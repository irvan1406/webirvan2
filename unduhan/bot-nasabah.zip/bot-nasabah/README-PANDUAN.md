# Bot Nasabah — Panduan Memasang

Bot WhatsApp (Baileys + Node.js) untuk mengelola data nasabah dari file Excel,
dilengkapi 150+ perintah: mushaf Al-Qur'an & hadis, peringatan gempa dan jadwal
sholat, pengunduh media, pembuat stiker, permainan, dan asisten AI.

Paket ini sudah dibersihkan dari seluruh data pemilik aslinya: tidak ada file
`.env` asli, tidak ada sesi login, tidak ada data nasabah, dan kode pairing
bawaan sudah diganti contoh netral.

## Syarat

- Node.js versi 20 atau lebih baru
- Koneksi internet untuk `npm install` dan untuk bot berjalan

## Langkah memasang

1. Ekstrak paket ini, lalu masuk ke foldernya.
2. Pasang dependensi:

   ```
   npm install
   ```

3. Buat konfigurasi:

   ```
   cp .env.example .env
   ```

   Edit `.env` — yang **wajib** diisi hanya `BOT_PHONE_NUMBER` (nomor WhatsApp
   yang akan menjadi bot, format internasional tanpa `+`, contoh
   `62812xxxxxxxx`). Kunci API AI boleh dikosongkan dulu.

4. Jalankan bot:

   ```
   npm start
   ```

5. Saat pertama jalan, bot meminta **pairing** ke WhatsApp nomor tersebut.
   Kode pairing bawaan dalam paket ini adalah `KODEKAMU` — kamu bisa
   menggantinya dengan mencari teks `requestPairingCode` di `index.js`.
   Masukkan kode itu di aplikasi WhatsApp → Perangkat tertaut → Tautkan dengan
   nomor telepon.

6. Setelah terhubung, kirim `.menu` ke bot untuk melihat semua perintah, dan
   `.fitur` untuk daftar per kategori.

## Data nasabah (CRM)

- Taruh file Excel nasabahmu di folder yang ditunjuk `EXCEL_DIR` pada `.env`
  (bawaan: `./data`).
- Bot membaca kolom-kolom umum (nama, unit, PIC, tanggal jatuh tempo, dsb.) —
  coba perintah `.cari <nama>` dan `.filter` setelah file terpasang.

## Folder dalam paket

- `index.js` — seluruh logika bot (satu file besar, memang begitu desainnya)
- `package.json` — dependensi
- `fonts/` — huruf untuk poster jadwal sholat & mushaf (jangan dipindah)
- `assets/` — latar poster sholat & nada sapaan menu (jangan dipindah)
- `.env.example` — contoh konfigurasi kosong

## Catatan

- Beberapa perintah memakai layanan pihak ketiga gratis (berita, unduhan,
  cuaca, dsb.); ketersediaannya mengikuti layanan masing-masing.
- Fitur AI (`.ai`, `.model`) baru aktif bila kamu mengisi kunci API milikmu
  sendiri di `.env`.
- Gunakan pada nomor dan data milikmu sendiri.
