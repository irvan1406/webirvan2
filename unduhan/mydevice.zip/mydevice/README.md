# My Device

Aplikasi Android pribadi untuk mengontrol HP dari jarak jauh via Telegram.
Jalankan di HP yang mau dikontrol. **Hanya untuk HP sendiri.**

## Cara pakai

1. Install APK di HP kedua.
2. Buka aplikasi, ikuti 5 langkah aktivasi:
   - Aktifkan Device Admin (untuk `/kunci`)
   - Aktifkan Aksesibilitas (untuk kunci aplikasi)
   - Beri semua izin runtime
   - Abaikan optimasi baterai
   - Izin ubah pengaturan sistem (untuk `/cerah`)
3. Tekan **Mulai service**.
4. **Matikan bot Termux** (`pkill -f gas.py`) — satu token hanya untuk satu bot.
5. Kirim `/menu` ke bot Telegram.

## Perintah

- `/kunci` — kunci layar seketika (butuh Device Admin)
- `/lockscreen <pin> | <pesan>` — tampilkan layar kunci PIN + pesan
- `/buka` — buka kunci dari jarak jauh
- `/setpin <pin>` — simpan PIN untuk kunci aplikasi
- `/daftarapk` — daftar aplikasi terinstall
- `/lockapk <nama/nomor>` — kunci aplikasi (butuh Aksesibilitas)
- `/bukapk <nama/nomor>` — buka kunci aplikasi
- `/foto`, `/selfie`, `/lokasi`, `/baterai`, `/info`, `/ngomong`, `/senter`,
  `/getar`, `/rekam`, `/sms`, `/inbox`, `/telpon`, `/kontak`, `/clipboard`,
  `/volume`, `/cerah`, `/notif`, `/toast`, `/download`, `/wifi`, `/wifion`,
  `/wifioff`, `/penyimpanan`
- Kirim **foto** ke bot → dijadikan wallpaper HP.

## Build

APK debug dibangun otomatis oleh GitHub Actions (workflow `Android CI`).
