package id.irvan.mydevice;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

/**
 * Layar media fullscreen: menampilkan foto / memutar video / audio yang dikirim
 * dari Telegram. HP terkunci total (semua tombol & taskbar mati) sampai /berhenti.
 */
public class ShowActivity extends Activity {

    public static ShowActivity current = null;

    /** Diisi sebelum activity diluncurkan. */
    public static String mediaPath = null;
    /** "image", "video", atau "audio". */
    public static String mediaKind = "image";
    public static String mediaLabel = "";

    private VideoView videoView = null;
    private MediaPlayer audioPlayer = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        hideNav();
        BarBlocker.show(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.BLACK);

        String kind = mediaKind == null ? "image" : mediaKind;
        String path = mediaPath;

        if ("video".equals(kind) && path != null) {
            videoView = new VideoView(this);
            LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            root.addView(videoView, vp);
            try {
                videoView.setVideoPath(path);
                videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        mp.setLooping(true);
                        videoView.start();
                    }
                });
                videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        try {
                            videoView.start();
                        } catch (Exception ignored) {
                        }
                    }
                });
            } catch (Exception ignored) {
            }
        } else if ("audio".equals(kind)) {
            TextView icon = new TextView(this);
            icon.setText("\uD83D\uDD0A");
            icon.setTextSize(96);
            icon.setGravity(Gravity.CENTER);
            root.addView(icon);
            TextView tv = new TextView(this);
            tv.setText("Memutar audio...\n" + (mediaLabel == null ? "" : mediaLabel)
                    + "\n\nKirim /berhenti di Telegram\nuntuk menghentikan.");
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(16);
            tv.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = 32;
            root.addView(tv, lp);
            startAudio(path);
        } else {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setAdjustViewBounds(true);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            root.addView(iv, ip);
            try {
                if (path != null) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inSampleSize = 2;
                    Bitmap b = BitmapFactory.decodeFile(path, o);
                    if (b != null) iv.setImageBitmap(b);
                }
            } catch (Exception ignored) {
            }
        }

        setContentView(root);
    }

    private void startAudio(final String path) {
        try {
            stopAudio();
            audioPlayer = new MediaPlayer();
            if (path != null) {
                audioPlayer.setDataSource(path);
            } else {
                return;
            }
            audioPlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            audioPlayer.setLooping(true);
            audioPlayer.prepare();
            audioPlayer.start();
        } catch (Exception ignored) {
        }
    }

    private void stopAudio() {
        try {
            if (audioPlayer != null) {
                try {
                    audioPlayer.stop();
                } catch (Exception ignored) {
                }
                audioPlayer.release();
            }
        } catch (Exception ignored) {
        }
        audioPlayer = null;
    }

    /** Dipanggil dari /berhenti: hentikan media & tutup. */
    public static void stopAndClose() {
        try {
            ShowActivity a = current;
            current = null;
            if (a != null) {
                a.stopAudio();
                try {
                    if (a.videoView != null) a.videoView.stopPlayback();
                } catch (Exception ignored) {
                }
                try {
                    BarBlocker.hide(a);
                } catch (Exception ignored) {
                }
                a.finish();
            }
        } catch (Exception ignored) {
        }
    }

    private void hideNav() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideNav();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // kunci media: kalau ditinggal (tombol home), paksa kembali ke depan
        try {
            if (Commands.mediaLocked() && !isFinishing()) {
                final ShowActivity self = this;
                getWindow().getDecorView().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (Commands.mediaLocked() && !self.isFinishing()) {
                                AppLockService.launchShow();
                            }
                        } catch (Exception ignored) {
                        }
                    }
                }, 400);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        stopAudio();
        try {
            if (videoView != null) videoView.stopPlayback();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // terkunci: tombol back mati
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        // semua tombol fisik mati selama kunci media
        int kc = e.getKeyCode();
        if (kc == android.view.KeyEvent.KEYCODE_VOLUME_UP
                || kc == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
                || kc == android.view.KeyEvent.KEYCODE_VOLUME_MUTE
                || kc == android.view.KeyEvent.KEYCODE_BACK
                || kc == android.view.KeyEvent.KEYCODE_MENU
                || kc == android.view.KeyEvent.KEYCODE_SEARCH
                || kc == android.view.KeyEvent.KEYCODE_APP_SWITCH) {
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
