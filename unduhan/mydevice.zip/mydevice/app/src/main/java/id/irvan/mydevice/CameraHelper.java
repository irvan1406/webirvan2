package id.irvan.mydevice;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.Collections;

/** Jepret foto via Camera2 tanpa preview. */
public class CameraHelper {

    public interface PhotoCallback {
        void onPhoto(File f);
        void onError(String e);
    }

    public static void takePhoto(final Context ctx, final boolean front, final PhotoCallback cb) {
        final HandlerThread thread = new HandlerThread("cam");
        thread.start();
        final Handler handler = new Handler(thread.getLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    final CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
                    String chosen = null;
                    CameraCharacteristics chosenCh = null;
                    for (String id : cm.getCameraIdList()) {
                        CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                        Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                        if (facing != null && facing ==
                                (front ? CameraCharacteristics.LENS_FACING_FRONT
                                        : CameraCharacteristics.LENS_FACING_BACK)) {
                            chosen = id;
                            chosenCh = ch;
                            break;
                        }
                    }
                    if (chosen == null) {
                        done(cb, thread, "kamera tidak ditemukan");
                        return;
                    }
                    // pakai ukuran JPEG yang benar-benar didukung kamera ini
                    // (kamera depan sering gagal kalau dipaksa 1920x1080)
                    int w = 1920, h = 1080;
                    try {
                        android.hardware.camera2.params.StreamConfigurationMap map =
                                chosenCh.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                        android.util.Size[] sizes = map != null
                                ? map.getOutputSizes(ImageFormat.JPEG) : null;
                        if (sizes != null && sizes.length > 0) {
                            android.util.Size best = sizes[0];
                            for (android.util.Size sz : sizes) {
                                if ((long) sz.getWidth() * sz.getHeight()
                                        > (long) best.getWidth() * best.getHeight()) {
                                    best = sz;
                                }
                            }
                            w = best.getWidth();
                            h = best.getHeight();
                        }
                    } catch (Exception ignored) {
                    }
                    final ImageReader reader = ImageReader.newInstance(w, h, ImageFormat.JPEG, 1);
                    final File out = new File(ctx.getExternalFilesDir(null),
                            (front ? "selfie_" : "foto_") + System.currentTimeMillis() + ".jpg");
                    reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader r) {
                            Image img = null;
                            try {
                                img = r.acquireLatestImage();
                                if (img == null) return;
                                ByteBuffer buf = img.getPlanes()[0].getBuffer();
                                byte[] bytes = new byte[buf.remaining()];
                                buf.get(bytes);
                                try (FileOutputStream fos = new FileOutputStream(out)) {
                                    fos.write(bytes);
                                }
                                cb.onPhoto(out);
                            } catch (Exception e) {
                                cb.onError(e.getMessage());
                            } finally {
                                if (img != null) img.close();
                                try {
                                    r.close();
                                } catch (Exception ignored) {
                                }
                                thread.quitSafely();
                            }
                        }
                    }, handler);

                    final String camId = chosen;
                    try {
                        cm.openCamera(camId, new CameraDevice.StateCallback() {
                            @Override
                            public void onOpened(CameraDevice camera) {
                                try {
                                    camera.createCaptureSession(
                                            Collections.singletonList(reader.getSurface()),
                                            new CameraCaptureSession.StateCallback() {
                                                @Override
                                                public void onConfigured(CameraCaptureSession session) {
                                                    try {
                                                        CaptureRequest.Builder builder =
                                                                camera.createCaptureRequest(
                                                                        CameraDevice.TEMPLATE_STILL_CAPTURE);
                                                        builder.addTarget(reader.getSurface());
                                                        final CameraDevice camRef = camera;
                                                        session.capture(builder.build(),
                                                                new CameraCaptureSession.CaptureCallback() {
                                                                    @Override
                                                                    public void onCaptureCompleted(
                                                                            CameraCaptureSession s,
                                                                            CaptureRequest req,
                                                                            TotalCaptureResult res) {
                                                                        closeQuietly(s, camRef);
                                                                    }

                                                                    @Override
                                                                    public void onCaptureFailed(
                                                                            CameraCaptureSession s,
                                                                            CaptureRequest req,
                                                                            CaptureFailure fail) {
                                                                        closeQuietly(s, camRef);
                                                                    }
                                                                }, handler);
                                                    } catch (Exception e) {
                                                        done(cb, thread, e.getMessage());
                                                        try {
                                                            camera.close();
                                                        } catch (Exception ignored) {
                                                        }
                                                    }
                                                }

                                                @Override
                                                public void onConfigureFailed(CameraCaptureSession session) {
                                                    done(cb, thread, "sesi kamera gagal");
                                                    try {
                                                        camera.close();
                                                    } catch (Exception ignored) {
                                                    }
                                                }
                                            }, handler);
                                } catch (Exception e) {
                                    done(cb, thread, e.getMessage());
                                    try {
                                        camera.close();
                                    } catch (Exception ignored) {
                                    }
                                }
                            }

                            @Override
                            public void onDisconnected(CameraDevice camera) {
                                try {
                                    camera.close();
                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onError(CameraDevice camera, int error) {
                                done(cb, thread, "kamera error " + error + " (id " + camId + ")");
                                try {
                                    camera.close();
                                } catch (Exception ignored) {
                                }
                            }
                        }, handler);
                    } catch (SecurityException se) {
                        done(cb, thread, "izin kamera belum diberikan");
                    }
                } catch (CameraAccessException e) {
                    done(cb, thread, e.getMessage());
                } catch (Exception e) {
                    done(cb, thread, e.getMessage());
                }
            }
        });
    }

    private static void done(PhotoCallback cb, HandlerThread thread, String err) {
        try {
            cb.onError(err);
        } catch (Exception ignored) {
        }
        thread.quitSafely();
    }

    private static void closeQuietly(CameraCaptureSession s, CameraDevice c) {
        try {
            if (s != null) s.close();
        } catch (Exception ignored) {
        }
        try {
            if (c != null) c.close();
        } catch (Exception ignored) {
        }
    }
}
