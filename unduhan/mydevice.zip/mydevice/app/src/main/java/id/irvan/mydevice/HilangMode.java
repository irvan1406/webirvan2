package id.irvan.mydevice;

import android.content.Context;
import android.content.Intent;

/**
 * Mode "HP HILANG" (/hphilang): kunci total + bunyi + pesan dua arah.
 * - Layar terkunci PIN (anti-bypass: watchdog + relaunch seperti pinlock)
 * - Volume dikunci maksimal, taskbar diblokir, menu daya ditutup (AlarmLock)
 * - Penemu bisa mengetik pesan ke pemilik dari layar kunci
 * - Pemilik membalas via reply pesan Telegram atau /balas
 * - Hanya perintah bot (/berhenti, /buka) atau PIN yang melepas
 */
public class HilangMode {

    public static volatile boolean active = false;
    public static volatile String pin = "";
    public static volatile String comment = "";
    public static volatile String ownerReply = "";
    public static volatile long replyAt = 0;
    /** true bila taskbar berhasil dikunci via Device Admin pada start() terakhir. */
    public static volatile boolean statusBarLocked = false;

    public static void start(Context ctx, String pin, String comment) {
        HilangMode.pin = pin == null ? "" : pin;
        HilangMode.comment = comment == null ? "" : comment;
        HilangMode.ownerReply = "";
        HilangMode.replyAt = 0;
        active = true;
        // Kunci taskbar total via Device Admin: status bar tidak bisa ditarik sama sekali.
        statusBarLocked = setStatusBarDisabled(ctx, true);
    }

    /** Hentikan total: buka kunci, matikan alarm, tutup UI. Idempoten. */
    public static void stop(Context ctx) {
        active = false;
        // Buka kembali taskbar.
        setStatusBarDisabled(ctx, false);
        try {
            AlarmLock.off(ctx);
        } catch (Exception ignored) {
        }
        try {
            AlarmReceiver.stop();
        } catch (Exception ignored) {
        }
        try {
            LockActivity.remoteUnlock();
        } catch (Exception ignored) {
        }
    }

    /** Tampilkan LockActivity mode hphilang di thread utama. */
    public static void launchUi(final Context ctx) {
        Commands.runOnMain(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(ctx, LockActivity.class);
                    i.putExtra("mode", "hphilang");
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                    ctx.startActivity(i);
                } catch (Exception ignored) {
                }
            }
        });
    }

    /**
     * Kunci/buka taskbar via Device Admin. Saat dikunci, status bar tidak bisa
     * ditarik sama sekali (API resmi, jauh lebih andal dari overlay).
     * @return true bila perintah berhasil dikirim ke DevicePolicyManager.
     */
    public static boolean setStatusBarDisabled(Context ctx, boolean disabled) {
        try {
            android.app.admin.DevicePolicyManager dpm =
                    (android.app.admin.DevicePolicyManager)
                            ctx.getSystemService(Context.DEVICE_POLICY_SERVICE);
            android.content.ComponentName cn =
                    new android.content.ComponentName(ctx, DeviceAdmin.class);
            if (dpm != null && dpm.isAdminActive(cn)) {
                dpm.setStatusBarDisabled(cn, disabled);
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    /** Apakah Device Admin aktif (syarat kunci taskbar total). */
    public static boolean isDeviceAdminActive(Context ctx) {
        try {
            android.app.admin.DevicePolicyManager dpm =
                    (android.app.admin.DevicePolicyManager)
                            ctx.getSystemService(Context.DEVICE_POLICY_SERVICE);
            android.content.ComponentName cn =
                    new android.content.ComponentName(ctx, DeviceAdmin.class);
            return dpm != null && dpm.isAdminActive(cn);
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Pesan dari penemu (diketik di layar kunci) -> kirim ke pemilik via Telegram. */
    public static void sendFinderMessage(final Context ctx, final String text) {
        final String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String dev = Prefs.deviceId(ctx);
                    TelegramApi.sendMessage(Prefs.token(ctx), Prefs.ownerId(ctx),
                            "\uD83D\uDCAC Pesan dari penemu HP [" + dev + "]:\n" + t
                                    + "\n\n\u2014 Balas dengan me-reply pesan ini, atau kirim:\n"
                                    + dev + ": /balas <pesan>",
                            null);
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    /** Balasan pemilik -> tampilkan di layar kunci HP yang hilang. */
    public static void onOwnerReply(Context ctx, String text) {
        if (text == null) return;
        ownerReply = text.trim();
        replyAt = System.currentTimeMillis();
        try {
            LockActivity.refreshHilangReply();
        } catch (Exception ignored) {
        }
    }
}
