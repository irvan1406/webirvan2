package id.irvan.mydevice;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * IDE-8: Setup Wizard 1-tombol.
 * Checklist status + tombol "Aktifkan Semua" yang memandu user langkah demi langkah:
 * dialog izin berurutan, deep-link ke App Info (pengaturan terbatas), Aksesibilitas,
 * Device Admin, dan bebas optimasi baterai. Tidak menghilangkan tap wajib sistem,
 * tapi menghilangkan cari-cari menu.
 */
public class SetupWizardActivity extends Activity {

    private LinearLayout list;
    private TextView statusJudul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF121212);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        sv.addView(root);

        TextView judul = new TextView(this);
        judul.setText("Setup My Device");
        judul.setTextSize(26);
        judul.setTypeface(null, android.graphics.Typeface.BOLD);
        judul.setTextColor(Color.WHITE);
        root.addView(judul);

        TextView sub = new TextView(this);
        sub.setText("Selesaikan semua langkah agar semua fitur berjalan.");
        sub.setTextSize(14);
        sub.setTextColor(0xFFAAAAAA);
        root.addView(sub);

        statusJudul = new TextView(this);
        statusJudul.setTextSize(14);
        statusJudul.setTextColor(0xFF03DAC6);
        statusJudul.setPadding(0, dp(8), 0, dp(8));
        root.addView(statusJudul);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Button cek = tombol("CEK LAGI", 0xFF333333, Color.WHITE);
        cek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh();
            }
        });
        root.addView(cek);

        setContentView(sv);
        refresh();
    }

    private Button tombol(String teks, int bg, int fg) {
        Button b = new Button(this);
        b.setText(teks);
        b.setTextColor(fg);
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(dp(12));
        b.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, 0);
        b.setLayoutParams(lp);
        b.setPadding(dp(16), dp(14), dp(16), dp(14));
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void refresh() {
        list.removeAllViews();
        int ok = 0, total = 5;
        ok += kartu("1. Izin aplikasi",
                "Kamera, mic, lokasi, SMS, kontak, Bluetooth, notifikasi.",
                izinDasarOk(),
                "Minta izin", new Runnable() {
                    @Override
                    public void run() {
                        mintaIzin();
                    }
                }) ? 1 : 0;
        if (Build.VERSION.SDK_INT >= 29) {
            ok += kartu("1b. Lokasi latar belakang",
                    "Wajib agar /lokasi & /lokasirt jalan saat layar mati.\n" +
                            "Di halaman berikut: tap Izin \u2192 Lokasi \u2192 pilih \"Izinkan sepanjang waktu\".",
                    bgLocOk(),
                    "Buka info aplikasi", new Runnable() {
                        @Override
                        public void run() {
                            bukaInfoAplikasi();
                        }
                    }) ? 1 : 0;
            total++;
        }
        ok += kartu("1c. Tampil di atas aplikasi lain",
                "Wajib agar taskbar tidak bisa ditarik saat HP hilang / terkunci.\n" +
                        "Di halaman berikut: aktifkan \"Izinkan tampil di atas aplikasi lain\".",
                BarBlocker.canDrawOverlays(this),
                "Buka pengaturan", new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                            i.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                            toast("Gagal membuka pengaturan");
                        }
                    }
                }) ? 1 : 0;
        total++;
        ok += kartu("2. Pengaturan terbatas",
                "Wajib untuk aplikasi sideload.\nDi halaman berikut: tap \u22EE kanan atas \u2192 "
                        + "Izinkan pengaturan terbatas \u2192 masukkan PIN.",
                a11yOk(),
                "Buka info aplikasi", new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            i.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                            toast("Gagal membuka pengaturan");
                        }
                    }
                }) ? 1 : 0;
        ok += kartu("3. Aksesibilitas",
                "Dibutuhkan: kunci aplikasi, anti-bypass PIN, skip iklan, dll.",
                a11yOk(),
                "Buka aksesibilitas", new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                        } catch (Exception e) {
                            toast("Gagal membuka pengaturan");
                        }
                    }
                }) ? 1 : 0;
        ok += kartu("4. Admin perangkat",
                "Dibutuhkan untuk kunci layar jarak jauh.",
                deviceAdminOk(),
                "Aktifkan", new Runnable() {
                    @Override
                    public void run() {
                        try {
                            ComponentName cn = new ComponentName(SetupWizardActivity.this,
                                    DeviceAdmin.class);
                            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn);
                            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                    "Diperlukan untuk mengunci layar dari jarak jauh.");
                            startActivity(i);
                        } catch (Exception e) {
                            toast("Gagal membuka aktivasi");
                        }
                    }
                }) ? 1 : 0;
        ok += kartu("5. Bebas optimasi baterai",
                "Agar layanan tetap jalan saat layar mati.",
                batteryOk(),
                "Izinkan", new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent i = new Intent(
                                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                            i.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                            toast("Gagal membuka pengaturan");
                        }
                    }
                }) ? 1 : 0;
        statusJudul.setText(ok + " dari " + total + " langkah selesai"
                + (ok == total ? " \u2014 semua beres! \uD83C\uDF89" : ""));
    }

    private boolean kartu(String judul, String desc, boolean ok, String aksiTeks,
                          final Runnable aksi) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xFF1E1E1E);
        d.setCornerRadius(dp(14));
        card.setBackground(d);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);

        TextView t = new TextView(this);
        t.setText((ok ? "\u2705 " : "\u274C ") + judul);
        t.setTextSize(16);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setTextColor(Color.WHITE);
        card.addView(t);

        TextView ds = new TextView(this);
        ds.setText(desc);
        ds.setTextSize(13);
        ds.setTextColor(0xFFBBBBBB);
        ds.setPadding(0, dp(4), 0, dp(8));
        card.addView(ds);

        if (!ok) {
            Button b = tombol(aksiTeks, 0xFF03DAC6, Color.BLACK);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    aksi.run();
                }
            });
            card.addView(b);
        }
        list.addView(card);
        return ok;
    }

    private void mintaIzin() {
        List<String> need = new ArrayList<>();
        List<String> all = new ArrayList<>();
        all.add(android.Manifest.permission.CAMERA);
        all.add(android.Manifest.permission.RECORD_AUDIO);
        all.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        all.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
        all.add(android.Manifest.permission.SEND_SMS);
        all.add(android.Manifest.permission.RECEIVE_SMS);
        all.add(android.Manifest.permission.READ_SMS);
        all.add(android.Manifest.permission.CALL_PHONE);
        all.add(android.Manifest.permission.READ_CONTACTS);
        all.add(android.Manifest.permission.READ_CALL_LOG);
        all.add(android.Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT >= 31) {
            all.add(android.Manifest.permission.BLUETOOTH_CONNECT);
            all.add(android.Manifest.permission.BLUETOOTH_SCAN);
        }
        // CATATAN: ACCESS_BACKGROUND_LOCATION TIDAK BOLEH digabung — Android 11+
        // mengabaikan seluruh request jika digabung (tombol terlihat mati).
        // Izin itu ditangani kartu terpisah via Pengaturan aplikasi.
        for (String p : all) {
            try {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
            } catch (Exception ignored) {
            }
        }
        if (need.isEmpty()) {
            toast("Semua izin dasar sudah diberikan");
            refresh();
        } else {
            try {
                requestPermissions(need.toArray(new String[0]), 9001);
            } catch (Exception e) {
                toast("Gagal meminta izin");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private boolean bgLocOk() {
        try {
            return checkSelfPermission(android.Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    private void bukaInfoAplikasi() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            toast("Gagal membuka pengaturan");
        }
    }

    private boolean izinDasarOk() {
        String[] must = {
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.RECORD_AUDIO,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_CONTACTS,
        };
        for (String p : must) {
            try {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    private boolean a11yOk() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabled != null && enabled.toLowerCase().contains(getPackageName().toLowerCase());
        } catch (Exception e) {
            return false;
        }
    }

    private boolean deviceAdminOk() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName cn = new ComponentName(this, DeviceAdmin.class);
            return dpm != null && dpm.isAdminActive(cn);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean batteryOk() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
