package id.irvan.mydevice;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.List;

/**
 * Sembunyikan/tampilkan ikon launcher. Komponen launcher dicari langsung via
 * queryIntentActivities (tanpa tebak nama) agar andal di semua varian build.
 */
public class AppIcon {

    /** Cari komponen launcher aplikasi ini yang sebenarnya (biasanya LauncherAlias). */
    public static ComponentName launcherComponent(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            launcher.setPackage(ctx.getPackageName());
            List<ResolveInfo> list = pm.queryIntentActivities(launcher,
                    PackageManager.MATCH_DISABLED_COMPONENTS);
            if (list != null) {
                for (ResolveInfo ri : list) {
                    if (ri != null && ri.activityInfo != null) {
                        return new ComponentName(ri.activityInfo.packageName,
                                ri.activityInfo.name);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** Cari LauncherAlias yang benar-benar ada di PackageManager. */
    public static ComponentName alias(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        String pkg = ctx.getPackageName();
        // Catatan: nama relatif ".LauncherAlias" di manifest diekspansi pakai
        // namespace build (id.irvan.mydevice), BUKAN applicationId (bisa .debug)
        String[] candidates = {
                "id.irvan.mydevice.LauncherAlias",
                pkg + ".LauncherAlias",
        };
        for (String cls : candidates) {
            try {
                ComponentName cn = new ComponentName(pkg, cls);
                pm.getActivityInfo(cn, PackageManager.MATCH_DISABLED_COMPONENTS);
                return cn;
            } catch (Exception ignored) {
            }
        }
        return new ComponentName(pkg, "id.irvan.mydevice.LauncherAlias");
    }

    /** Status ikon saat ini: true = terlihat. */
    public static boolean isVisible(Context ctx) {
        try {
            ComponentName cn = launcherComponent(ctx);
            if (cn == null) cn = alias(ctx);
            int st = ctx.getPackageManager().getComponentEnabledSetting(cn);
            // DEFAULT (0) = mengikuti manifest = terlihat
            return st != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
        } catch (Exception e) {
            return true;
        }
    }

    /**
     * @return true kalau status AKHIR sesuai permintaan (terverifikasi baca-balik).
     */
    public static boolean setVisible(Context ctx, boolean visible) {
        try {
            PackageManager pm = ctx.getPackageManager();
            ComponentName cn = launcherComponent(ctx);
            if (cn == null) cn = alias(ctx); // fallback cara lama
            int targetState = visible ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                    : PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
            for (int attempt = 0; attempt < 2; attempt++) {
                try {
                    pm.setComponentEnabledSetting(cn, targetState,
                            PackageManager.DONT_KILL_APP);
                } catch (Exception ignored) {
                }
                try {
                    Thread.sleep(400);
                } catch (Exception ignored) {
                }
                if (checkState(pm, cn, visible)) return true;
            }
            return checkState(pm, cn, visible);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean checkState(PackageManager pm, ComponentName cn, boolean visible) {
        try {
            int st = pm.getComponentEnabledSetting(cn);
            if (visible) {
                return st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        || st == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT;
            } else {
                return st == PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
