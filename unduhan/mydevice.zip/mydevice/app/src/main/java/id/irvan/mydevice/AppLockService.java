package id.irvan.mydevice;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * - Kunci PIN kiosk: paksa kembali ke layar PIN untuk aplikasi apa pun.
 * - Kunci aplikasi (appblock): aplikasi terkunci tidak bisa dibuka sama sekali,
 *   hanya bisa dibuka via /bukapk dari Telegram. Tanpa PIN di layar.
 */
public class AppLockService extends AccessibilityService {

    /** package -> boleh dibuka sampai timestamp ini (setelah PIN benar, mode pinlock). */
    public static final Map<String, Long> tempUnlock = new HashMap<>();
    private static String lastPkg = null;
    /** Paket foreground terakhir menurut event a11y (untuk debounce kunci apk). */
    private static volatile String latestFgPkg = "";
    /** Paket yang sedang dijadwalkan dikunci (cegah jadwal ganda). */
    private static volatile String pendingLockPkg = null;

    private final android.os.Handler watchHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());

    /**
     * Watchdog: tiap 700ms pastikan layar kunci/kunci media benar-benar di depan.
     * Menutup celah timing (mis. spam home) yang lolos dari event & onPause.
     */
    private final Runnable watchTick = new Runnable() {
        @Override
        public void run() {
            try {
                AppLockService svc = AppLockService.this;
                boolean pinlock = false, screenlock = false, media = false, hilang = false;
                boolean papan = false;
                try {
                    pinlock = Prefs.isPinLocked(svc);
                    screenlock = Prefs.screenLocked(svc);
                    media = Commands.mediaLocked();
                    hilang = HilangMode.active;
                    papan = Prefs.papanActive(svc);
                } catch (Exception ignored) {
                }
                if ((pinlock || screenlock) && !LockActivity.isResumed) {
                    if (pinlock) launchPinlock();
                    else launchScreenLock();
                } else if (hilang && !LockActivity.isResumed) {
                    launchHilang();
                } else if (papan && !PapanActivity.isResumed()) {
                    launchPapanAgain();
                } else if (media && ShowActivity.current == null) {
                    launchShow();
                }
                // Taskbar: pastikan tetap terkunci selama HP hilang (asuransi bila
                // kebijakan DPM ter-reset oleh sistem).
                if (hilang) {
                    try {
                        if (!HilangMode.statusBarLocked) {
                            HilangMode.statusBarLocked =
                                    HilangMode.setStatusBarDisabled(svc, true);
                        }
                    } catch (Exception ignored) {
                    }
                }
            } catch (Exception ignored) {
            }
            try {
                watchHandler.postDelayed(this, 700);
            } catch (Exception ignored) {
            }
        }
    };

    private void startWatchdog() {
        try {
            watchHandler.removeCallbacks(watchTick);
            watchHandler.postDelayed(watchTick, 700);
        } catch (Exception ignored) {
        }
    }

    private void stopWatchdog() {
        try {
            watchHandler.removeCallbacks(watchTick);
        } catch (Exception ignored) {
        }
    }

    private static AccessibilityService instance;

    /** Batas waktu auto-klik dialog pairing Bluetooth (diset BtHelper saat pairing). */
    public static volatile long btAutoAcceptUntil = 0;

    private boolean isYouTubePkg(String pkg) {
        return "com.google.android.youtube".equals(pkg)
                || "app.revanced.android.youtube".equals(pkg);
    }

    /** Klik tombol "Lewati"/"Skip" iklan YouTube jika ada. */
    private void skipYouTubeAd() {
        android.view.accessibility.AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            String[] kws = {"skip", "lewati"};
            for (String kw : kws) {
                java.util.List<android.view.accessibility.AccessibilityNodeInfo> nodes;
                try {
                    nodes = root.findAccessibilityNodeInfosByText(kw);
                } catch (Exception e) {
                    continue;
                }
                if (nodes == null) continue;
                for (android.view.accessibility.AccessibilityNodeInfo n : nodes) {
                    try {
                        CharSequence t = n.getText();
                        if (t == null) continue;
                        String s = t.toString().trim().toLowerCase();
                        if (s.equals("skip") || s.equals("lewati")
                                || s.startsWith("skip ad") || s.startsWith("lewati iklan")) {
                            android.view.accessibility.AccessibilityNodeInfo tgt =
                                    n.isClickable() ? n : n.getParent();
                            if (tgt != null && tgt.performAction(
                                    android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)) {
                                return;
                            }
                        }
                    } catch (Exception ignored) {
                    }
                }
            }
        } finally {
            try {
                root.recycle();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        try {
            startWatchdog();
        } catch (Exception ignored) {
        }
        try {
            android.accessibilityservice.AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.flags |= android.accessibilityservice.AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
                setServiceInfo(info);
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Telan tombol volume saat HP sedang berdering kencang (/findmy, /bunyi,
     * alarm) — volume hanya bisa dimatikan lewat perintah Telegram.
     */
    @Override
    protected boolean onKeyEvent(android.view.KeyEvent event) {
        try {
            int kc = event.getKeyCode();
            if (kc == android.view.KeyEvent.KEYCODE_VOLUME_UP
                    || kc == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
                    || kc == android.view.KeyEvent.KEYCODE_VOLUME_MUTE) {
                if (AlarmReceiver.isRinging() || Commands.isFindRinging()
                        || Commands.mediaLocked() || AlarmLock.isEnforcing()) return true;
            }
        } catch (Exception ignored) {
        }
        return super.onKeyEvent(event);
    }

    /** Cek via Settings apakah layanan aksesibilitas aplikasi ini AKTIF (sumber kebenaran). */
    public static boolean isEnabled(android.content.Context ctx) {
        try {
            String enabled = android.provider.Settings.Secure.getString(
                    ctx.getContentResolver(),
                    android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            String low = enabled.toLowerCase();
            String pkg = ctx.getPackageName().toLowerCase();
            return low.contains(pkg + "/.applockservice")
                    || low.contains(pkg + "/" + pkg + ".applockservice");
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        try {
            stopWatchdog();
        } catch (Exception ignored) {
        }
        return super.onUnbind(intent);
    }

    /** Geser taskbar (notification shade) ke bawah / ke atas bergantian. */
    public static boolean toggleShade() {
        try {
            AccessibilityService svc = instance;
            if (svc == null) return false;
            if (shadeOpen) {
                svc.performGlobalAction(GLOBAL_ACTION_BACK);
                shadeOpen = false;
            } else {
                svc.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
                shadeOpen = true;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Tekan tombol navigasi: "home", "back", atau "recent". */
    public static boolean navAction(String which) {
        try {
            AccessibilityService svc = instance;
            if (svc == null) return false;
            int action = "home".equals(which) ? GLOBAL_ACTION_HOME
                    : "back".equals(which) ? GLOBAL_ACTION_BACK
                    : GLOBAL_ACTION_RECENTS;
            return svc.performGlobalAction(action);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean shadeOpen = false;

    /** Buka MainActivity sendiri (untuk dialog izin Bluetooth sistem). */
    public static boolean launchSelf() {
        try {
            AccessibilityService svc = instance;
            if (svc == null) return false;
            Intent i = new Intent(svc, MainActivity.class);
            i.putExtra("bt_request", true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            svc.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Jalankan intent apa pun lewat accessibility service (lolos batasan background-start). */
    public static boolean launchIntent(android.content.Intent i) {
        try {
            AccessibilityService svc = instance;
            if (svc == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            svc.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Buka aplikasi lewat accessibility service (lolos batasan background-start). */
    public static boolean launchPackage(String pkg) {
        try {
            AccessibilityService svc = instance;
            if (svc == null) return false;
            Intent i = svc.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            svc.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private long lastAdSkipCheck = 0;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        int type = event.getEventType();
        CharSequence cs = event.getPackageName();
        String pkg = cs == null ? "" : cs.toString();

        // IDE-9: SKIP IKLAN YouTube otomatis — tombol "Lewati"/"Skip" muncul belakangan,
        // jadi pantau perubahan konten juga (throttle 1.5 dtk, hanya di aplikasi YouTube).
        if (!pkg.equals(getPackageName())
                && (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)) {
            try {
                if (Prefs.skipIklan(this) && isYouTubePkg(pkg)) {
                    long now = System.currentTimeMillis();
                    if (now - lastAdSkipCheck > 1500) {
                        lastAdSkipCheck = now;
                        skipYouTubeAd();
                    }
                }
            } catch (Exception ignored) {
            }
        }

        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (cs == null) return;
        latestFgPkg = pkg; // catat foreground terakhir (debounce kunci apk)
        if (pkg.equals(getPackageName())) return; // aplikasi sendiri

        // MODE HP HILANG (/bunyi): tutup menu daya sistem agar HP tak bisa
        // dimatikan dari perangkat — hanya /berhenti dari Telegram yang melepas.
        try {
            if (AlarmLock.isEnforcing() && isPowerMenu(event, pkg)) {
                performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                return;
            }
        } catch (Exception ignored) {
        }

        // MODE KUNCI (pinlock / HP hilang / lockscreen): tutup paksa notification
        // shade sistem agar taskbar tak bisa ditarik saat perangkat dikunci.
        // (DevicePolicyManager.setStatusBarDisabled adalah lapis utama; BarBlocker
        // overlay lapis kedua; ini lapis ketiga.)
        // Agresif: SEMUA window systemui saat terkunci -> tutup. Saat HP hilang/
        // terkunci, pengguna memang tidak boleh berinteraksi dengan systemui.
        try {
            if ((Prefs.isPinLocked(this) || HilangMode.active || Prefs.screenLocked(this))
                    && "com.android.systemui".equals(pkg)) {
                if (Build.VERSION.SDK_INT >= 31) {
                    performGlobalAction(
                            AccessibilityService.GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE);
                }
                performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                return;
            }
        } catch (Exception ignored) {
        }

        // AUTO-TERIMA pairing Bluetooth (2 menit setelah ketuk tombol perangkat)
        try {
            if (System.currentTimeMillis() < btAutoAcceptUntil && autoAcceptPairing()) return;
        } catch (Exception ignored) {
        }

        // Keluar dari aplikasi yang dibuka sementara -> kunci lagi
        try {
            String lp = lastPkg;
            if (lp != null && !lp.equals(pkg) && !lp.equals(getPackageName())
                    && !pkg.equals(getPackageName()) && tempUnlock.containsKey(lp)) {
                tempUnlock.remove(lp);
            }
            lastPkg = pkg;
        } catch (Exception ignored) {
        }

        // KUNCI LAYAR (pinlock & lockscreen): paksa kembali SEGERA ke layar kunci,
        // tanpa peduli LockActivity.current — spam home pun langsung ditarik balik.
        // (singleInstance: instance yang ada dibawa ke depan, bukan dibuat baru)
        try {
            if (Prefs.isPinLocked(this)) {
                launchPinlock();
                return;
            }
            if (Prefs.screenLocked(this)) {
                launchScreenLock();
                return;
            }
            if (HilangMode.active) {
                launchHilang();
                return;
            }
        } catch (Exception e) {
            return;
        }

        if (LockActivity.current != null) return; // kunci aplikasi sedang tampil

        // Kunci media: paksa kembali ke layar media sampai /berhenti (bawa ke depan)
        try {
            if (Commands.mediaLocked()) {
                launchShow();
                return;
            }
        } catch (Exception e) {
            return;
        }

        // Kunci aplikasi: blokir total, tanpa PIN di layar — buka hanya via /bukapk
        Set<String> locked;
        try {
            locked = Prefs.lockedApps(this);
        } catch (Exception e) {
            return;
        }
        if (!locked.contains(pkg)) return;
        if (!isAppLocked(this, pkg)) return; // dibuka sementara via /bukapk

        // Debounce: event basi (mis. aplikasi X yang baru ditutup) bisa datang
        // SETELAH event home — kunci hanya bila X masih foreground 350ms kemudian.
        // Ini memperbaiki "kunci apk muncul lagi setelah keluar dari aplikasi".
        final String lockPkg = pkg;
        if (lockPkg.equals(pendingLockPkg)) return; // sudah dijadwalkan
        pendingLockPkg = lockPkg;
        final AppLockService self = this;
        watchHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    pendingLockPkg = null;
                    if (!lockPkg.equals(latestFgPkg)) return; // sudah pindah, batal
                    if (!isAppLocked(self, lockPkg)) return;
                    if (LockActivity.current != null) return;
                    Intent i = new Intent(self, LockActivity.class);
                    i.putExtra("mode", "appblock");
                    i.putExtra("pkg", lockPkg);
                    try {
                        String label = self.getPackageManager().getApplicationLabel(
                                self.getPackageManager().getApplicationInfo(lockPkg, 0)).toString();
                        i.putExtra("label", label);
                    } catch (Exception ignored) {
                        i.putExtra("label", lockPkg);
                    }
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                    try {
                        self.startActivity(i);
                    } catch (Exception ignored) {
                    }
                } catch (Exception ignored) {
                }
            }
        }, 350);
    }

    @Override
    public void onInterrupt() {
    }

    /** true jika aplikasi masih terkunci (bukan temp-unlock yang valid). */
    public static boolean isAppLocked(android.content.Context ctx, String pkg) {
        try {
            if (!Prefs.lockedApps(ctx).contains(pkg)) return false;
            Long exp = tempUnlock.get(pkg);
            return exp == null || exp < System.currentTimeMillis();
        } catch (Exception e) {
            return false;
        }
    }

    /** Tampilkan lagi layar media (dipakai saat kunci media aktif). */
    public static boolean launchShow() {
        AccessibilityService svc = instance;
        if (svc == null) return false;
        try {
            Intent i = new Intent(svc, ShowActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            svc.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Tampilkan papan LED / jam digital (IDE-6). Revisi 2026-10-13: tutup yang lama dulu. */
    public static boolean launchPapan(String mode, String teks) {
        AccessibilityService svc = instance;
        if (svc == null) return false;
        try {
            try {
                PapanActivity.stopCurrent();
            } catch (Exception ignored) {
            }
            PapanActivity.mode = mode;
            PapanActivity.teks = teks == null ? "" : teks;
            Intent i = new Intent(svc, PapanActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            svc.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Bawa kembali PapanActivity (kiosk papan/jam). */
    private void launchPapanAgain() {
        Intent i = new Intent(this, PapanActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    /** Tampilkan lagi layar lockscreen PIN (mode /lockscreen). */
    public static boolean launchScreenLock() {
        AccessibilityService svc = instance;
        if (svc == null) return false;
        try {
            Intent i = new Intent(svc, LockActivity.class);
            i.putExtra("mode", "lockscreen");
            i.putExtra("pin", Prefs.pin(svc));
            i.putExtra("message", Prefs.lockMessage(svc));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            svc.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void launchHilang() {
        Intent i = new Intent(this, LockActivity.class);
        i.putExtra("mode", "hphilang");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void launchPinlock() {
        Intent i = new Intent(this, LockActivity.class);
        i.putExtra("mode", "pinlock");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    // ---------- screenshot (Android 11+) ----------

    public interface ShotCallback {
        void onShot(java.io.File f);
        void onError(String e);
    }

    /** Ambil screenshot layar. Butuh Android 11+ (API 30). */
    public static void takeScreenshot(final android.content.Context ctx, final ShotCallback cb) {
        final AccessibilityService svc = instance;
        if (svc == null) {
            cb.onError("aksesibilitas belum aktif");
            return;
        }
        if (android.os.Build.VERSION.SDK_INT < 30) {
            cb.onError("butuh Android 11+");
            return;
        }
        try {
            java.util.concurrent.Executor exec = new java.util.concurrent.Executor() {
                @Override
                public void execute(Runnable r) {
                    r.run();
                }
            };
            svc.takeScreenshot(android.view.Display.DEFAULT_DISPLAY, exec,
                    new AccessibilityService.TakeScreenshotCallback() {
                        @Override
                        public void onSuccess(final android.accessibilityservice.AccessibilityService.ScreenshotResult res) {
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        android.graphics.Bitmap bmp = android.graphics.Bitmap.wrapHardwareBuffer(
                                                res.getHardwareBuffer(), res.getColorSpace());
                                        android.graphics.Bitmap sw = bmp.copy(android.graphics.Bitmap.Config.ARGB_8888, false);
                                        bmp.recycle();
                                        try {
                                            res.getHardwareBuffer().close();
                                        } catch (Exception ignored) {
                                        }
                                        java.io.File out = new java.io.File(ctx.getExternalFilesDir(null),
                                                "shot_" + System.currentTimeMillis() + ".jpg");
                                        java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
                                        // kecilkan agar cepat terkirim
                                        int w = sw.getWidth(), h = sw.getHeight();
                                        float scale = Math.min(1.0f, 720.0f / Math.max(w, h));
                                        android.graphics.Bitmap small = android.graphics.Bitmap.createScaledBitmap(
                                                sw, Math.round(w * scale), Math.round(h * scale), true);
                                        small.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, fos);
                                        fos.close();
                                        sw.recycle();
                                        if (small != sw) small.recycle();
                                        cb.onShot(out);
                                    } catch (Exception e) {
                                        cb.onError(e.getMessage());
                                    }
                                }
                            }).start();
                        }

                        @Override
                        public void onFailure(int errorCode) {
                            cb.onError("screenshot gagal (" + errorCode + ")");
                        }
                    });
        } catch (Exception e) {
            cb.onError(e.getMessage());
        }
    }

    // ---------- gesture jarak jauh ----------

    public interface GestureCallback {
        void onDone(boolean ok);
    }

    /** Ketuk di koordinat layar (x,y piksel). */
    public static void sendTapAt(final float x, final float y, final GestureCallback cb) {
        final AccessibilityService svc = instance;
        if (svc == null) {
            if (cb != null) cb.onDone(false);
            return;
        }
        try {
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(x, y);
            android.accessibilityservice.GestureDescription.StrokeDescription stroke =
                    new android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 80);
            android.accessibilityservice.GestureDescription gd =
                    new android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build();
            svc.dispatchGesture(gd, new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(android.accessibilityservice.GestureDescription g) {
                    if (cb != null) cb.onDone(true);
                }

                @Override
                public void onCancelled(android.accessibilityservice.GestureDescription g) {
                    if (cb != null) cb.onDone(false);
                }
            }, null);
        } catch (Exception e) {
            if (cb != null) cb.onDone(false);
        }
    }

    /**
     * Ketuk digit PIN di keypad kunci layar bawaan (estimasi posisi 3x4, best-effort).
     * Callback dipanggil setelah semua digit diketuk.
     */
    public static void tapPinDigits(final String pin, final GestureCallback cb) {
        final AccessibilityService svc = instance;
        if (svc == null) {
            if (cb != null) cb.onDone(false);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.view.WindowManager wm = (android.view.WindowManager)
                            svc.getSystemService(android.content.Context.WINDOW_SERVICE);
                    android.graphics.Point sz = new android.graphics.Point();
                    try {
                        wm.getDefaultDisplay().getRealSize(sz);
                    } catch (Exception e) {
                        wm.getDefaultDisplay().getSize(sz);
                    }
                    final float w = sz.x, h = sz.y;
                    Thread.sleep(1500); // tunggu keypad muncul
                    for (int k = 0; k < pin.length(); k++) {
                        char c = pin.charAt(k);
                        if (c < '0' || c > '9') continue;
                        int d = c - '0';
                        int row, col;
                        if (d == 0) {
                            row = 3;
                            col = 1;
                        } else {
                            row = (d - 1) / 3;
                            col = (d - 1) % 3;
                        }
                        // Revisi 2026-10-13: titik keypad bisa dikalibrasi via /pinpos.
                        float gx0 = 0.125f, gy0 = 0.5525f, gw = 0.75f, gh = 0.38f;
                        try {
                            gx0 = Prefs.pinGridX0(svc);
                            gy0 = Prefs.pinGridY0(svc);
                            gw = Prefs.pinGridW(svc);
                            gh = Prefs.pinGridH(svc);
                        } catch (Exception ignored) {
                        }
                        final float x = w * (gx0 + gw * (col + 0.5f) / 3f);
                        final float y = h * (gy0 + gh * (row + 0.5f) / 4f);
                        final boolean[] done = {false};
                        sendTapAt(x, y, new GestureCallback() {
                            @Override
                            public void onDone(boolean ok) {
                                done[0] = true;
                            }
                        });
                        long t0 = System.currentTimeMillis();
                        while (!done[0] && System.currentTimeMillis() - t0 < 2000) {
                            Thread.sleep(50);
                        }
                        Thread.sleep(350);
                    }
                    if (cb != null) cb.onDone(true);
                } catch (Exception e) {
                    if (cb != null) cb.onDone(false);
                }
            }
        }).start();
    }

    /**
     * Kirim gesture: "up", "down", "left", "right", "tap".
     * Koordinat dihitung dari ukuran layar aktual.
     */
    public static void sendGesture(String kind, final GestureCallback cb) {
        final AccessibilityService svc = instance;
        if (svc == null) {
            if (cb != null) cb.onDone(false);
            return;
        }
        try {
            android.view.WindowManager wm = (android.view.WindowManager)
                    svc.getSystemService(android.content.Context.WINDOW_SERVICE);
            android.graphics.Point size = new android.graphics.Point();
            try {
                wm.getDefaultDisplay().getRealSize(size);
            } catch (Exception e) {
                wm.getDefaultDisplay().getSize(size);
            }
            int w = size.x, h = size.y;
            android.graphics.Path path = new android.graphics.Path();
            long dur = 300;
            if ("tap".equals(kind)) {
                path.moveTo(w / 2f, h / 2f);
                dur = 80;
            } else if ("up".equals(kind)) {
                path.moveTo(w / 2f, h * 0.75f);
                path.lineTo(w / 2f, h * 0.25f);
            } else if ("down".equals(kind)) {
                path.moveTo(w / 2f, h * 0.25f);
                path.lineTo(w / 2f, h * 0.75f);
            } else if ("left".equals(kind)) {
                path.moveTo(w * 0.75f, h / 2f);
                path.lineTo(w * 0.25f, h / 2f);
            } else { // right
                path.moveTo(w * 0.25f, h / 2f);
                path.lineTo(w * 0.75f, h / 2f);
            }
            android.accessibilityservice.GestureDescription.StrokeDescription stroke =
                    new android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, dur);
            android.accessibilityservice.GestureDescription gd =
                    new android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build();
            svc.dispatchGesture(gd, new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(android.accessibilityservice.GestureDescription g) {
                    if (cb != null) cb.onDone(true);
                }

                @Override
                public void onCancelled(android.accessibilityservice.GestureDescription g) {
                    if (cb != null) cb.onDone(false);
                }
            }, null);
        } catch (Exception e) {
            if (cb != null) cb.onDone(false);
        }
    }

    // ---------- bluetooth via pengaturan (fallback Android 13+) ----------

    /**
     * Nyalakan/matikan Bluetooth lewat halaman Pengaturan (untuk HP yang
     * memblokir toggle programatik). Mengembalikan status akhir tercapai.
     */
    public static boolean btViaSettings(final boolean want) {
        final AccessibilityService svc = instance;
        if (svc == null) return false;
        try {
            final android.bluetooth.BluetoothAdapter ba =
                    android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            // buka halaman bluetooth
            android.content.Intent i = new android.content.Intent(
                    android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            svc.startActivity(i);
            long t0 = android.os.SystemClock.uptimeMillis();
            boolean clicked = false;
            while (android.os.SystemClock.uptimeMillis() - t0 < 12000) {
                if (ba != null && ba.isEnabled() == want) {
                    clicked = true;
                    break;
                }
                try {
                    android.view.accessibility.AccessibilityNodeInfo root =
                            svc.getRootInActiveWindow();
                    if (root != null) {
                        if (tryFlipBtSwitch(root, want)) {
                            // tunggu perubahan status
                            long t1 = android.os.SystemClock.uptimeMillis();
                            while (android.os.SystemClock.uptimeMillis() - t1 < 4000) {
                                if (ba != null && ba.isEnabled() == want) break;
                                Thread.sleep(400);
                            }
                        }
                        try {
                            root.recycle();
                        } catch (Exception ignored) {
                        }
                    }
                } catch (Exception ignored) {
                }
                try {
                    Thread.sleep(800);
                } catch (InterruptedException ignored) {
                }
            }
            try {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
            } catch (Exception ignored) {
            }
            return ba != null && ba.isEnabled() == want;
        } catch (Exception e) {
            return false;
        }
    }

    /** Deteksi dialog menu daya sistem (tahan tombol power). */
    private boolean isPowerMenu(android.view.accessibility.AccessibilityEvent event, String pkg) {
        try {
            if (!"com.android.systemui".equals(pkg)) return false;
            CharSequence cn = event.getClassName();
            String cls = cn == null ? "" : cn.toString().toLowerCase(java.util.Locale.US);
            if (cls.contains("power") || cls.contains("globalactions") || cls.contains("shutdown")) {
                return true;
            }
            StringBuilder tb = new StringBuilder();
            try {
                for (CharSequence t : event.getText()) tb.append(t).append(' ');
            } catch (Exception ignored) {
            }
            String txt = tb.toString().toLowerCase(java.util.Locale.US);
            return txt.contains("matikan daya") || txt.contains("power off")
                    || txt.contains("mulai ulang") || txt.contains("restart")
                    || txt.contains("daya mati") || txt.contains("mode darurat");
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Deteksi notification shade / panel notifikasi sistem (tarik taskbar). */
    private boolean isNotifShade(android.view.accessibility.AccessibilityEvent event, String pkg) {
        try {
            if (!"com.android.systemui".equals(pkg)) return false;
            CharSequence cn = event.getClassName();
            String cls = cn == null ? "" : cn.toString().toLowerCase(java.util.Locale.US);
            return cls.contains("shade") || cls.contains("notification") || cls.contains("statusbar")
                    || cls.contains("qs") || cls.contains("quicksettings");
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Klik tombol "Pasangkan" pada dialog pairing Bluetooth bila muncul. */
    private boolean autoAcceptPairing() {
        android.view.accessibility.AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null) return false;
            if (!containsPairText(root)) return false;
            return clickPairButton(root);
        } catch (Exception ignored) {
            return false;
        } finally {
            try {
                if (root != null) root.recycle();
            } catch (Exception ignored) {
            }
        }
    }

    private boolean containsPairText(android.view.accessibility.AccessibilityNodeInfo node) {
        if (node == null) return false;
        try {
            if (containsPairWord(node.getText())) return true;
            if (containsPairWord(node.getContentDescription())) return true;
            int n = node.getChildCount();
            for (int k = 0; k < n; k++) {
                android.view.accessibility.AccessibilityNodeInfo c = null;
                try {
                    c = node.getChild(k);
                } catch (Exception ignored) {
                }
                if (c != null) {
                    boolean r = containsPairText(c);
                    try {
                        c.recycle();
                    } catch (Exception ignored) {
                    }
                    if (r) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean containsPairWord(CharSequence cs) {
        if (cs == null) return false;
        String t = cs.toString().toLowerCase(java.util.Locale.US);
        return t.contains("pasang") || t.contains("pair") || t.contains("sambungkan");
    }

    private boolean clickPairButton(android.view.accessibility.AccessibilityNodeInfo node) {
        if (node == null) return false;
        boolean[] done = {false};
        clickPairButtonRec(node, done);
        return done[0];
    }

    private void clickPairButtonRec(android.view.accessibility.AccessibilityNodeInfo node,
                                    boolean[] done) {
        if (node == null || done[0]) return;
        try {
            CharSequence t = node.getText();
            String txt = t == null ? "" : t.toString().toLowerCase(java.util.Locale.US);
            boolean positive = txt.equals("pasangkan") || txt.equals("pair")
                    || txt.equals("sambungkan") || txt.equals("hubungkan")
                    || txt.equals("ok") || txt.equals("ya");
            if (positive) {
                try {
                    if (node.isClickable()) {
                        node.performAction(
                                android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);
                        done[0] = true;
                        return;
                    }
                } catch (Exception ignored) {
                }
            }
            int n = node.getChildCount();
            for (int k = 0; k < n && !done[0]; k++) {
                android.view.accessibility.AccessibilityNodeInfo c = null;
                try {
                    c = node.getChild(k);
                } catch (Exception ignored) {
                }
                if (c != null) {
                    clickPairButtonRec(c, done);
                    try {
                        c.recycle();
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Cari Switch Bluetooth di pohon aksesibilitas dan klik bila perlu.
     * @return true hanya jika benar-benar mengklik sebuah switch (bukan karena
     *         "sudah sesuai" — itu dicek pemanggil via ba.isEnabled()).
     */
    private static boolean tryFlipBtSwitch(android.view.accessibility.AccessibilityNodeInfo node, boolean want) {
        // Pass 1: switch yang bertuliskan "bluetooth" (toggle utama)
        if (clickBtSwitch(node, want, true)) return true;
        // Pass 2: switch apa pun yang perlu di-flip
        return clickBtSwitch(node, want, false);
    }

    private static boolean clickBtSwitch(android.view.accessibility.AccessibilityNodeInfo node,
                                         boolean want, boolean onlyBt) {
        boolean[] clicked = {false};
        clickBtSwitchRec(node, want, onlyBt, clicked);
        return clicked[0];
    }

    private static void clickBtSwitchRec(android.view.accessibility.AccessibilityNodeInfo node,
                                         boolean want, boolean onlyBt, boolean[] clicked) {
        if (node == null || clicked[0]) return;
        try {
            CharSequence cn = node.getClassName();
            if (cn != null && cn.toString().contains("Switch")) {
                boolean needFlip = false;
                try {
                    needFlip = (node.isChecked() != want);
                } catch (Exception ignored) {
                }
                if (needFlip && (!onlyBt || hasBtText(node))) {
                    if (performClick(node)) {
                        clicked[0] = true;
                        return;
                    }
                }
            }
            int n = node.getChildCount();
            for (int k = 0; k < n && !clicked[0]; k++) {
                android.view.accessibility.AccessibilityNodeInfo c = null;
                try {
                    c = node.getChild(k);
                } catch (Exception ignored) {
                }
                if (c != null) {
                    clickBtSwitchRec(c, want, onlyBt, clicked);
                    try {
                        c.recycle();
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean hasBtText(android.view.accessibility.AccessibilityNodeInfo node) {
        try {
            if (containsBt(node.getText())) return true;
            if (containsBt(node.getContentDescription())) return true;
            android.view.accessibility.AccessibilityNodeInfo p = null;
            try {
                p = node.getParent();
                if (p != null && (containsBt(p.getText()) || containsBt(p.getContentDescription()))) {
                    return true;
                }
            } finally {
                try {
                    if (p != null) p.recycle();
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private static boolean containsBt(CharSequence cs) {
        return cs != null && cs.toString().toLowerCase(java.util.Locale.US).contains("bluetooth");
    }

    /** Klik node; bila node tidak clickable, coba klik parent-nya (baris setting). */
    private static boolean performClick(android.view.accessibility.AccessibilityNodeInfo node) {
        try {
            if (node.isClickable()) {
                node.performAction(
                        android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);
                return true;
            }
            android.view.accessibility.AccessibilityNodeInfo p = null;
            try {
                p = node.getParent();
                if (p != null && p.isClickable()) {
                    p.performAction(
                            android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);
                    return true;
                }
            } finally {
                try {
                    if (p != null) p.recycle();
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }
}
