package id.irvan.mydevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;

/**
 * IDE-1: Perintah via SMS + pertahanan SIM.
 *
 * Format SMS dari nomor pemilik (terdaftar via /setnomor):
 *   IRVAN# BUNYI 1234   -> kunci + bunyi (mode HP hilang)
 *   IRVAN# KUNCI 1234   -> sama seperti BUNYI
 *   IRVAN# LOKASI 1234  -> balas SMS berisi link Google Maps
 *   IRVAN# BERHENTI 1234 -> hentikan semua aktivitas (seperti /berhenti)
 *   /berhenti          -> hentikan semua aktivitas (tanpa prefix & tanpa PIN, jaga-jaga)
 * "1234" = PIN master aplikasi (/setpin). Tanpa PIN yang benar -> diabaikan.
 *
 * Juga: SIM dicabut -> kunci otomatis; SIM dipasang lagi -> peringatan Telegram.
 */
public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        if (a == null) return;
        if ("android.provider.Telephony.SMS_RECEIVED".equals(a)) {
            handleSms(ctx, intent);
        } else if ("android.telephony.action.SIM_CARD_STATE_CHANGED".equals(a)) {
            handleSim(ctx);
        }
    }

    private void handleSms(Context ctx, Intent intent) {
        try {
            Bundle b = intent.getExtras();
            if (b == null) return;
            Object[] pdus = (Object[]) b.get("pdus");
            if (pdus == null || pdus.length == 0) return;
            String sender = "";
            StringBuilder sb = new StringBuilder();
            String fmt = b.getString("format");
            for (Object pdu : pdus) {
                SmsMessage m;
                try {
                    m = SmsMessage.createFromPdu((byte[]) pdu, fmt);
                } catch (Exception e) {
                    continue;
                }
                if (m == null) continue;
                if (m.getOriginatingAddress() != null) sender = m.getOriginatingAddress();
                if (m.getMessageBody() != null) sb.append(m.getMessageBody());
            }
            String owner = Prefs.ownerPhone(ctx);
            if (owner == null || owner.isEmpty()) return;
            if (!Commands.normPhone(sender).equals(Commands.normPhone(owner))) return;

            String body = sb.toString().trim();
            // Revisi 2026-10-13: "/berhenti" polos dari nomor owner = hentikan semua
            // (tanpa prefix IRVAN# dan tanpa PIN, untuk jaga-jaga).
            if (body.equalsIgnoreCase("/berhenti")) {
                try {
                    abortBroadcast();
                } catch (Exception ignored) {
                }
                Commands.berhentiTotal(ctx);
                balasSms(ctx, sender, "OK: semua aktivitas dihentikan di [" + Prefs.deviceId(ctx) + "].");
                return;
            }
            if (!body.toUpperCase().startsWith("IRVAN#")) return;
            String[] parts = body.substring(6).trim().split("\\s+");
            if (parts.length < 2) return;
            String cmd = parts[0].toUpperCase();
            String pin = parts[1];
            String master = Prefs.pin(ctx);
            if (master == null || master.isEmpty() || !master.equals(pin)) return;

            try {
                abortBroadcast();
            } catch (Exception ignored) {
            }

            if ("BUNYI".equals(cmd) || "KUNCI".equals(cmd)) {
                hilangFull(ctx, pin, "Perintah via SMS dari pemilik");
                balasSms(ctx, sender, "OK: mode HP hilang aktif di [" + Prefs.deviceId(ctx) + "].");
            } else if ("BERHENTI".equals(cmd)) {
                Commands.berhentiTotal(ctx);
                balasSms(ctx, sender, "OK: semua aktivitas dihentikan di [" + Prefs.deviceId(ctx) + "].");
            } else if ("LOKASI".equals(cmd)) {
                kirimLokasiSms(ctx, sender);
            }
        } catch (Exception ignored) {
        }
    }

    /** Aktivasi mode HP hilang lengkap (seperti /hphilang). */
    private void hilangFull(Context ctx, String pin, String comment) {
        try {
            HilangMode.start(ctx, pin, comment);
            try {
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                am.setStreamVolume(AudioManager.STREAM_ALARM,
                        am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            } catch (Exception ignored) {
            }
            AlarmReceiver.ring(ctx, "Mode HP hilang", false);
            AlarmLock.on(ctx);
            HilangMode.launchUi(ctx);
        } catch (Exception ignored) {
        }
    }

    private void balasSms(Context ctx, String to, String msg) {
        try {
            SmsManager sm = SmsManager.getDefault();
            for (String part : sm.divideMessage(msg)) {
                try {
                    sm.sendTextMessage(to, null, part, null, null);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void kirimLokasiSms(final Context ctx, final String to) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    LocationManager lm = (LocationManager)
                            ctx.getSystemService(Context.LOCATION_SERVICE);
                    Location l = null;
                    try {
                        l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (l == null) l = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    } catch (Exception ignored) {
                    }
                    String msg = (l == null)
                            ? "Lokasi [" + Prefs.deviceId(ctx) + "] belum tersedia."
                            : "Lokasi [" + Prefs.deviceId(ctx) + "]: "
                            + "https://maps.google.com/?q="
                            + l.getLatitude() + "," + l.getLongitude();
                    SmsManager sm = SmsManager.getDefault();
                    for (String part : sm.divideMessage(msg)) {
                        try {
                            sm.sendTextMessage(to, null, part, null, null);
                        } catch (Exception ignored) {
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private void handleSim(final Context ctx) {
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return;
            int st = tm.getSimState();
            if (st == TelephonyManager.SIM_STATE_ABSENT) {
                Prefs.setSimWasAbsent(ctx, true);
                // SIM dicabut -> kunci otomatis
                String pin = Prefs.pin(ctx);
                if (pin == null || pin.isEmpty()) pin = "1234";
                hilangFull(ctx, pin, "SIM dicabut — pengaman otomatis");
            } else if (st == TelephonyManager.SIM_STATE_READY && Prefs.simWasAbsent(ctx)) {
                Prefs.setSimWasAbsent(ctx, false);
                // SIM dipasang lagi (kemungkinan diganti) -> peringatan via Telegram
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            TelegramApi.sendMessage(Prefs.token(ctx), Prefs.ownerId(ctx),
                                    "⚠️ SIM dipasang/diganti di [" + Prefs.deviceId(ctx)
                                            + "]. Periksa HP itu!",
                                    null);
                        } catch (Exception ignored) {
                        }
                    }
                }).start();
            }
        } catch (Exception ignored) {
        }
    }
}
