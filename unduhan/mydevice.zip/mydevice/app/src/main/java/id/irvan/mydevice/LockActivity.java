package id.irvan.mydevice;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Layar kunci PIN fullscreen.
 * Mode "lockscreen": mengunci seluruh HP (dari /lockscreen).
 * Mode "applock": mengunci satu aplikasi (dari AppLockService).
 */
public class LockActivity extends Activity {

    public static LockActivity current = null;
    /** true saat activity kunci sedang tampil di depan (di-update onResume/onPause). */
    public static boolean isResumed = false;

    private String pin = "";
    private String mode = "lockscreen";
    private String pkg = "";
    private final StringBuilder input = new StringBuilder();
    private TextView dots;
    private TextView replyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }

        pin = getIntent().getStringExtra("pin");
        if (pin == null) pin = "";
        mode = getIntent().getStringExtra("mode");
        if (mode == null) mode = "lockscreen";
        // mode "pinlock": kunci total perangkat, PIN dari Prefs (hanya angka)
        if ("pinlock".equals(mode)) {
            pin = Prefs.pinLockPin(this);
        }
        // mode "hphilang": PIN dari perintah /hphilang
        if ("hphilang".equals(mode)) {
            pin = HilangMode.pin;
        }
        pkg = getIntent().getStringExtra("pkg");
        if (pkg == null) pkg = "";
        String message = getIntent().getStringExtra("message");
        if (message == null || message.isEmpty()) {
            if ("pinlock".equals(mode)) {
                message = "Perangkat dikunci.\nMasukkan PIN untuk membuka.";
            } else if ("hphilang".equals(mode)) {
                String hc = HilangMode.comment;
                message = (hc == null || hc.isEmpty())
                        ? "\uD83D\uDEA8 HP ini hilang.\nKetik pesan di bawah untuk menghubungi pemilik."
                        : hc;
            } else if ("appblock".equals(mode)) {
                message = "Aplikasi dikunci oleh pemilik.\nHubungi pemilik untuk membuka.";
            } else {
                message = "lockscreen".equals(mode)
                        ? "HP dikunci.\nMasukkan PIN yang dikirim."
                        : "Aplikasi dikunci.\nMasukkan PIN.";
            }
        }
        String label = getIntent().getStringExtra("label");
        if (label == null || label.isEmpty()) label = "My Device";

        // mode pinlock/appblock/hphilang: immersive penuh, sembunyikan navigasi
        if ("pinlock".equals(mode) || "appblock".equals(mode) || "hphilang".equals(mode)) {
            hideNav();
            BarBlocker.show(this);
        }

        // Revisi 2026-10-13: UI HP hilang ala mockup (tema biru, kartu PIN, kartu pesan).
        if ("hphilang".equals(mode)) {
            buildHilangUi();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#111827"));
        root.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("\uD83D\uDD12 " + ("lockscreen".equals(mode) ? "My Device" : label));
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView msg = new TextView(this);
        msg.setText(message);
        msg.setTextColor(Color.parseColor("#9CA3AF"));
        msg.setTextSize(16);
        msg.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mp.topMargin = 24;
        mp.bottomMargin = 32;
        root.addView(msg, mp);

        dots = new TextView(this);
        dots.setTextSize(32);
        dots.setTextColor(Color.WHITE);
        dots.setGravity(Gravity.CENTER);
        root.addView(dots);
        refreshDots();

        if ("appblock".equals(mode)) {
            TextView lock = new TextView(this);
            lock.setText("\uD83D\uDD12");
            lock.setTextSize(72);
            lock.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            llp.topMargin = 48;
            root.addView(lock, llp);
        } else {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setRowCount(4);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        gp.topMargin = 32;
        grid.setLayoutParams(gp);

        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "\u232B"};
        for (String k : keys) {
            Button b = new Button(this);
            b.setText(k);
            b.setTextSize(24);
            b.setTextColor(Color.WHITE);
            b.setBackgroundColor(Color.parseColor("#1F2937"));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 220;
            lp.height = 170;
            lp.setMargins(12, 12, 12, 12);
            b.setLayoutParams(lp);
            final String key = k;
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onKey(key);
                }
            });
            grid.addView(b);
        }
        LinearLayout wrap = new LinearLayout(this);
        wrap.setGravity(Gravity.CENTER);
        wrap.addView(grid);
        root.addView(wrap);
        }

        setContentView(root);
    }

    /** Refresh tampilan balasan pemilik (dipanggil saat ada /balas atau reply). */
    public static void refreshHilangReply() {
        final LockActivity a = current;
        if (a == null || !"hphilang".equals(a.mode) || a.replyView == null) return;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    String r = HilangMode.ownerReply;
                    a.replyView.setText(r == null || r.isEmpty() ? "(belum ada balasan)" : r);
                } catch (Exception ignored) {
                }
            }
        });
    }

    /** Revisi 2026-10-13: UI HP hilang ala mockup — tema biru, kartu PIN, kartu pesan. */
    private void buildHilangUi() {
        // #6: layout mengecil saat keyboard muncul — input tetap kelihatan.
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        ScrollView sv = new ScrollView(this);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF1430D6, 0xFF060D5E});
        sv.setBackground(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(36));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText(Prefs.hilangJudul(this));
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText(Prefs.hilangPesan(this));
        sub.setTextColor(0xFFD6DCFF);
        sub.setTextSize(15);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(8);
        slp.bottomMargin = dp(20);
        root.addView(sub, slp);

        // ---- Peringatan lockdown (#8) ----
        TextView warn = new TextView(this);
        warn.setText("\u26A0\uFE0F " + Prefs.hilangWarn(this));
        warn.setTextColor(0xFFFFD54F);
        warn.setTextSize(14);
        warn.setTypeface(Typeface.DEFAULT_BOLD);
        warn.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        wlp.bottomMargin = dp(6);
        root.addView(warn, wlp);

        // ---- Kartu PIN ----
        if (Prefs.hilangPinOn(this)) {
            LinearLayout card = hilangCard();
            TextView lb = new TextView(this);
            lb.setText("\uD83D\uDCAC " + Prefs.hilangPinLabel(this));
            lb.setTextColor(Color.WHITE);
            lb.setTextSize(16);
            lb.setTypeface(Typeface.DEFAULT_BOLD);
            card.addView(lb);
            String psub = Prefs.hilangPinSub(this);
            if (psub != null && !psub.isEmpty()) {
                TextView ps = new TextView(this);
                ps.setText(psub);
                ps.setTextColor(0xFFAAB4FF);
                ps.setTextSize(13);
                LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                plp.topMargin = dp(2);
                plp.bottomMargin = dp(8);
                card.addView(ps, plp);
            }
            dots = new TextView(this);
            dots.setTextSize(30);
            dots.setTextColor(Color.WHITE);
            dots.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            dlp.topMargin = dp(10);
            dlp.bottomMargin = dp(14);
            card.addView(dots, dlp);
            refreshDots();

            GridLayout grid = new GridLayout(this);
            grid.setColumnCount(3);
            LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            grid.setLayoutParams(glp);
            String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "\u232B", "0"};
            for (String k : keys) {
                Button b = new Button(this);
                b.setText(k);
                b.setTextSize(22);
                b.setTextColor(Color.WHITE);
                GradientDrawable bd = new GradientDrawable();
                bd.setColor(0xFF2A4BE0);
                bd.setCornerRadius(dp(14));
                b.setBackground(bd);
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = 0;
                lp.height = dp(64);
                lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
                lp.setMargins(dp(6), dp(6), dp(6), dp(6));
                b.setLayoutParams(lp);
                final String key = k;
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onKey(key);
                    }
                });
                grid.addView(b);
            }
            card.addView(grid);
            root.addView(card);
        }

        // ---- Kartu balasan pemilik ----
        LinearLayout rcard = hilangCard();
        TextView rl = new TextView(this);
        rl.setText("\uD83D\uDCAC " + Prefs.hilangLabel(this));
        rl.setTextColor(0xFFAAB4FF);
        rl.setTextSize(14);
        rl.setTypeface(Typeface.DEFAULT_BOLD);
        rcard.addView(rl);
        replyView = new TextView(this);
        replyView.setTextColor(Color.WHITE);
        replyView.setTextSize(15);
        replyView.setMaxLines(5);
        LinearLayout.LayoutParams rvp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        rvp.topMargin = dp(6);
        rcard.addView(replyView, rvp);
        refreshHilangReply();
        root.addView(rcard);

        // ---- Kartu pesan ----
        LinearLayout mcard = hilangCard();
        TextView ml = new TextView(this);
        ml.setText("\uD83D\uDCAC " + Prefs.hilangMsgLabel(this));
        ml.setTextColor(Color.WHITE);
        ml.setTextSize(16);
        ml.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        mlp.bottomMargin = dp(10);
        mcard.addView(ml, mlp);

        LinearLayout irow = new LinearLayout(this);
        irow.setOrientation(LinearLayout.HORIZONTAL);
        irow.setGravity(Gravity.CENTER_VERTICAL);
        final EditText et = new EditText(this);
        et.setHint(Prefs.hilangHint(this));
        et.setTextColor(Color.WHITE);
        et.setHintTextColor(0xFF8A94D6);
        GradientDrawable ed = new GradientDrawable();
        ed.setColor(0xFF1A2BB0);
        ed.setCornerRadius(dp(16));
        et.setBackground(ed);
        et.setPadding(dp(18), dp(14), dp(18), dp(14));
        et.setSingleLine(false);
        et.setMaxLines(3);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        elp.rightMargin = dp(10);
        irow.addView(et, elp);
        Button send = new Button(this);
        send.setText("\u27A4");
        send.setTextColor(Color.WHITE);
        send.setTextSize(18);
        GradientDrawable sd = new GradientDrawable();
        sd.setColor(0xFF2E7CF6);
        sd.setCornerRadius(dp(16));
        send.setBackground(sd);
        send.setPadding(dp(18), dp(12), dp(18), dp(12));
        irow.addView(send);
        mcard.addView(irow);
        root.addView(mcard);

        // ---- Tombol besar ----
        final Button kirim = new Button(this);
        kirim.setText("\uD83D\uDCE9 " + Prefs.hilangTombol(this));
        kirim.setTextColor(Color.WHITE);
        kirim.setTextSize(17);
        kirim.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable kd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF3B8BF6, 0xFF1A56DB});
        kd.setCornerRadius(dp(18));
        kirim.setBackground(kd);
        kirim.setPadding(dp(16), dp(18), dp(16), dp(18));
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        klp.topMargin = dp(18);
        root.addView(kirim, klp);
        final LockActivity selfRef = this;
        View.OnClickListener kirimAct = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = et.getText().toString().trim();
                if (t.isEmpty()) return;
                HilangMode.sendFinderMessage(selfRef, t);
                et.setText("");
                kirim.setText("\u2705 Terkirim!");
                kirim.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            kirim.setText("\uD83D\uDCE9 " + Prefs.hilangTombol(selfRef));
                        } catch (Exception ignored) {
                        }
                    }
                }, 2000);
            }
        };
        kirim.setOnClickListener(kirimAct);
        send.setOnClickListener(kirimAct);

        // Keyboard menutupi input: di mode fullscreen immersive, ADJUST_RESIZE
        // tidak jalan — geser manual konten setinggi keyboard + auto-scroll ke input.
        final ScrollView svRef = sv;
        final EditText etRef = et;
        sv.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    private int lastKb = -1;

                    @Override
                    public void onGlobalLayout() {
                        Rect r = new Rect();
                        svRef.getWindowVisibleDisplayFrame(r);
                        int h = svRef.getRootView().getHeight();
                        int kb = h - r.bottom;
                        if (kb < h * 0.15) kb = 0;
                        if (kb != lastKb) {
                            lastKb = kb;
                            svRef.setPadding(0, 0, 0, kb);
                        }
                    }
                });
        et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    svRef.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            svRef.smoothScrollTo(0, etRef.getBottom());
                        }
                    }, 300);
                }
            }
        });

        setContentView(sv);
    }

    private LinearLayout hilangCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xFF1B2BA8);
        d.setCornerRadius(dp(20));
        d.setStroke(dp(2), 0xFF2E4BE8);
        card.setBackground(d);
        card.setPadding(dp(20), dp(18), dp(20), dp(18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        card.setLayoutParams(lp);
        return card;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        // #8/#11: total lockdown saat HP hilang — volume & back mati.
        if ("hphilang".equals(mode)) {
            if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP
                    || keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
                    || keyCode == android.view.KeyEvent.KEYCODE_VOLUME_MUTE
                    || keyCode == android.view.KeyEvent.KEYCODE_BACK) {
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private void onKey(String k) {
        if ("C".equals(k)) {
            input.setLength(0);
        } else if ("\u232B".equals(k)) {
            if (input.length() > 0) input.deleteCharAt(input.length() - 1);
        } else {
            if (input.length() < 12) input.append(k);
        }
        refreshDots();
        if (input.length() == pin.length() && pin.length() > 0) {
            if (input.toString().equals(pin)) {
                unlock();
            } else {
                input.setLength(0);
                refreshDots();
                dots.setText("\u274C salah");
                onPinSalah();
            }
        }
    }

    private void refreshDots() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < input.length(); i++) s.append("\u25CF ");
        dots.setText(s.toString());
    }

    private static int gagalPin = 0;

    private void unlock() {
        gagalPin = 0;
        if ("lockscreen".equals(mode)) {
            Prefs.setScreenLocked(this, false);
        } else if ("pinlock".equals(mode)) {
            Prefs.setPinLocked(this, false);
            notifyTelegram("\uD83D\uDD13 [" + Prefs.deviceId(this) + "] Perangkat dibuka dengan PIN.");
        } else if ("hphilang".equals(mode)) {
            HilangMode.stop(this);
            notifyTelegram("\uD83D\uDD13 [" + Prefs.deviceId(this) + "] Mode HP hilang dibuka dengan PIN.");
        } else if (!pkg.isEmpty()) {
            AppLockService.tempUnlock.put(pkg, System.currentTimeMillis() + 120_000);
        }
        finish();
    }

    /** IDE-3: salah PIN 1x -> selfie diam-diam terkirim ke owner. */
    private void onPinSalah() {
        if (!Prefs.fotoPenyusup(this)) return;
        gagalPin++;
        if (gagalPin >= 1) {
            gagalPin = 0;
            fotoPenyusup();
        }
    }

    private void fotoPenyusup() {
        try {
            CameraHelper.takePhoto(this, true, new CameraHelper.PhotoCallback() {
                @Override
                public void onPhoto(final java.io.File f) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                TelegramApi.sendFile(Prefs.token(LockActivity.this),
                                        "sendPhoto", "photo",
                                        Prefs.ownerId(LockActivity.this), f,
                                        "\uD83D\uDEA8 Ada yang salah memasukkan PIN 3x di ["
                                                + Prefs.deviceId(LockActivity.this) + "]",
                                        null);
                            } catch (Exception ignored) {
                            }
                        }
                    }).start();
                }

                @Override
                public void onError(String e) {
                }
            });
        } catch (Exception ignored) {
        }
    }

    private void notifyTelegram(final String teks) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    TelegramApi.sendMessage(Prefs.token(LockActivity.this),
                            Prefs.ownerId(LockActivity.this), teks, null);
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    /** Dipanggil dari /buka: tutup kunci dari jarak jauh. */
    public static void remoteUnlock() {
        final LockActivity a = current;
        if (a != null) {
            if ("lockscreen".equals(a.mode)) {
                Prefs.setScreenLocked(a, false);
            } else if ("pinlock".equals(a.mode)) {
                Prefs.setPinLocked(a, false);
            } else if ("hphilang".equals(a.mode)) {
                HilangMode.active = false;
            }
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        a.finish();
                    } catch (Exception ignored) {
                    }
                }
            });
        }
    }

    // ---------- mode pinlock: kiosk ----------

    private void hideNav() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && ("pinlock".equals(mode) || "appblock".equals(mode)
                || "hphilang".equals(mode))) hideNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isResumed = (current == this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        isResumed = false;
        // pinlock/lockscreen/appblock: kalau layar kunci ditinggal (tombol home), paksa kembali
        boolean stillBlocked = ("pinlock".equals(mode) && Prefs.isPinLocked(this))
                || ("lockscreen".equals(mode) && Prefs.screenLocked(this))
                || ("appblock".equals(mode) && AppLockService.isAppLocked(this, pkg))
                || ("hphilang".equals(mode) && HilangMode.active);
        if (stillBlocked) {
            final LockActivity self = this;
            getWindow().getDecorView().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        boolean sb2 = ("pinlock".equals(self.mode) && Prefs.isPinLocked(self))
                                || ("lockscreen".equals(self.mode) && Prefs.screenLocked(self))
                                || ("appblock".equals(self.mode)
                                    && AppLockService.isAppLocked(self, self.pkg))
                                || ("hphilang".equals(self.mode) && HilangMode.active);
                        if (sb2 && !self.isFinishing()) {
                            android.content.Intent i = new android.content.Intent(self, LockActivity.class);
                            i.putExtra("mode", self.mode);
                            i.putExtra("pkg", self.pkg);
                            if ("lockscreen".equals(self.mode)) {
                                i.putExtra("pin", Prefs.pin(self));
                                i.putExtra("message", Prefs.lockMessage(self));
                            }
                            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                    | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                    | android.content.Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                            self.startActivity(i);
                        }
                    } catch (Exception ignored) {
                    }
                }
            }, 300);
        }
    }

    @Override
    public void onBackPressed() {
        // tombol back diblokir
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        // pinlock/appblock: telan tombol volume juga — semua tombol fisik mati
        if ("pinlock".equals(mode) || "appblock".equals(mode)) {
            int kc = e.getKeyCode();
            if (kc == android.view.KeyEvent.KEYCODE_VOLUME_UP
                    || kc == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
                    || kc == android.view.KeyEvent.KEYCODE_VOLUME_MUTE) {
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        try {
            BarBlocker.hide(this);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
