package id.irvan.mydevice;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

/** Penerima jadwal alarm: bunyikan nada alarm berulang sampai dihentikan. */
public class AlarmReceiver extends BroadcastReceiver {

    public static final String ACT_RING = "id.irvan.mydevice.ALARM_RING";
    private static final String CH = "alarm_ch";

    private static MediaPlayer player;

    /** Jadwalkan alarm sekali bunyi. */
    public static void schedule(Context ctx, long triggerAt, String label) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = pendingFor(ctx, triggerAt, label);
            if (am == null) return;
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } catch (SecurityException se) {
                // izin exact alarm belum diberikan -> pakai jadwal biasa
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
            Prefs.addAlarm(ctx, triggerAt, label);
        } catch (Exception ignored) {
        }
    }

    /** Batalkan alarm tertentu. */
    public static void cancel(Context ctx, long triggerAt, String label) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(pendingFor(ctx, triggerAt, label));
        } catch (Exception ignored) {
        }
        Prefs.removeAlarm(ctx, triggerAt);
    }

    private static PendingIntent pendingFor(Context ctx, long triggerAt, String label) {
        Intent in = new Intent(ctx, AlarmReceiver.class);
        in.setAction(ACT_RING);
        in.putExtra("label", label);
        in.putExtra("trigger", triggerAt);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(ctx, (int) (triggerAt % 100000), in, flags);
    }

    /** Jadwalkan ulang semua alarm tersimpan (dipanggil setelah reboot). */
    public static void rescheduleAll(Context ctx) {
        try {
            long now = System.currentTimeMillis();
            for (String x : Prefs.alarms(ctx)) {
                String[] p = x.split("\\|", 2);
                long t = Long.parseLong(p[0]);
                if (t > now) schedule(ctx, t, p.length > 1 ? p[1] : "Alarm");
                else Prefs.removeAlarm(ctx, t);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!ACT_RING.equals(intent.getAction())) return;
        final Context ctx = context.getApplicationContext();
        final String label = intent.getStringExtra("label");
        final long trigger = intent.getLongExtra("trigger", 0);
        Prefs.removeAlarm(ctx, trigger);
        ring(ctx, label != null ? label : "Alarm");
    }

    /** Bunyikan alarm berulang. */
    public static synchronized void ring(final Context ctx, final String label) {
        ring(ctx, label, true);
    }

    /** @param notifyTelegram kirim pesan Telegram ke owner saat berbunyi */
    public static synchronized void ring(final Context ctx, final String label,
                                         final boolean notifyTelegram) {
        stop();
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            player = new MediaPlayer();
            player.setDataSource(ctx, uri);
            if (Build.VERSION.SDK_INT >= 21) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM).build());
            }
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            player = null;
        }
        // notifikasi agar terlihat
        try {
            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH, "Alarm",
                        NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(ctx, CH)
                    : new Notification.Builder(ctx);
            b.setContentTitle("\u23F0 Alarm: " + label)
                    .setContentText("Kirim /berhenti ke bot untuk mematikan.")
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setOngoing(true);
            nm.notify(9001, b.build());
        } catch (Exception ignored) {
        }
        // kabari owner via Telegram
        if (notifyTelegram) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        TelegramApi.sendMessage(Prefs.token(ctx), Prefs.ownerId(ctx),
                                "\u23F0\u23F0 Alarm berbunyi di [" + Prefs.deviceId(ctx) + "]: "
                                        + label + "\nKirim /berhenti untuk mematikan.",
                                null);
                    } catch (Exception ignored) {
                    }
                }
            }).start();
        }
    }

    /** @return true jika nada alarm sedang berbunyi. */
    public static synchronized boolean isRinging() {
        try {
            return player != null && player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    /** Hentikan bunyi alarm (dipanggil dari /berhenti). */
    public static synchronized void stop() {
        try {
            if (player != null) {
                try {
                    player.stop();
                } catch (Exception ignored) {
                }
                try {
                    player.release();
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        player = null;
    }

    /** Tutup juga notifikasinya. */
    public static void dismissNotif(Context ctx) {
        try {
            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel(9001);
        } catch (Exception ignored) {
        }
    }
}
