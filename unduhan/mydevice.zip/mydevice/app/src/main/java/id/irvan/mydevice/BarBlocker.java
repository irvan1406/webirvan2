package id.irvan.mydevice;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/**
 * Menghalangi status bar / notification shade dibuka saat perangkat dikunci.
 * Caranya: overlay transparan di tepi atas layar yang menelan semua sentuhan,
 * sehingga swipe-down tidak pernah sampai ke sistem.
 * Butuh izin "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW).
 */
public class BarBlocker {

    private static View blockerView = null;

    public static boolean canDrawOverlays(Context c) {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            return Settings.canDrawOverlays(c);
        } catch (Exception e) {
            return false;
        }
    }

    /** Tampilkan penghalang. Aman dipanggil berulang. */
    public static synchronized void show(Context c) {
        if (blockerView != null) return;
        if (!canDrawOverlays(c)) return;
        try {
            final Context app = c.getApplicationContext();
            WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
            View v = new View(app);
            // transparan, tapi menelan sentuhan
            v.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return true;
                }
            });
            int h = (int) (120 * app.getResources().getDisplayMetrics().density);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    h,
                    Build.VERSION.SDK_INT >= 26
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_SYSTEM_ERROR,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSPARENT);
            lp.gravity = Gravity.TOP;
            wm.addView(v, lp);
            blockerView = v;
        } catch (Exception ignored) {
        }
    }

    /** Sembunyikan penghalang. */
    public static synchronized void hide(Context c) {
        if (blockerView == null) return;
        try {
            WindowManager wm = (WindowManager) c.getApplicationContext()
                    .getSystemService(Context.WINDOW_SERVICE);
            wm.removeView(blockerView);
        } catch (Exception ignored) {
        }
        blockerView = null;
    }
}
