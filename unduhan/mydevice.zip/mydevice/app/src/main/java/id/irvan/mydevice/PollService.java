package id.irvan.mydevice;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/** Foreground service: polling Bot API Telegram & eksekusi perintah. */
public class PollService extends Service {

    private static final int NOTIF_ID = 1001;
    private static final String CH = "mydevice_svc";

    /** chatId -> aksi yang menunggu input teks lanjutan. */
    public static final Map<Long, String> pending = new HashMap<>();

    private volatile boolean running = false;
    private Thread worker;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "My Device",
                    NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH)
                : new Notification.Builder(this);
        b.setContentTitle("My Device")
                .setContentText("Menghubungkan ke Telegram...")
                .setSmallIcon(android.R.drawable.ic_dialog_info);
        startForeground(NOTIF_ID, b.build());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) {
            running = true;
            worker = new Thread(new Runnable() {
                @Override
                public void run() {
                    loop();
                }
            });
            worker.start();
            // umumkan kehadiran + ID unik ke owner
            final PollService self = this;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(4000);
                        TelegramApi.sendMessage(Prefs.token(self), Prefs.ownerId(self),
                                "\uD83D\uDCF1 [" + Prefs.deviceId(self).toUpperCase()
                                        + "] online \u2014 siap dikontrol.",
                                null);
                    } catch (Exception ignored) {
                    }
                }
            }).start();
        }
        return START_STICKY;
    }

    private void loop() {
        long offset = 0;
        final PollService self = this;
        while (running) {
            try {
                String token = Prefs.token(self);
                if (token == null || token.isEmpty() || token.contains("ISI_")) {
                    Thread.sleep(10000);
                    continue;
                }
                JSONObject res = TelegramApi.getUpdates(token, offset);
                JSONArray arr = res.getJSONArray("result");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject upd = arr.getJSONObject(i);
                    offset = upd.getLong("update_id") + 1;
                    handleUpdate(upd);
                }
            } catch (Exception e) {
                // 409 = ada poller lain (mis. bot Termux masih jalan) -> tunggu lebih lama
                try {
                    Thread.sleep(e.getMessage() != null && e.getMessage().contains("409")
                            ? 30000 : 5000);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    private void handleUpdate(JSONObject upd) {
        try {
            final String token = Prefs.token(this);
            final long owner = Prefs.ownerId(this);

            if (upd.has("callback_query")) {
                JSONObject cb = upd.getJSONObject("callback_query");
                TelegramApi.answerCallback(token, cb.getString("id"));
                JSONObject cm = cb.optJSONObject("message");
                if (cm == null) return;
                long chatId = cm.getJSONObject("chat").getLong("id");
                if (chatId != owner) return;
                long msgId = cm.optLong("message_id", 0);
                Commands.handleCallback(this, chatId, msgId, cb.optString("data", ""));
                return;
            }

            if (!upd.has("message")) return;
            JSONObject msg = upd.getJSONObject("message");
            long chatId = msg.getJSONObject("chat").getLong("id");
            if (chatId != owner) return;

            // forward untuk /notifchat: pisahkan notifikasi ke channel/grup sendiri
            String pv0 = pending.get(chatId);
            if (pv0 != null && pv0.endsWith(":notifchat") && msg.has("forward_from_chat")) {
                try {
                    long fid = msg.getJSONObject("forward_from_chat").getLong("id");
                    String tgt0 = pv0.substring(0, pv0.length() - ":notifchat".length());
                    Prefs.setNotifChatId(this, fid);
                    pending.remove(chatId);
                    Commands.dispatchTarget = tgt0;
                    Commands.sayPlain(this, chatId,
                            "\uD83D\uDD14 Notifikasi proaktif [" + tgt0 + "] akan dikirim ke channel/grup itu. Punya folder sendiri ✅");
                } catch (Exception ignored) {
                }
                return;
            }

            // foto masuk -> jadikan wallpaper (target pending, atau perangkat pertama)
            if (msg.has("photo")) {
                if (!Prefs.isMenuServer(this)) return;
                JSONArray photos = msg.getJSONArray("photo");
                JSONObject biggest = photos.getJSONObject(photos.length() - 1);
                String tgt = Prefs.firstDevice(this);
                String pv = pending.get(chatId);
                if (pv != null && pv.endsWith(":wallpaper")) {
                    tgt = pv.substring(0, pv.length() - ":wallpaper".length());
                    pending.remove(chatId);
                }
                Commands.dispatchTarget = tgt;
                if (pv != null) {
                    Commands.handleIncomingPhoto(this, chatId, tgt,
                            biggest.getString("file_id"));
                } else {
                    Commands.handleIncomingPhotoShow(this, chatId, tgt,
                            biggest.getString("file_id"));
                }
                return;
            }

            // voice note masuk -> HP hilang? putar di HP itu : mode suara? : auto-play
            if (msg.has("voice")) {
                String ht = Prefs.hilangTarget(this);
                if (ht != null) {
                    if (!ht.equals(Prefs.deviceId(this))) return; // HP lain yg hilang, diam
                    JSONObject v = msg.getJSONObject("voice");
                    Commands.dispatchTarget = ht;
                    Commands.handleIncomingVoice(this, chatId, ht,
                            v.getString("file_id"), true);
                    return;
                }
                if (!Prefs.isMenuServer(this)) return;
                JSONObject v = msg.getJSONObject("voice");
                String tgt = Prefs.firstDevice(this);
                Commands.dispatchTarget = tgt;
                if (Prefs.voiceMode(this, chatId)) {
                    VoiceCmd.handleVoiceCommand(this, chatId, tgt, v.getString("file_id"));
                    return;
                }
                Commands.handleIncomingVoice(this, chatId, tgt,
                        v.getString("file_id"), true);
                return;
            }

            // audio masuk -> HP hilang? putar di HP itu : auto-play di HP + kunci total
            if (msg.has("audio")) {
                String ht = Prefs.hilangTarget(this);
                if (ht != null) {
                    if (!ht.equals(Prefs.deviceId(this))) return; // HP lain yg hilang, diam
                    JSONObject a = msg.getJSONObject("audio");
                    Commands.dispatchTarget = ht;
                    Commands.handleIncomingVoice(this, chatId, ht,
                            a.getString("file_id"), false);
                    return;
                }
                if (!Prefs.isMenuServer(this)) return;
                JSONObject a = msg.getJSONObject("audio");
                String tgt = Prefs.firstDevice(this);
                Commands.dispatchTarget = tgt;
                Commands.handleIncomingVoice(this, chatId, tgt,
                        a.getString("file_id"), false);
                return;
            }

            // video masuk -> auto-play fullscreen di HP + kunci total
            if (msg.has("video")) {
                if (!Prefs.isMenuServer(this)) return;
                JSONObject vd = msg.getJSONObject("video");
                String tgt = Prefs.firstDevice(this);
                Commands.dispatchTarget = tgt;
                Commands.handleIncomingVideo(this, chatId, tgt,
                        vd.getString("file_id"));
                return;
            }

            String text = msg.optString("text", "");
            if (text == null) text = "";
            String t = text.trim();

            // Mode HP hilang: pemilik me-reply pesan penemu -> tampil di layar kunci
            if (HilangMode.active && msg.has("reply_to_message") && !t.isEmpty()
                    && !t.startsWith("/")) {
                try {
                    JSONObject rpl = msg.getJSONObject("reply_to_message");
                    JSONObject rfrom = rpl.optJSONObject("from");
                    String rtext = rpl.optString("text", "");
                    if (rfrom != null && rfrom.optBoolean("is_bot", false)
                            && rtext.startsWith("\uD83D\uDCAC Pesan dari penemu HP")) {
                        HilangMode.onOwnerReply(this, t);
                        return;
                    }
                } catch (Exception ignored) {
                }
            }

            // pengumuman online dari HP: menu-server peringatkan jika ID belum terdaftar
            if (t.startsWith("\uD83D\uDCF1 [") && t.contains("] online") && Prefs.isMenuServer(this)) {
                try {
                    String announced = t.substring(4, t.indexOf(']')).trim().toLowerCase();
                    if (!announced.isEmpty() && !Prefs.deviceList(this).contains(announced)) {
                        Commands.sayPlain(this, chatId, "⚠️ ID [" + announced.toUpperCase()
                                + "] belum terdaftar — HP itu tidak akan muncul di /menu.\nBuat ID via /menu → ➕ Buat ID baru, lalu masukkan di aplikasi HP itu.");
                    }
                } catch (Exception ignored) {
                }
                return;
            }

            boolean isCmd = t.startsWith("/");
            if (!isCmd) {
                // "idperangkat: ..." hanya perintah jika id-nya dikenal
                java.util.regex.Matcher mm = java.util.regex.Pattern
                        .compile("^([A-Za-z0-9_\\-]+)\\s*:.*$", java.util.regex.Pattern.DOTALL)
                        .matcher(t);
                if (mm.matches() && Prefs.knownTarget(this, mm.group(1))) isCmd = true;
            }
            if (isCmd) {
                Commands.handleText(this, chatId, text);
            } else if (Commands.speakMode.containsKey(chatId)) {
                // mode ngomong: teks polos langsung diucapkan
                String tgt = Commands.speakMode.get(chatId);
                if (tgt != null && Commands.forMe(this, tgt)) {
                    Commands.dispatchTarget = tgt;
                    Commands.speakText(this, chatId, tgt, t);
                }
            } else if (pending.containsKey(chatId)) {
                String v = pending.remove(chatId); // "target:aksi"
                int i = v.indexOf(':');
                if (i > 0) {
                    Commands.handlePending(this, chatId,
                            v.substring(0, i), v.substring(i + 1), text);
                }
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
