package id.irvan.mydevice;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Integrasi YouTube / YouTube ReVanced:
 * cari video (via API publik youtubei), putar di aplikasi, kontrol putar/menit/skip/stop.
 */
public class YouTube {

    public static final String PKG_STOCK = "com.google.android.youtube";
    public static final String PKG_REVANCED = "app.revanced.android.youtube";

    /** Kunci API publik milik klien web YouTube (sama yang dipakai youtube.com). */
    private static final String YT_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";

    public static class Video {
        public String id;
        public String title;
        public String channel;
        /** durasi teks "12:34", "LIVE", atau "-". */
        public String durText;
        /** durasi detik, -1 jika live/tak diketahui. */
        public int durSec = -1;
    }

    /** Daftar aplikasi YouTube yang terinstal (stock dan/atau ReVanced). */
    public static List<String> installedApps(Context ctx) {
        List<String> out = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();
        for (String pkg : new String[]{PKG_REVANCED, PKG_STOCK}) {
            try {
                pm.getPackageInfo(pkg, 0);
                out.add(pkg);
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    public static String appLabel(String pkg) {
        return PKG_REVANCED.equals(pkg) ? "ReVanced" : "YouTube";
    }

    /**
     * Cari video via youtubei (tanpa API key pribadi).
     *
     * @throws Exception jika gagal (jaringan/diblokir).
     */
    public static List<Video> search(String query) throws Exception {
        List<Video> out = new ArrayList<>();
        String endpoint = "https://www.youtube.com/youtubei/v1/search?key=" + YT_API_KEY
                + "&prettyPrint=false";
        JSONObject body = new JSONObject();
        JSONObject client = new JSONObject();
        client.put("clientName", "WEB");
        client.put("clientVersion", "2.20240101.00.00");
        client.put("hl", "id");
        client.put("gl", "ID");
        JSONObject context = new JSONObject();
        context.put("client", client);
        body.put("context", context);
        body.put("query", query);

        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
                        + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        byte[] payload = body.toString().getBytes("UTF-8");
        OutputStream os = conn.getOutputStream();
        os.write(payload);
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        if (code != 200) throw new Exception("HTTP " + code);
        BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();

        JSONObject root = new JSONObject(sb.toString());
        JSONArray sections = root.getJSONObject("contents")
                .getJSONObject("twoColumnSearchResultsRenderer")
                .getJSONObject("primaryContents")
                .getJSONObject("sectionListRenderer")
                .getJSONArray("contents");
        for (int i = 0; i < sections.length() && out.size() < 10; i++) {
            JSONObject sec = sections.getJSONObject(i);
            if (!sec.has("itemSectionRenderer")) continue;
            JSONArray items = sec.getJSONObject("itemSectionRenderer").getJSONArray("contents");
            for (int j = 0; j < items.length() && out.size() < 10; j++) {
                JSONObject it = items.getJSONObject(j);
                if (!it.has("videoRenderer")) continue;
                JSONObject vr = it.getJSONObject("videoRenderer");
                Video v = new Video();
                v.id = vr.optString("videoId", "");
                if (v.id.isEmpty()) continue;
                v.title = runsText(vr.optJSONObject("title"));
                v.channel = runsText(vr.optJSONObject("ownerText"));
                JSONObject lt = vr.optJSONObject("lengthText");
                if (lt != null) {
                    v.durText = lt.optString("simpleText", "-");
                    v.durSec = parseDur(v.durText);
                } else if (vr.optJSONArray("badges") != null) {
                    v.durText = "LIVE";
                } else {
                    v.durText = "-";
                }
                if (v.title == null || v.title.isEmpty()) v.title = "(tanpa judul)";
                out.add(v);
            }
        }
        return out;
    }

    private static String runsText(JSONObject o) {
        try {
            if (o == null) return "";
            JSONArray runs = o.getJSONArray("runs");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < runs.length(); i++) {
                sb.append(runs.getJSONObject(i).optString("text", ""));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Video terkait / "up next" untuk sebuah video (untuk daftar putar lanjutan).
     *
     * @throws Exception jika gagal.
     */
    public static List<Video> related(String videoId) throws Exception {
        List<Video> out = new ArrayList<>();
        String endpoint = "https://www.youtube.com/youtubei/v1/next?key=" + YT_API_KEY
                + "&prettyPrint=false";
        JSONObject body = new JSONObject();
        JSONObject client = new JSONObject();
        client.put("clientName", "WEB");
        client.put("clientVersion", "2.20240101.00.00");
        client.put("hl", "id");
        client.put("gl", "ID");
        JSONObject context = new JSONObject();
        context.put("client", client);
        body.put("context", context);
        body.put("videoId", videoId);

        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
                        + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        byte[] payload = body.toString().getBytes("UTF-8");
        OutputStream os = conn.getOutputStream();
        os.write(payload);
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        if (code != 200) throw new Exception("HTTP " + code);
        BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();

        JSONObject root = new JSONObject(sb.toString());
        JSONArray results = root.getJSONObject("contents")
                .getJSONObject("twoColumnWatchNextResults")
                .getJSONObject("secondaryResults")
                .getJSONObject("secondaryResults")
                .getJSONArray("results");
        for (int i = 0; i < results.length() && out.size() < 10; i++) {
            JSONObject r = results.getJSONObject(i);
            if (!r.has("compactVideoRenderer")) continue;
            JSONObject vr = r.getJSONObject("compactVideoRenderer");
            Video v = new Video();
            v.id = vr.optString("videoId", "");
            if (v.id.isEmpty()) continue;
            v.title = runsText(vr.optJSONObject("title"));
            v.channel = runsText(vr.optJSONObject("shortBylineText"));
            JSONObject lt = vr.optJSONObject("lengthText");
            if (lt != null) {
                v.durText = lt.optString("simpleText", "-");
                v.durSec = parseDur(v.durText);
            } else {
                v.durText = "LIVE";
            }
            if (v.title == null || v.title.isEmpty()) v.title = "(tanpa judul)";
            out.add(v);
        }
        return out;
    }

    /** "12:34" -> 754, "1:02:03" -> 3723, else -1. */
    public static int parseDur(String t) {
        try {
            String[] p = t.split(":");
            int s = 0;
            for (String x : p) s = s * 60 + Integer.parseInt(x.trim());
            return s;
        } catch (Exception e) {
            return -1;
        }
    }

    /** "1:30" / "90" / "1m30s" -> detik. */
    public static int parseMenit(String in) {
        try {
            in = in.trim().toLowerCase().replace(" ", "");
            if (in.contains(":")) {
                return parseDur(in);
            }
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?:(\\d+)m)?(?:(\\d+)s?)?").matcher(in);
            if (m.matches()) {
                int total = 0;
                boolean any = false;
                if (m.group(1) != null) {
                    total += Integer.parseInt(m.group(1)) * 60;
                    any = true;
                }
                if (m.group(2) != null) {
                    total += Integer.parseInt(m.group(2));
                    any = true;
                }
                if (any) return total;
            }
            return Integer.parseInt(in);
        } catch (Exception e) {
            return -1;
        }
    }

    public static String fmtDur(int sec) {
        if (sec < 0) return "-";
        int h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return h + ":" + String.format("%02d", m) + ":" + String.format("%02d", s);
        return m + ":" + String.format("%02d", s);
    }

    /** Putar video di aplikasi YouTube/ReVanced, mulai dari detik startSec. */
    public static boolean play(Context ctx, String pkg, String videoId, int startSec) {
        try {
            String url = "https://www.youtube.com/watch?v=" + videoId
                    + (startSec > 0 ? "&t=" + startSec : "");
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage(pkg);
            return AppLockService.launchIntent(i);
        } catch (Exception e) {
            return false;
        }
    }

    /** Buka halaman hasil pencarian di aplikasi (fallback manual). */
    public static boolean openSearch(Context ctx, String pkg, String query) {
        try {
            String url = "https://www.youtube.com/results?search_query=" + Uri.encode(query);
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.setPackage(pkg);
            return AppLockService.launchIntent(i);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Kirim tombol media (play/pause/stop) ke sesi media yang sedang aktif.
     * Ini cara yang benar untuk menghentikan ReVanced/YouTube yang sedang
     * background-play (foreground service tidak mempan di-kill).
     */
    public static boolean mediaKey(Context ctx, int keyCode) {
        try {
            android.media.AudioManager am =
                    (android.media.AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            long now = android.os.SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(now, now,
                    android.view.KeyEvent.ACTION_DOWN, keyCode, 0));
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(now, now,
                    android.view.KeyEvent.ACTION_UP, keyCode, 0));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Jeda pemutaran. */
    public static boolean pause(Context ctx) {
        return mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE);
    }

    /** Lanjutkan pemutaran. */
    public static boolean resume(Context ctx) {
        return mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_PLAY);
    }

    /** Hentikan pemutaran: kirim MEDIA_STOP, lalu home + kill sebagai bersih-bersih. */
    public static void stop(Context ctx, String pkg) {
        try {
            mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_STOP);
        } catch (Exception ignored) {
        }
        try {
            Thread.sleep(400);
        } catch (InterruptedException ignored) {
        }
        try {
            AppLockService.navAction("home");
        } catch (Exception ignored) {
        }
        try {
            Thread.sleep(600);
        } catch (InterruptedException ignored) {
        }
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            am.killBackgroundProcesses(pkg);
        } catch (Exception ignored) {
        }
    }
}
