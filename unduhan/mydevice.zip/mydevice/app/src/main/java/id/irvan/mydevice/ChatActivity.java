package id.irvan.mydevice;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Chat dua arah: menampilkan pesan dari owner + kolom balasan.
 * Dibuka via perintah Telegram /pesan <teks>.
 */
public class ChatActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        String pesan = getIntent().getStringExtra("text");
        if (pesan == null) pesan = "";
        String waktu;
        try {
            waktu = new SimpleDateFormat("HH:mm, d MMM", new Locale("id")).format(new Date());
        } catch (Exception e) {
            waktu = "";
        }

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0B1220"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 64, 48, 64);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("\uD83D\uDCAC Pesan masuk");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("dari Owner • " + waktu + " • " + Prefs.deviceId(this));
        sub.setTextColor(Color.parseColor("#64748B"));
        sub.setTextSize(13);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.bottomMargin = 32;
        root.addView(sub, slp);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setPadding(36, 28, 36, 28);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1E293B"));
        bg.setCornerRadius(32);
        bubble.setBackground(bg);
        TextView isi = new TextView(this);
        isi.setText(pesan);
        isi.setTextColor(Color.WHITE);
        isi.setTextSize(18);
        bubble.addView(isi);
        root.addView(bubble);

        final EditText etBalas = new EditText(this);
        etBalas.setHint("Tulis balasan...");
        etBalas.setHintTextColor(Color.parseColor("#64748B"));
        etBalas.setTextColor(Color.WHITE);
        etBalas.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etBalas.setMinLines(2);
        GradientDrawable ebg = new GradientDrawable();
        ebg.setColor(Color.parseColor("#151F32"));
        ebg.setCornerRadius(24);
        ebg.setStroke(2, Color.parseColor("#334155"));
        etBalas.setBackground(ebg);
        etBalas.setPadding(32, 24, 32, 24);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        elp.topMargin = 32;
        root.addView(etBalas, elp);

        Button kirim = new Button(this);
        kirim.setText("Kirim balasan");
        kirim.setTextColor(Color.WHITE);
        kirim.setTextSize(16);
        GradientDrawable kbg = new GradientDrawable();
        kbg.setColor(Color.parseColor("#0284C7"));
        kbg.setCornerRadius(24);
        kirim.setBackground(kbg);
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        klp.topMargin = 20;
        root.addView(kirim, klp);

        kirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String balasan = etBalas.getText().toString().trim();
                if (balasan.isEmpty()) {
                    Toast.makeText(ChatActivity.this, "Balasan kosong", Toast.LENGTH_SHORT).show();
                    return;
                }
                final String teks = "\uD83D\uDCAC [" + Prefs.deviceId(ChatActivity.this) + "]: " + balasan;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            TelegramApi.sendMessage(Prefs.token(ChatActivity.this),
                                    Prefs.ownerId(ChatActivity.this), teks, null);
                        } catch (Exception ignored) {
                        }
                    }
                }).start();
                Toast.makeText(ChatActivity.this, "Balasan terkirim", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        setContentView(sv);
    }
}
