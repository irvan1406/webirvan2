package id.irvan.mydevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;

/**
 * Notifikasi proaktif: SMS masuk & baterai lemah diteruskan ke Telegram.
 * Aktif hanya jika user mengaktifkan via /notif.
 */
public class NotifReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent.getAction();
        if (a == null) return;
        try {
            if ("android.provider.Telephony.SMS_RECEIVED".equals(a)) {
                if (!Prefs.notifOn(context) || !Prefs.notifSms(context)) return;
                StringBuilder sb = new StringBuilder();
                Bundle b = intent.getExtras();
                if (b == null) return;
                Object[] pdus = (Object[]) b.get("pdus");
                String format = b.getString("format");
                if (pdus == null) return;
                String sender = "";
                for (Object pdu : pdus) {
                    SmsMessage m;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        m = SmsMessage.createFromPdu((byte[]) pdu, format);
                    } else {
                        m = SmsMessage.createFromPdu((byte[]) pdu);
                    }
                    if (m == null) continue;
                    sender = m.getOriginatingAddress();
                    sb.append(m.getMessageBody());
                }
                final String text = "📩 SMS masuk [" + Prefs.deviceId(context) + "]\nDari: "
                        + sender + "\n" + sb.toString();
                sendNotif(context, text);
            } else if (Intent.ACTION_BATTERY_LOW.equals(a)) {
                if (!Prefs.notifOn(context) || !Prefs.notifBatt(context)) return;
                sendNotif(context, "🔋 Baterai HP [" + Prefs.deviceId(context) + "] lemah!");
            }
        } catch (Exception ignored) {
        }
    }

    /** Kirim notifikasi ke chat notifikasi (atau chat owner bila belum diatur). */
    public static void sendNotif(final Context ctx, final String text) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long chat = Prefs.notifChatId(ctx);
                    if (chat == 0) chat = Prefs.ownerId(ctx);
                    if (chat == 0) return;
                    TelegramApi.sendMessage(Prefs.token(ctx), chat, "🔔 " + text, null);
                } catch (Exception ignored) {
                }
            }
        }).start();
    }
}
