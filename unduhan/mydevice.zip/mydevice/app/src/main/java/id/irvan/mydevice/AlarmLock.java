package id.irvan.mydevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;

/**
 * Mode "HP hilang": saat /bunyi (atau /findmy) berdering, volume dikunci
 * maksimal dan taskbar diblokir. Tombol volume hardware sudah ditelan oleh
 * aksesibilitas (AppLockService.onKeyEvent); receiver ini mengembalikan volume
 * yang diubah lewat slider/pengaturan. Menu daya sistem yang muncul ikut
 * ditutup oleh aksesibilitas. Hanya /berhenti dari Telegram yang melepasnya.
 */
public class AlarmLock {

    private static volatile boolean enforcing = false;
    private static BroadcastReceiver volGuard = null;

    public static boolean isEnforcing() {
        return enforcing;
    }

    public static synchronized void on(Context ctx) {
        enforcing = true;
        try {
            BarBlocker.show(ctx);
        } catch (Exception ignored) {
        }
        maxAll(ctx);
        if (volGuard == null) {
            volGuard = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    if (enforcing) maxAll(c);
                }
            };
            try {
                ctx.getApplicationContext().registerReceiver(volGuard,
                        new IntentFilter("android.media.VOLUME_CHANGED_ACTION"));
            } catch (Exception ignored) {
                volGuard = null;
            }
        }
    }

    public static synchronized void off(Context ctx) {
        enforcing = false;
        try {
            BarBlocker.hide(ctx);
        } catch (Exception ignored) {
        }
        if (volGuard != null) {
            try {
                ctx.getApplicationContext().unregisterReceiver(volGuard);
            } catch (Exception ignored) {
            }
            volGuard = null;
        }
    }

    private static void maxAll(Context ctx) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            int[] streams = {
                    AudioManager.STREAM_ALARM,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.STREAM_RING,
                    AudioManager.STREAM_NOTIFICATION
            };
            for (int s : streams) {
                try {
                    am.setStreamVolume(s, am.getStreamMaxVolume(s), 0);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }
}
