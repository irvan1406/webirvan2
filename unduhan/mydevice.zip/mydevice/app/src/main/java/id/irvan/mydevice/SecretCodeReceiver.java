package id.irvan.mydevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Kode rahasia dialer untuk membuka aplikasi saat ikon disembunyikan.
 * Tekan *#*#5656#*#* di aplikasi Telepon.
 */
public class SecretCodeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent i = new Intent(context, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            context.startActivity(i);
        } catch (Exception ignored) {
        }
    }
}
