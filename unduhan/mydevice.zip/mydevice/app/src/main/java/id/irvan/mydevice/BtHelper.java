package id.irvan.mydevice;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Pindai perangkat Bluetooth di sekitar (/bton otomatis memindai, /btscan),
 * tampilkan sebagai tombol, pasangkan + coba sambungkan audio otomatis.
 *
 * Batasan jujur: Android modern mewajibkan konfirmasi pairing di layar HP
 * untuk aplikasi biasa. Kami (1) mencoba setPairingConfirmation (berhasil di
 * sebagian HP), dan (2) menyalakan auto-klik aksesibilitas selama 2 menit
 * yang menekan tombol "Pasangkan" pada dialog pairing bila muncul.
 */
public class BtHelper {

    private static volatile boolean scanning = false;
    private static BroadcastReceiver scanRx = null;
    private static final Map<String, String> found = new LinkedHashMap<>();
    private static long scanChatId;
    private static String scanTarget;

    private static BroadcastReceiver pairRx = null;
    private static String pendingMac = null;
    private static long pairChatId;
    private static String pairTarget;

    public static boolean isScanning() {
        return scanning;
    }

    private static boolean hasScanPerm(Context ctx) {
        if (Build.VERSION.SDK_INT >= 31) {
            return ctx.checkSelfPermission("android.permission.BLUETOOTH_SCAN")
                    == android.content.pm.PackageManager.PERMISSION_GRANTED
                    && ctx.checkSelfPermission("android.permission.BLUETOOTH_CONNECT")
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private static String devName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return (n == null || n.isEmpty()) ? "(tanpa nama)" : n;
        } catch (Exception e) {
            return "(tanpa nama)";
        }
    }

    /** Mulai pemindaian perangkat sekitar. */
    @SuppressLint("MissingPermission")
    public static synchronized void scan(final Context ctx, final long chatId, final String target) {
        if (scanning) {
            Commands.replyT(ctx, chatId, target, "Masih memindai — tunggu sebentar.");
            return;
        }
        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        if (ba == null) {
            Commands.replyT(ctx, chatId, target, "HP ini tidak punya Bluetooth.");
            return;
        }
        if (!ba.isEnabled()) {
            Commands.replyT(ctx, chatId, target, "Bluetooth mati. Kirim /bton dulu.");
            return;
        }
        if (!hasScanPerm(ctx)) {
            Commands.replyT(ctx, chatId, target,
                    "Izin Bluetooth (pindai) belum diberikan.\nBuka aplikasi My Device > Aktifkan > Izin aplikasi, lalu /btscan lagi.");
            return;
        }
        scanning = true;
        found.clear();
        scanChatId = chatId;
        scanTarget = target;
        final Context app = ctx.getApplicationContext();

        scanRx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(a)) {
                    try {
                        BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        if (d != null && d.getAddress() != null) {
                            found.put(d.getAddress(), devName(d));
                        }
                    } catch (Exception ignored) {
                    }
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(a)) {
                    finishScan(app);
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        try {
            app.registerReceiver(scanRx, f);
        } catch (Exception e) {
            scanning = false;
            Commands.replyT(ctx, chatId, target, "Gagal memulai pemindaian.");
            return;
        }
        try {
            if (ba.isDiscovering()) ba.cancelDiscovery();
        } catch (Exception ignored) {
        }
        boolean ok = false;
        try {
            ok = ba.startDiscovery();
        } catch (Exception ignored) {
        }
        if (!ok) {
            finishScan(app);
            return;
        }
        Commands.replyT(ctx, chatId, target,
                "🔍 Memindai perangkat Bluetooth di sekitar (±15 detik)...");
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                finishScan(app);
            }
        }, 20000);
    }

    private static synchronized void finishScan(Context appCtx) {
        if (!scanning) return;
        scanning = false;
        try {
            BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
        } catch (Exception ignored) {
        }
        if (scanRx != null) {
            try {
                appCtx.unregisterReceiver(scanRx);
            } catch (Exception ignored) {
            }
            scanRx = null;
        }
        if (found.isEmpty()) {
            Commands.replyT(appCtx, scanChatId, scanTarget,
                    "Tidak ketemu perangkat Bluetooth.\nPastikan perangkatnya dalam mode pairing & Lokasi HP menyala, lalu /btscan lagi.");
            return;
        }
        String[][] items = new String[found.size()][];
        int k = 0;
        for (Map.Entry<String, String> e : found.entrySet()) {
            items[k++] = new String[]{e.getValue() + "\n" + e.getKey(), "btpair:" + e.getKey()};
        }
        JSONObject kb = Commands.buildMenuKb(appCtx, scanTarget, items, null, 1);
        try {
            TelegramApi.sendMessage(Prefs.token(appCtx), scanChatId,
                    "📶 Ketuk perangkat untuk dipasangkan & disambungkan:",
                    kb);
        } catch (Exception ignored) {
        }
    }

    /** Pasangkan dengan perangkat pilihan + coba sambungkan audio. */
    @SuppressLint("MissingPermission")
    public static synchronized void pair(final Context ctx, final long chatId,
                                         final String target, final String mac) {
        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        if (ba == null || !ba.isEnabled()) {
            Commands.replyT(ctx, chatId, target, "Bluetooth tidak aktif.");
            return;
        }
        final BluetoothDevice dev;
        try {
            dev = ba.getRemoteDevice(mac);
        } catch (Exception e) {
            Commands.replyT(ctx, chatId, target, "Alamat perangkat tidak valid.");
            return;
        }
        ensurePairReceiver(ctx.getApplicationContext());
        if (dev.getBondState() == BluetoothDevice.BOND_BONDED) {
            Commands.replyT(ctx, chatId, target,
                    "Sudah dipasangkan: " + devName(dev) + "\nMencoba menyambungkan audio...");
            connectA2dp(ctx, chatId, target, dev);
            return;
        }
        pendingMac = mac;
        pairChatId = chatId;
        pairTarget = target;
        // izinkan auto-klik dialog pairing via aksesibilitas selama 2 menit
        AppLockService.btAutoAcceptUntil = System.currentTimeMillis() + 120000;
        boolean ok = false;
        try {
            ok = dev.createBond();
        } catch (Exception ignored) {
        }
        Commands.replyT(ctx, chatId, target, ok
                ? "🔗 Memasangkan dengan " + devName(dev) + "...\nDialog konfirmasi di HP akan diterima otomatis bila muncul."
                : "Gagal memulai pairing dengan " + devName(dev) + ".");
    }

    private static synchronized void ensurePairReceiver(final Context app) {
        if (pairRx != null) return;
        pairRx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                try {
                    if (BluetoothDevice.ACTION_PAIRING_REQUEST.equals(a)) {
                        BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        // Coba terima otomatis (butuh hak sistem di Android baru;
                        // gagal -> andalkan auto-klik aksesibilitas).
                        try {
                            if (d != null) d.setPairingConfirmation(true);
                        } catch (Exception ignored) {
                        }
                    } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(a)) {
                        BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                        int st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE,
                                BluetoothDevice.BOND_NONE);
                        if (d == null || pendingMac == null
                                || !pendingMac.equalsIgnoreCase(d.getAddress())) return;
                        if (st == BluetoothDevice.BOND_BONDED) {
                            pendingMac = null;
                            Commands.replyT(c, pairChatId, pairTarget,
                                    "✅ Dipasangkan: " + devName(d)
                                            + "\nMencoba menyambungkan audio...");
                            connectA2dp(c, pairChatId, pairTarget, d);
                        } else if (st == BluetoothDevice.BOND_NONE) {
                            pendingMac = null;
                            Commands.replyT(c, pairChatId, pairTarget,
                                    "❌ Pairing dengan " + devName(d) + " gagal/dibatalkan.");
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_PAIRING_REQUEST);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        try {
            app.registerReceiver(pairRx, f);
        } catch (Exception ignored) {
            pairRx = null;
        }
    }

    /** Coba sambungkan profil audio (A2DP). Best-effort; headset biasanya otomatis tersambung setelah bond. */
    @SuppressLint("MissingPermission")
    private static void connectA2dp(final Context ctx, final long chatId,
                                    final String target, final BluetoothDevice dev) {
        try {
            BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
            boolean started = ba.getProfileProxy(ctx.getApplicationContext(),
                    new BluetoothProfile.ServiceListener() {
                        @Override
                        public void onServiceConnected(int profile, BluetoothProfile proxy) {
                            boolean sent = false;
                            try {
                                java.lang.reflect.Method m = proxy.getClass()
                                        .getMethod("connect", BluetoothDevice.class);
                                Object r = m.invoke(proxy, dev);
                                sent = Boolean.TRUE.equals(r);
                            } catch (Exception ignored) {
                            }
                            try {
                                BluetoothAdapter.getDefaultAdapter()
                                        .closeProfileProxy(profile, proxy);
                            } catch (Exception ignored) {
                            }
                            Commands.replyT(ctx, chatId, target, sent
                                    ? "🔊 Permintaan sambungan audio dikirim ke " + devName(dev) + "."
                                    : "ℹ️ " + devName(dev)
                                    + " sudah dipasangkan. Sambungan audio biasanya otomatis oleh sistem; bila belum, sambungkan manual sekali di HP itu.");
                        }

                        @Override
                        public void onServiceDisconnected(int profile) {
                        }
                    }, BluetoothProfile.A2DP);
            if (!started) {
                Commands.replyT(ctx, chatId, target,
                        "ℹ️ " + devName(dev) + " sudah dipasangkan. Sambungkan audio manual sekali di HP bila belum tersambung.");
            }
        } catch (Exception e) {
            Commands.replyT(ctx, chatId, target,
                    "ℹ️ " + devName(dev) + " sudah dipasangkan. Sambungkan audio manual sekali di HP bila belum tersambung.");
        }
    }
}
