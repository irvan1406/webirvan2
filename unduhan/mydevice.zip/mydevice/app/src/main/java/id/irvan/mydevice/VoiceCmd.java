package id.irvan.mydevice;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Perintah suara: voice note Telegram -> unduh -> transkrip offline (Vosk,
 * model Bahasa Indonesia diunduh sekali saja) -> eksekusi perintah ->
 * balas dengan pesan suara (TTS).
 *
 * Dipakai saat /modesuara aktif untuk chat tersebut.
 */
public class VoiceCmd {

    private static final String MODEL_URL =
            "https://alphacephei.com/vosk/models/vosk-model-small-id-0.22.zip";

    /** Entry point dari PollService saat voice note masuk dalam mode suara. */
    public static void handleVoiceCommand(final Context ctx, final long chatId,
                                          final String target, final String fileId) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Commands.sayPlain(ctx, chatId, "🎤 Mendengarkan...");
                    // 1. unduh voice note
                    JSONObject f = TelegramApi.getFile(Prefs.token(ctx), fileId);
                    String path = f.getJSONObject("result").getString("file_path");
                    File ogg = new File(ctx.getCacheDir(), "vcmd.ogg");
                    TelegramApi.downloadFile(Prefs.token(ctx), path, ogg);
                    // 2. model suara (unduh sekali saja)
                    File modelDir = ensureModel(ctx, chatId);
                    if (modelDir == null) return;
                    // 3. decode ogg -> PCM 16kHz mono
                    short[] pcm = decodeToPcm16k(ogg);
                    try {
                        ogg.delete();
                    } catch (Exception ignored) {
                    }
                    if (pcm.length < 1600) {
                        replyVoice(ctx, chatId, "Maaf, suaranya terlalu pendek.");
                        return;
                    }
                    // 4. kenali
                    String text = recognize(modelDir, pcm);
                    if (text == null || text.isEmpty()) {
                        replyVoice(ctx, chatId, "Maaf, tidak terdengar jelas. Coba lagi.");
                        return;
                    }
                    Commands.sayPlain(ctx, chatId, "🎤 Kamu bilang: \"" + text + "\"");
                    // 5. eksekusi
                    dispatchVoice(ctx, chatId, target, text);
                } catch (Exception e) {
                    Commands.sayPlain(ctx, chatId,
                            "Gagal proses suara: " + e.getMessage());
                }
            }
        }).start();
    }

    // ---------- model Vosk ----------

    private static File ensureModel(Context ctx, long chatId) {
        File dir = new File(ctx.getFilesDir(), "vosk-model-id");
        if (new File(dir, "am").exists() && new File(dir, "conf").exists()) return dir;
        try {
            Commands.sayPlain(ctx, chatId,
                    "📥 Mengunduh model suara Indonesia (~50MB, sekali saja)...");
            File zip = new File(ctx.getCacheDir(), "vosk-id.zip");
            downloadHttp(MODEL_URL, zip);
            unzip(zip, ctx.getFilesDir());
            try {
                zip.delete();
            } catch (Exception ignored) {
            }
            File src = new File(ctx.getFilesDir(), "vosk-model-small-id-0.22");
            if (src.exists() && !dir.exists()) src.renameTo(dir);
            if (new File(dir, "am").exists()) {
                Commands.sayPlain(ctx, chatId, "✅ Model suara siap.");
                return dir;
            }
        } catch (Exception e) {
            Commands.sayPlain(ctx, chatId, "Gagal unduh model suara: " + e.getMessage());
        }
        return null;
    }

    private static void downloadHttp(String urlStr, File dest) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(30000);
        c.setReadTimeout(120000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0");
        int code = c.getResponseCode();
        if (code / 100 != 2) throw new Exception("HTTP " + code);
        InputStream in = c.getInputStream();
        FileOutputStream fos = new FileOutputStream(dest);
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
        fos.close();
        in.close();
    }

    private static void unzip(File zip, File destDir) throws Exception {
        ZipInputStream zis = new ZipInputStream(new FileInputStream(zip));
        ZipEntry e;
        byte[] buf = new byte[32768];
        String base = destDir.getCanonicalPath();
        while ((e = zis.getNextEntry()) != null) {
            File f = new File(destDir, e.getName());
            if (!f.getCanonicalPath().startsWith(base)) {
                zis.closeEntry();
                continue;
            }
            if (e.isDirectory()) {
                f.mkdirs();
            } else {
                f.getParentFile().mkdirs();
                FileOutputStream fos = new FileOutputStream(f);
                int n;
                while ((n = zis.read(buf)) > 0) fos.write(buf, 0, n);
                fos.close();
            }
            zis.closeEntry();
        }
        zis.close();
    }

    // ---------- decode ogg/opus -> PCM 16kHz mono ----------

    private static short[] decodeToPcm16k(File inFile) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(inFile.getAbsolutePath());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    track = i;
                    fmt = f;
                    break;
                }
            }
            if (track < 0) throw new Exception("tidak ada trek audio");
            ex.selectTrack(track);
            int srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 48000;
            int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
            MediaCodec dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            try {
                dec.configure(fmt, null, null, 0);
                dec.start();
                ByteArrayOutputStream raw = new ByteArrayOutputStream();
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                boolean eos = false;
                int guard = 0;
                while (!eos && guard++ < 4000) {
                    int inIdx = dec.dequeueInputBuffer(10000);
                    if (inIdx >= 0) {
                        ByteBuffer inBuf = dec.getInputBuffer(inIdx);
                        int n = ex.readSampleData(inBuf, 0);
                        if (n < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        } else {
                            dec.queueInputBuffer(inIdx, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                    int outIdx = dec.dequeueOutputBuffer(info, 10000);
                    if (outIdx >= 0) {
                        ByteBuffer outBuf = dec.getOutputBuffer(outIdx);
                        if (info.size > 0 && outBuf != null) {
                            byte[] chunk = new byte[info.size];
                            outBuf.get(chunk);
                            raw.write(chunk);
                        }
                        dec.releaseOutputBuffer(outIdx, false);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eos = true;
                    }
                }
                dec.stop();
                byte[] bytes = raw.toByteArray();
                int nFrames = bytes.length / (2 * ch);
                if (nFrames <= 0) return new short[0];
                short[] mono = new short[nFrames];
                ByteBuffer bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
                for (int i = 0; i < nFrames; i++) {
                    int sum = 0;
                    for (int c = 0; c < ch; c++) sum += bb.getShort();
                    mono[i] = (short) (sum / ch);
                }
                if (srcRate == 16000) return mono;
                double ratio = 16000.0 / srcRate;
                int nOut = Math.max(1, (int) (nFrames * ratio));
                short[] out = new short[nOut];
                for (int i = 0; i < nOut; i++) {
                    double pos = i / ratio;
                    int p0 = (int) pos;
                    int p1 = Math.min(p0 + 1, nFrames - 1);
                    double frac = pos - p0;
                    out[i] = (short) (mono[p0] * (1 - frac) + mono[p1] * frac);
                }
                return out;
            } finally {
                try {
                    dec.release();
                } catch (Exception ignored) {
                }
            }
        } finally {
            try {
                ex.release();
            } catch (Exception ignored) {
            }
        }
    }

    // ---------- pengenalan suara ----------

    private static String recognize(File modelDir, short[] pcm) throws Exception {
        org.vosk.Model model = new org.vosk.Model(modelDir.getAbsolutePath());
        try {
            org.vosk.Recognizer rec = new org.vosk.Recognizer(model, 16000.0f);
            try {
                int off = 0;
                int chunk = 8000;
                while (off < pcm.length) {
                    int n = Math.min(chunk, pcm.length - off);
                    short[] part = new short[n];
                    System.arraycopy(pcm, off, part, 0, n);
                    rec.acceptWaveForm(part, n);
                    off += n;
                }
                String res = rec.getFinalResult();
                return new JSONObject(res).optString("text", "").trim();
            } finally {
                rec.close();
            }
        } finally {
            model.close();
        }
    }

    // ---------- eksekusi perintah ----------

    private static void dispatchVoice(Context ctx, long chatId, String target, String text) {
        String t = text.toLowerCase().trim();
        try {
            if (t.contains("berhenti") || t.contains("stop")) {
                Commands.voiceTubeStop(ctx, chatId);
                replyVoice(ctx, chatId, "YouTube dihentikan.");
                return;
            }
            if (t.contains("jeda") || t.contains("pause") || t.contains("paus")) {
                YouTube.pause(ctx);
                replyVoice(ctx, chatId, "Dijeda.");
                return;
            }
            if (t.contains("lanjut") || t.contains("terus")) {
                YouTube.resume(ctx);
                replyVoice(ctx, chatId, "Dilanjutkan.");
                return;
            }
            if (t.contains("lewat") || t.contains("skip") || t.contains("selanjutnya")
                    || t.contains("loncat")) {
                Commands.voiceTubeSkip(ctx, chatId, target, true);
                replyVoice(ctx, chatId, "Dilewati 30 detik.");
                return;
            }
            if (t.contains("mundur")) {
                Commands.voiceTubeSkip(ctx, chatId, target, false);
                replyVoice(ctx, chatId, "Mundur 30 detik.");
                return;
            }
            String q = afterKeyword(t,
                    new String[]{"putarkan", "puterkan", "putar", "puter", "mainkan", "setel", "setelkan"});
            if (q != null) {
                replyVoice(ctx, chatId, "Mencari " + q);
                Commands.voicePlayFirst(ctx, chatId, target, q);
                return;
            }
            String qs = afterKeyword(t, new String[]{"carikan", "cari"});
            if (qs != null) {
                Commands.voiceSearch(ctx, chatId, target, qs);
                replyVoice(ctx, chatId, "Ini hasil pencarian " + qs);
                return;
            }
            if (t.contains("senter")) {
                boolean on = !TorchHelper.get(ctx).isTorchOn();
                boolean ok = TorchHelper.get(ctx).setTorch(on);
                replyVoice(ctx, chatId, ok ? (on ? "Senter nyala." : "Senter mati.")
                        : "Senter gagal dinyalakan.");
                return;
            }
            if (t.contains("foto") || t.contains("kamera") || t.contains("potret")) {
                Commands.voiceFoto(ctx, chatId, target);
                replyVoice(ctx, chatId, "Mengambil foto.");
                return;
            }
            replyVoice(ctx, chatId,
                    "Perintah tidak dimengerti. Coba: putar judul lagu, jeda, lanjut, lewati, atau berhenti.");
        } catch (Exception e) {
            replyVoice(ctx, chatId, "Gagal menjalankan perintah.");
        }
    }

    private static String afterKeyword(String t, String[] kws) {
        String[] w = t.trim().split("\\s+");
        for (int i = 0; i < w.length; i++) {
            for (String k : kws) {
                if (w[i].equals(k) || w[i].startsWith(k)) {
                    StringBuilder sb = new StringBuilder();
                    for (int j = i + 1; j < w.length; j++) {
                        if (sb.length() > 0) sb.append(' ');
                        sb.append(w[j]);
                    }
                    String r = sb.toString().trim();
                    return r.isEmpty() ? null : r;
                }
            }
        }
        return null;
    }

    // ---------- balasan suara (TTS -> AAC -> Telegram) ----------

    /** Balas dengan pesan suara; fallback ke teks bila TTS/encode gagal. */
    public static void replyVoice(final Context ctx, final long chatId, final String text) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                File m4a = null;
                try {
                    File wav = TtsHelper.synthToFile(ctx, text);
                    if (wav != null) {
                        try {
                            m4a = encodeAac(ctx, wav);
                        } catch (Exception ignored) {
                        }
                        try {
                            wav.delete();
                        } catch (Exception ignored) {
                        }
                    }
                    if (m4a != null && m4a.exists() && m4a.length() > 100) {
                        TelegramApi.sendFile(Prefs.token(ctx), "sendAudio", "audio",
                                chatId, m4a, null, null);
                        try {
                            m4a.delete();
                        } catch (Exception ignored) {}
                        return;
                    }
                } catch (Exception ignored) {
                }
                Commands.sayPlain(ctx, chatId, "🔊 " + text);
            }
        }).start();
    }

    private static int le16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8)
                | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    private static byte[] readAll(File f) throws Exception {
        FileInputStream fis = new FileInputStream(f);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[32768];
        int n;
        while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
        fis.close();
        return bos.toByteArray();
    }

    /** WAV 16-bit -> AAC dalam .m4a (untuk balasan suara Telegram). */
    private static File encodeAac(Context ctx, File wav) throws Exception {
        byte[] all = readAll(wav);
        if (all.length < 44) throw new Exception("wav terlalu pendek");
        int sampleRate = le32(all, 24);
        int channels = le16(all, 22);
        int bits = le16(all, 34);
        if (bits != 16 || sampleRate <= 0) throw new Exception("format wav tak didukung");
        int nShorts = (all.length - 44) / 2;
        if (nShorts <= 0) throw new Exception("wav kosong");
        short[] pcm = new short[nShorts];
        ByteBuffer.wrap(all, 44, nShorts * 2).order(ByteOrder.LITTLE_ENDIAN)
                .asShortBuffer().get(pcm);
        if (channels == 2) {
            short[] mono = new short[nShorts / 2];
            for (int i = 0; i < mono.length; i++) {
                mono[i] = (short) ((pcm[i * 2] + pcm[i * 2 + 1]) / 2);
            }
            pcm = mono;
        }

        File out = new File(ctx.getCacheDir(), "tts_reply.m4a");
        try {
            out.delete();
        } catch (Exception ignored) {
        }
        MediaFormat fmt = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 1);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 64000);
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        MediaCodec enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        MediaMuxer muxer = null;
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            muxer = new MediaMuxer(out.getAbsolutePath(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            boolean muxStarted = false;
            int trackIdx = -1;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int off = 0;
            int chunkSamples = 1024;
            long pts = 0;
            boolean eosSent = false;
            int guard = 0;
            while (guard++ < 8000) {
                int inIdx = enc.dequeueInputBuffer(10000);
                if (inIdx >= 0) {
                    if (!eosSent && off < pcm.length) {
                        ByteBuffer inBuf = enc.getInputBuffer(inIdx);
                        int n = Math.min(chunkSamples, pcm.length - off);
                        inBuf.clear();
                        for (int i = 0; i < n; i++) inBuf.putShort(pcm[off + i]);
                        long durUs = (long) n * 1000000L / sampleRate;
                        enc.queueInputBuffer(inIdx, 0, n * 2, pts, 0);
                        pts += durUs;
                        off += n;
                    } else {
                        enc.queueInputBuffer(inIdx, 0, 0, pts,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        eosSent = true;
                    }
                }
                int outIdx = enc.dequeueOutputBuffer(info, 10000);
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    trackIdx = muxer.addTrack(enc.getOutputFormat());
                    muxer.start();
                    muxStarted = true;
                } else if (outIdx >= 0) {
                    ByteBuffer ob = enc.getOutputBuffer(outIdx);
                    if (muxStarted && info.size > 0 && ob != null) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        muxer.writeSampleData(trackIdx, ob, info);
                    }
                    enc.releaseOutputBuffer(outIdx, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
            if (!muxStarted) throw new Exception("muxer tidak jalan");
            return out;
        } finally {
            try {
                enc.stop();
            } catch (Exception ignored) {
            }
            try {
                enc.release();
            } catch (Exception ignored) {
            }
            try {
                if (muxer != null) muxer.stop();
            } catch (Exception ignored) {
            }
            try {
                if (muxer != null) muxer.release();
            } catch (Exception ignored) {
            }
        }
    }
}
