package id.irvan.mydevice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Jalankan ulang service polling setelah HP reboot. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Intent s = new Intent(context, PollService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(s);
            } else {
                context.startService(s);
            }
            try {
                AlarmReceiver.rescheduleAll(context);
            } catch (Exception ignored) {
            }
            try {
                if (Prefs.notifOn(context) && Prefs.notifBoot(context)) {
                    NotifReceiver.sendNotif(context, "\uD83D\uDCF1 HP ["
                            + Prefs.deviceId(context) + "] baru dinyalakan.");
                }
            } catch (Exception ignored) {
            }
        }
    }
}
