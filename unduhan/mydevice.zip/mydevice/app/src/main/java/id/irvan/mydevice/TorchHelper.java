package id.irvan.mydevice;

import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;

/** Kontrol senter: nyala/mati + mode strobo (kedip cepat). */
public class TorchHelper {

    private static TorchHelper instance;
    private final CameraManager cm;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean strobing = false;
    private boolean torchOn = false;

    private TorchHelper(Context c) {
        cm = (CameraManager) c.getApplicationContext().getSystemService(Context.CAMERA_SERVICE);
    }

    public static synchronized TorchHelper get(Context c) {
        if (instance == null) instance = new TorchHelper(c);
        return instance;
    }

    /** Cari kamera yang punya flash. @return id kamera atau null. */
    private String flashCameraId() {
        try {
            for (String id : cm.getCameraIdList()) {
                try {
                    Boolean hasFlash = cm.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (Boolean.TRUE.equals(hasFlash)) return id;
                } catch (Exception ignored) {
                }
            }
            // fallback: kamera pertama
            String[] ids = cm.getCameraIdList();
            return ids.length > 0 ? ids[0] : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** @return true jika perintah terkirim ke kamera. */
    public boolean setTorch(boolean on) {
        stopStrobe();
        torchOn = on;
        try {
            String id = flashCameraId();
            if (id == null) {
                torchOn = false;
                return false;
            }
            cm.setTorchMode(id, on);
            return true;
        } catch (Exception e) {
            torchOn = false;
            return false;
        }
    }

    public boolean isTorchOn() {
        return torchOn || strobing;
    }

    /** Kedip cepat ~4x per detik sampai stopStrobe(). @return true jika strobo jalan. */
    public boolean startStrobe() {
        if (strobing) return true;
        String id = flashCameraId();
        if (id == null) return false;
        flashId = id;
        strobing = true;
        handler.post(strobeTick);
        return true;
    }

    public void stopStrobe() {
        strobing = false;
        handler.removeCallbacks(strobeTick);
        torchOn = false;
        try {
            String id = flashId != null ? flashId : flashCameraId();
            if (id != null) cm.setTorchMode(id, false);
        } catch (Exception ignored) {
        }
    }

    public boolean isStrobing() {
        return strobing;
    }

    private String flashId = null;

    private final Runnable strobeTick = new Runnable() {
        private boolean phase = false;

        @Override
        public void run() {
            if (!strobing) return;
            phase = !phase;
            try {
                String id = flashId != null ? flashId : flashCameraId();
                if (id != null) cm.setTorchMode(id, phase);
            } catch (Exception e) {
                // kamera sibuk / error: hentikan strobo agar tidak macet
                strobing = false;
                torchOn = false;
                return;
            }
            handler.postDelayed(this, 130);
        }
    };
}
