package id.irvan.mydevice;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

/**
 * Text-to-speech Bahasa Indonesia, mode LOOP: teks diucapkan berulang-ulang
 * sampai stopLoop() dipanggil (via /berhenti).
 */
public class TtsHelper {

    public interface SpeakCallback {
        void onDone(boolean ok, String err);
    }

    private static TextToSpeech tts;
    private static boolean looping = false;
    private static String loopText = "";
    private static int utterSeq = 0;
    private static boolean ready = false;

    /** Mulai loop ucapan. Callback dipanggil di thread background. */
    public static synchronized void speakLoop(final Context ctx, final String text,
                                             final SpeakCallback cb) {
        stopLoopInternal();
        looping = true;
        loopText = text;
        ready = false;
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (tts == null) {
                        final boolean[] done = {false};
                        final boolean[] ok = {false};
                        final String[] err = {null};
                        tts = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
                            @Override
                            public void onInit(int status) {
                                try {
                                    if (status != TextToSpeech.SUCCESS) {
                                        err[0] = "TTS init gagal";
                                    } else {
                                        int lang = tts.setLanguage(new Locale("id", "ID"));
                                        if (lang == TextToSpeech.LANG_MISSING_DATA
                                                || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                                            err[0] = "Suara Bahasa Indonesia belum terinstal di HP ini. "
                                                    + "Install dulu: Pengaturan > Bahasa > Text-to-speech > "
                                                    + "Install data suara > Indonesia.";
                                        } else {
                                            tts.setOnUtteranceProgressListener(
                                                    new UtteranceProgressListener() {
                                                        @Override
                                                        public void onStart(String utteranceId) {
                                                        }

                                                        @Override
                                                        public void onDone(String utteranceId) {
                                                            // ucapkan lagi selama loop aktif
                                                            speakOnce();
                                                        }

                                                        @Override
                                                        public void onError(String utteranceId) {
                                                        }
                                                    });
                                            ok[0] = true;
                                        }
                                    }
                                } catch (Exception e) {
                                    err[0] = e.getMessage();
                                } finally {
                                    synchronized (done) {
                                        done[0] = true;
                                        done.notifyAll();
                                    }
                                }
                            }
                        });
                        synchronized (done) {
                            long t0 = System.currentTimeMillis();
                            while (!done[0] && System.currentTimeMillis() - t0 < 15000) {
                                try {
                                    done.wait(1000);
                                } catch (InterruptedException ignored) {
                                }
                            }
                        }
                        if (!ok[0]) {
                            looping = false;
                            shutdown();
                            if (cb != null) cb.onDone(false, err[0] != null ? err[0] : "TTS init timeout");
                            return;
                        }
                        ready = true;
                    }
                    speakOnce();
                    if (cb != null) cb.onDone(true, null);
                } catch (Exception e) {
                    looping = false;
                    if (cb != null) cb.onDone(false, e.getMessage());
                }
            }
        }).start();
    }

    /**
     * Ucapkan SEKALI saja (tidak loop). Menghentikan loop yang sedang jalan.
     * Callback dipanggil di thread background.
     */
    public static void speak(final Context ctx, final String text, final SpeakCallback cb) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (TtsHelper.class) {
                    stopLoopInternal();
                }
                final boolean[] done = {false};
                final boolean[] ok = {false};
                final String[] err = {null};
                try {
                    synchronized (TtsHelper.class) {
                        if (tts == null) {
                            tts = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
                                @Override
                                public void onInit(int status) {
                                    try {
                                        if (status != TextToSpeech.SUCCESS) {
                                            err[0] = "TTS init gagal";
                                        } else {
                                            int lang = tts.setLanguage(new java.util.Locale("id", "ID"));
                                            if (lang == TextToSpeech.LANG_MISSING_DATA
                                                    || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                                                err[0] = "Suara Bahasa Indonesia belum terinstal di HP ini. "
                                                        + "Install dulu: Pengaturan > Bahasa > Text-to-speech > "
                                                        + "Install data suara > Indonesia.";
                                            } else {
                                                ok[0] = true;
                                            }
                                        }
                                    } catch (Exception e) {
                                        err[0] = e.getMessage();
                                    } finally {
                                        synchronized (done) {
                                            done[0] = true;
                                            done.notifyAll();
                                        }
                                    }
                                }
                            });
                        } else {
                            ok[0] = true;
                            done[0] = true;
                        }
                    }
                    synchronized (done) {
                        long t0 = System.currentTimeMillis();
                        while (!done[0] && System.currentTimeMillis() - t0 < 15000) {
                            try {
                                done.wait(1000);
                            } catch (InterruptedException ignored) {
                            }
                        }
                    }
                    if (!ok[0]) {
                        if (cb != null) cb.onDone(false, err[0] != null ? err[0] : "TTS init timeout");
                        return;
                    }
                    synchronized (TtsHelper.class) {
                        ready = true;
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "md" + (++utterSeq));
                    }
                    if (cb != null) cb.onDone(true, null);
                } catch (Exception e) {
                    if (cb != null) cb.onDone(false, e.getMessage());
                }
            }
        }).start();
    }

    private static synchronized void speakOnce() {
        try {
            if (!looping || tts == null || !ready) return;
            String uid = "md" + (++utterSeq);
            tts.speak(loopText, TextToSpeech.QUEUE_FLUSH, null, uid);
        } catch (Exception ignored) {
        }
    }

    /** Hentikan loop (dipanggil dari /berhenti). TTS engine tetap siap. */
    public static synchronized void stopLoop() {
        stopLoopInternal();
    }

    private static void stopLoopInternal() {
        looping = false;
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
    }

    private static void shutdown() {
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        tts = null;
        ready = false;
    }

    /**
     * Sintesis teks ke file WAV (blocking, maks ~30 dtk). Dipakai untuk balasan suara.
     *
     * @return file wav, atau null bila gagal.
     */
    public static java.io.File synthToFile(Context ctx, String text) {
        final Context app = ctx.getApplicationContext();
        final java.io.File out = new java.io.File(app.getCacheDir(), "tts_reply.wav");
        try {
            if (out.exists()) out.delete();
        } catch (Exception ignored) {
        }
        final TextToSpeech[] holder = new TextToSpeech[1];
        try {
            final java.util.concurrent.CountDownLatch initLatch =
                    new java.util.concurrent.CountDownLatch(1);
            final boolean[] initOk = {false};
            holder[0] = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    try {
                        if (status == TextToSpeech.SUCCESS) {
                            int lang = holder[0].setLanguage(new Locale("id", "ID"));
                            initOk[0] = lang != TextToSpeech.LANG_MISSING_DATA
                                    && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                        }
                    } catch (Exception ignored) {
                    }
                    initLatch.countDown();
                }
            });
            if (!initLatch.await(15, java.util.concurrent.TimeUnit.SECONDS) || !initOk[0]) {
                return null;
            }
            final java.util.concurrent.CountDownLatch doneLatch =
                    new java.util.concurrent.CountDownLatch(1);
            final boolean[] ok = {false};
            holder[0].setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                }

                @Override
                public void onDone(String utteranceId) {
                    ok[0] = true;
                    doneLatch.countDown();
                }

                @Override
                public void onError(String utteranceId) {
                    doneLatch.countDown();
                }
            });
            int r = holder[0].synthesizeToFile(text, null, out, "ttsfile");
            if (r != TextToSpeech.SUCCESS) return null;
            if (!doneLatch.await(30, java.util.concurrent.TimeUnit.SECONDS)) return null;
            if (!ok[0] || !out.exists() || out.length() < 100) return null;
            return out;
        } catch (Exception e) {
            return null;
        } finally {
            try {
                if (holder[0] != null) holder[0].shutdown();
            } catch (Exception ignored) {
            }
        }
    }

    /** Dipakai saat service dimatikan. */
    public static synchronized void release() {
        stopLoopInternal();
        shutdown();
    }
}
