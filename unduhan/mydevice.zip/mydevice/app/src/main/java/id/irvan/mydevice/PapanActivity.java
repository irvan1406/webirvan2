package id.irvan.mydevice;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * IDE-6: Papan LED fullscreen + jam digital raksasa.
 * Dibuka via AppLockService.launchPapan() (aksesibilitas, lolos batas background).
 * Ketuk layar untuk keluar. /berhenti juga menutup via stopCurrent().
 */
public class PapanActivity extends Activity {

    public static String mode = "papan"; // "papan" | "jam"
    public static String teks = "";

    private static PapanActivity current = null;
    private static boolean resumed = false;

    /** true saat PapanActivity sedang tampil di depan. */
    public static boolean isResumed() {
        return resumed;
    }

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable task = null;
    private TextView tv;

    public static void stopCurrent() {
        PapanActivity a = current;
        if (a != null) {
            try {
                a.finish();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;
        // Revisi 2026-10-13: rotasi sensor + override manual (/papanset).
        int or = 0;
        try {
            or = Prefs.papanOrient(this);
        } catch (Exception ignored) {
        }
        if (or == 1) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if (or == 2) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        }
        // Revisi 2026-10-13: mode kiosk — hanya /berhenti yang menutup.
        try {
            Prefs.setPapanActive(this, true);
        } catch (Exception ignored) {
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        try {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = 1.0f;
            getWindow().setAttributes(lp);
        } catch (Exception ignored) {
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Prefs.papanBg(this));

        tv = new TextView(this);
        tv.setTextColor(Prefs.papanFg(this));
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(fontDariPref());
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(tv, lp);
        setContentView(root);

        if ("jam".equals(mode)) {
            tampilJam();
        } else {
            tampilPapan();
        }
    }

    private Typeface fontDariPref() {
        switch (Prefs.papanFont(this)) {
            case 1:
                return Typeface.SERIF;
            case 2:
                return Typeface.MONOSPACE;
            case 3:
                return Typeface.DEFAULT_BOLD;
            default:
                return Typeface.DEFAULT;
        }
    }

    private float ukuranSp() {
        switch (Prefs.papanSize(this)) {
            case 0:
                return 52f;
            case 1:
                return 84f;
            case 3:
                return 170f;
            default:
                return 120f;
        }
    }

    private void tampilPapan() {
        stopMarquee();
        String t = teks == null ? "" : teks;
        if (t.contains("|")) {
            tv.setText(t.replace("|", "\n"));
            tv.setSingleLine(false);
            tv.setGravity(Gravity.CENTER);
            tv.setTextSize(ukuranSp() * 0.7f);
            try {
                tv.setTranslationX(0);
            } catch (Exception ignored) {
            }
        } else {
            tv.setText(t);
            tv.setSingleLine(true);
            tv.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            tv.setHorizontallyScrolling(true);
            tv.setTextSize(ukuranSp());
            startMarquee();
        }
    }

    /** Hentikan animasi berjalan yang sedang aktif. */
    private void stopMarquee() {
        try {
            if (task != null) handler.removeCallbacks(task);
        } catch (Exception ignored) {
        }
        task = null;
    }

    /**
     * Teks berjalan ala LED asli: masuk dari kanan, geser ke kiri, keluar,
     * lalu masuk lagi — berulang. Pakai translationX (lebih andal dari scrollTo).
     */
    private void startMarquee() {
        stopMarquee();
        tv.post(new Runnable() {
            @Override
            public void run() {
                try {
                    final int textW = (int) tv.getPaint().measureText(tv.getText().toString());
                    final int viewW = tv.getWidth();
                    if (textW <= 0 || viewW <= 0) return;
                    final int[] speeds = {4, 8, 14, 22, 32}; // px per 30ms
                    int sp = 3;
                    try {
                        sp = Prefs.papanSpeed(PapanActivity.this);
                    } catch (Exception ignored) {
                    }
                    if (sp < 1) sp = 1;
                    if (sp > 5) sp = 5;
                    final int speedPx = speeds[sp - 1];
                    task = new Runnable() {
                        float x = viewW;

                        @Override
                        public void run() {
                            x -= speedPx;
                            if (x < -textW) x = viewW; // loop seperti LED
                            try {
                                tv.setTranslationX(x);
                            } catch (Exception ignored) {
                            }
                            try {
                                handler.postDelayed(this, 30);
                            } catch (Exception ignored) {
                            }
                        }
                    };
                    handler.post(task);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void tampilJam() {
        stopMarquee();
        try {
            tv.setTranslationX(0);
        } catch (Exception ignored) {
        }
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setTextSize(170f);
        task = new Runnable() {
            @Override
            public void run() {
                try {
                    boolean fmt24 = Prefs.jamFmt24(PapanActivity.this);
                    boolean detik = Prefs.jamDetik(PapanActivity.this);
                    String pat = fmt24 ? (detik ? "HH:mm:ss" : "HH:mm")
                            : (detik ? "hh:mm:ss a" : "hh:mm a");
                    tv.setText(new SimpleDateFormat(pat, Locale.getDefault()).format(new Date()));
                } catch (Exception ignored) {
                }
                handler.postDelayed(this, detik() ? 1000 : 5000);
            }

            private boolean detik() {
                try {
                    return Prefs.jamDetik(PapanActivity.this);
                } catch (Exception e) {
                    return true;
                }
            }
        };
        handler.post(task);
    }

    @Override
    protected void onDestroy() {
        if (task != null) {
            try {
                handler.removeCallbacks(task);
            } catch (Exception ignored) {
            }
            task = null;
        }
        if (current == this) current = null;
        super.onDestroy();
    }
}
