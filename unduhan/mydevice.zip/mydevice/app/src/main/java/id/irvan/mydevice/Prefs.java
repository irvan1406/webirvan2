package id.irvan.mydevice;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Penyimpanan pengaturan + state bot. */
public class Prefs {
    private static final String NAME = "mydevice";
    // Token default diisi saat install; bisa diganti di layar utama.
    public static final String DEFAULT_TOKEN = "ISI_TOKEN_BOT_KAMU_DISINI";
    public static final long DEFAULT_OWNER = 0L;

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static String token(Context c) {
        return sp(c).getString("token", DEFAULT_TOKEN);
    }

    public static void setToken(Context c, String v) {
        sp(c).edit().putString("token", v).apply();
    }

    /** Jumlah tombol per baris di menu Telegram: 1 (renggang) s/d 4 (rapat). */
    static int btnCols(Context c) {
        try {
            int v = sp(c).getInt("btncols", 2);
            return (v >= 1 && v <= 4) ? v : 2;
        } catch (Exception e) {
            return 2;
        }
    }

    static void setBtnCols(Context c, int v) {
        sp(c).edit().putInt("btncols", v).apply();
    }

    public static long ownerId(Context c) {
        try {
            return Long.parseLong(sp(c).getString("owner", String.valueOf(DEFAULT_OWNER)));
        } catch (Exception e) {
            return DEFAULT_OWNER;
        }
    }

    public static void setOwnerId(Context c, String v) {
        sp(c).edit().putString("owner", v).apply();
    }

    /** PIN untuk lockscreen & kunci aplikasi. */
    public static String pin(Context c) {
        return sp(c).getString("pin", "");
    }

    public static void setPin(Context c, String v) {
        sp(c).edit().putString("pin", v).apply();
    }

    /** Kode otentikasi khusus perintah via SMS — TERPISAH dari PIN lockscreen. */
    public static String smsCode(Context c) {
        return sp(c).getString("sms_code", "");
    }

    public static void setSmsCode(Context c, String v) {
        sp(c).edit().putString("sms_code", v == null ? "" : v).apply();
    }

    public static boolean screenLocked(Context c) {
        return sp(c).getBoolean("screen_locked", false);
    }

    public static void setScreenLocked(Context c, boolean v) {
        sp(c).edit().putBoolean("screen_locked", v).apply();
    }

    public static String lockMessage(Context c) {
        return sp(c).getString("lock_msg", "HP dikunci. Masukkan PIN yang dikirim.");
    }

    public static void setLockMessage(Context c, String v) {
        sp(c).edit().putString("lock_msg", v).apply();
    }

    public static Set<String> lockedApps(Context c) {
        return new HashSet<>(sp(c).getStringSet("locked_apps", new HashSet<String>()));
    }

    public static void setLockedApps(Context c, Set<String> v) {
        sp(c).edit().putStringSet("locked_apps", v).apply();
    }

    /** Daftar aplikasi terakhir dari /daftarapk: JSONArray string "label|package". */
    public static void setLastAppList(Context c, JSONArray arr) {
        sp(c).edit().putString("last_apps", arr.toString()).apply();
    }

    public static JSONArray getLastAppList(Context c) {
        try {
            return new JSONArray(sp(c).getString("last_apps", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    /** Cari package dari nomor / nama / label. Kembalikan JSONObject {label, pkg} atau null. */
    public static JSONObject resolveApp(Context c, String query) {        JSONArray arr = getLastAppList(c);
        String q = query.trim().toLowerCase();
        try {
            // nomor urut?
            int idx = Integer.parseInt(q) - 1;
            if (idx >= 0 && idx < arr.length()) {
                String[] parts = arr.getString(idx).split("\\|", 2);
                JSONObject o = new JSONObject();
                o.put("label", parts[0]);
                o.put("pkg", parts.length > 1 ? parts[1] : parts[0]);
                return o;
            }
        } catch (Exception ignored) {
        }
        try {
            for (int i = 0; i < arr.length(); i++) {
                String[] parts = arr.getString(i).split("\\|", 2);
                String label = parts[0];
                String pkg = parts.length > 1 ? parts[1] : parts[0];
                if (label.toLowerCase().contains(q) || pkg.toLowerCase().contains(q)
                        || pkg.toLowerCase().endsWith("." + q)) {
                    JSONObject o = new JSONObject();
                    o.put("label", label);
                    o.put("pkg", pkg);
                    return o;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    // ---------- multi-perangkat (v2.0) ----------

    /** ID unik HP ini, mis. "utama", "anak". */
    public static String deviceId(Context c) {
        return sp(c).getString("device_id", "utama").trim().toLowerCase();
    }

    public static void setDeviceId(Context c, String v) {
        v = v == null ? "utama" : v.trim().toLowerCase().replaceAll("[^a-z0-9_\\-]", "");
        if (v.isEmpty()) v = "utama";
        sp(c).edit().putString("device_id", v).apply();
    }

    /** Daftar ID perangkat yang dikenal, dipisah koma. Perangkat pertama = menu server. */
    public static String deviceListRaw(Context c) {
        return sp(c).getString("device_list", "utama,anak");
    }

    public static void setDeviceList(Context c, String v) {
        sp(c).edit().putString("device_list", v == null ? "utama,anak" : v).apply();
    }

    public static java.util.List<String> deviceList(Context c) {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String s : deviceListRaw(c).split(",")) {
            s = s.trim().toLowerCase().replaceAll("[^a-z0-9_\\-]", "");
            if (!s.isEmpty() && !out.contains(s)) out.add(s);
        }
        if (out.isEmpty()) out.add("utama");
        if (!out.contains(deviceId(c))) out.add(0, deviceId(c));
        return out;
    }

    public static String firstDevice(Context c) {
        return deviceList(c).get(0);
    }

    /** Hanya perangkat pertama yang me-render menu / menangani foto & /menu. */
    public static boolean isMenuServer(Context c) {
        return deviceId(c).equals(firstDevice(c));
    }

    public static boolean knownTarget(Context c, String id) {
        if (id == null) return false;
        id = id.trim().toLowerCase();
        return id.equals("semua") || id.equals("all") || deviceList(c).contains(id);
    }

    /** Hapus ID dari registry. @return true jika ada yang dihapus. */
    public static boolean removeDevice(Context c, String id) {
        if (id == null) return false;
        id = id.trim().toLowerCase();
        java.util.List<String> keep = new java.util.ArrayList<>();
        boolean found = false;
        for (String s : deviceListRaw(c).split(",")) {
            String norm = s.trim().toLowerCase().replaceAll("[^a-z0-9_\\-]", "");
            if (norm.isEmpty()) continue;
            if (norm.equals(id)) {
                found = true;
                continue;
            }
            if (!keep.contains(s.trim())) keep.add(s.trim());
        }
        if (found) setDeviceList(c, android.text.TextUtils.join(",", keep));
        return found;
    }

    /** Terbitkan ID unik acak (mis. IRV7X2K), simpan ke registry, kembalikan ID-nya. */
    public static String issueId(Context c) {
        java.util.List<String> list = deviceList(c);
        java.util.Random r = new java.util.Random();
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        String id;
        do {
            StringBuilder sb = new StringBuilder("IRV");
            for (int i = 0; i < 4; i++) sb.append(chars.charAt(r.nextInt(chars.length())));
            id = sb.toString().toLowerCase();
        } while (list.contains(id));
        String raw = deviceListRaw(c).trim();
        setDeviceList(c, raw.isEmpty() ? id : raw + "," + id);
        return id;
    }

    // ---------- kunci PIN kiosk (v2.0) ----------

    public static boolean isPinLocked(Context c) {
        return sp(c).getBoolean("pin_locked", false);
    }

    public static void setPinLocked(Context c, boolean v) {
        sp(c).edit().putBoolean("pin_locked", v).apply();
    }

    // ---------- notifikasi proaktif ----------
    public static boolean notifOn(Context c) {
        return sp(c).getBoolean("notif_on", false);
    }

    public static void setNotifOn(Context c, boolean v) {
        sp(c).edit().putBoolean("notif_on", v).apply();
    }

    public static boolean notifSms(Context c) {
        return sp(c).getBoolean("notif_sms", true);
    }

    public static void setNotifSms(Context c, boolean v) {
        sp(c).edit().putBoolean("notif_sms", v).apply();
    }

    public static boolean notifBatt(Context c) {
        return sp(c).getBoolean("notif_batt", true);
    }

    public static void setNotifBatt(Context c, boolean v) {
        sp(c).edit().putBoolean("notif_batt", v).apply();
    }

    public static boolean notifBoot(Context c) {
        return sp(c).getBoolean("notif_boot", true);
    }

    public static void setNotifBoot(Context c, boolean v) {
        sp(c).edit().putBoolean("notif_boot", v).apply();
    }

    /** Chat tujuan notifikasi; 0 = pakai chat owner. */
    public static long notifChatId(Context c) {
        return sp(c).getLong("notif_chat", 0);
    }

    public static void setNotifChatId(Context c, long v) {
        sp(c).edit().putLong("notif_chat", v).apply();
    }

    /** Target mode HP hilang (untuk routing voice note antar-HP). null = tidak aktif. */
    public static String hilangTarget(Context c) {
        String v = sp(c).getString("hilang_target", null);
        return (v == null || v.isEmpty()) ? null : v;
    }

    public static void setHilangTarget(Context c, String v) {
        sp(c).edit().putString("hilang_target", v == null ? "" : v).apply();
    }

    // ---------- IDE-1: SMS fallback ----------
    /** Nomor pemilik untuk perintah via SMS (format: 0812..., tanpa spasi). */
    public static String ownerPhone(Context c) {
        return sp(c).getString("owner_phone", "");
    }

    public static void setOwnerPhone(Context c, String v) {
        sp(c).edit().putString("owner_phone", v == null ? "" : v.trim()).apply();
    }

    /** SubscriberId terakhir (deteksi ganti SIM). */
    public static String lastSimId(Context c) {
        return sp(c).getString("last_sim_id", "");
    }

    /** SIM pernah tercatat dicabut (untuk deteksi ganti SIM). */
    // ---------- Revisi 2026-10-13: orientasi papan, PIN hilang, kalibrasi keypad ----------
    /** Orientasi papan/jam: 0=auto(sensor) 1=portrait 2=landscape */
    public static int papanOrient(Context c) {
        int v = sp(c).getInt("papan_orient", 0);
        return Math.max(0, Math.min(2, v));
    }

    public static void setPapanOrient(Context c, int v) {
        sp(c).edit().putInt("papan_orient", Math.max(0, Math.min(2, v))).apply();
    }

    /** Mode kiosk papan/jam aktif (hanya /berhenti yang melepas). */
    public static boolean papanActive(Context c) {
        return sp(c).getBoolean("papan_active", false);
    }

    public static void setPapanActive(Context c, boolean v) {
        sp(c).edit().putBoolean("papan_active", v).apply();
    }

    /** Tampilkan keypad PIN di layar HP hilang (default true). */
    public static boolean hilangPinOn(Context c) {
        return sp(c).getBoolean("hilang_pin_on", true);
    }

    public static void setHilangPinOn(Context c, boolean v) {
        sp(c).edit().putBoolean("hilang_pin_on", v).apply();
    }

    public static String hilangPinLabel(Context c) {
        return sp(c).getString("hilang_pin_label", "Masukkan PIN untuk mengakses");
    }

    public static void setHilangPinLabel(Context c, String v) {
        sp(c).edit().putString("hilang_pin_label", v).apply();
    }

    public static String hilangPinSub(Context c) {
        return sp(c).getString("hilang_pin_sub", "");
    }

    public static void setHilangPinSub(Context c, String v) {
        sp(c).edit().putString("hilang_pin_sub", v).apply();
    }

    /** Peringatan lockdown layar HP hilang. */
    public static String hilangWarn(Context c) {
        return sp(c).getString("hilang_warn",
                "Tidak ada yang bisa kamu lakukan kecuali kirim pesan ke pemilik HP ini.");
    }

    public static void setHilangWarn(Context c, String v) {
        sp(c).edit().putString("hilang_warn", v).apply();
    }

    public static String hilangMsgLabel(Context c) {
        return sp(c).getString("hilang_msg_label", "Pesan untuk pemilik HP");
    }

    public static void setHilangMsgLabel(Context c, String v) {
        sp(c).edit().putString("hilang_msg_label", v).apply();
    }

    /** Kalibrasi keypad PIN lockscreen bawaan (fraksi 0-1 dari layar). */
    public static float pinGridX0(Context c) {
        return sp(c).getFloat("pingrid_x0", 0.125f);
    }

    public static float pinGridY0(Context c) {
        return sp(c).getFloat("pingrid_y0", 0.5525f);
    }

    public static float pinGridW(Context c) {
        return sp(c).getFloat("pingrid_w", 0.75f);
    }

    public static float pinGridH(Context c) {
        return sp(c).getFloat("pingrid_h", 0.38f);
    }

    public static void setPinGrid(Context c, float x0, float y0, float w, float h) {
        sp(c).edit().putFloat("pingrid_x0", x0).putFloat("pingrid_y0", y0)
                .putFloat("pingrid_w", w).putFloat("pingrid_h", h).apply();
    }

    // ---------- Teks custom layar HP hilang (revisi user 2026-10-13) ----------
    public static String hilangJudul(Context c) {
        return sp(c).getString("hilang_judul", "\uD83D\uDD12 My Device");
    }

    public static void setHilangJudul(Context c, String v) {
        sp(c).edit().putString("hilang_judul", v).apply();
    }

    public static String hilangPesan(Context c) {
        return sp(c).getString("hilang_pesan",
                "HP ini hilang, kamu gabisa ngapa-in juga, balikin sini \uD83D\uDE42");
    }

    public static void setHilangPesan(Context c, String v) {
        sp(c).edit().putString("hilang_pesan", v).apply();
    }

    public static String hilangLabel(Context c) {
        return sp(c).getString("hilang_label", "Balasan pemilik HP:");
    }

    public static void setHilangLabel(Context c, String v) {
        sp(c).edit().putString("hilang_label", v).apply();
    }

    public static String hilangHint(Context c) {
        return sp(c).getString("hilang_hint", "Ketik pesan untuk pemilik HP\u2026");
    }

    public static void setHilangHint(Context c, String v) {
        sp(c).edit().putString("hilang_hint", v).apply();
    }

    public static String hilangTombol(Context c) {
        return sp(c).getString("hilang_tombol", "KIRIM KE PEMILIK");
    }

    public static void setHilangTombol(Context c, String v) {
        sp(c).edit().putString("hilang_tombol", v).apply();
    }

    public static void resetHilangTeks(Context c) {
        sp(c).edit()
                .remove("hilang_judul").remove("hilang_pesan").remove("hilang_label")
                .remove("hilang_hint").remove("hilang_tombol")
                .remove("hilang_pin_label").remove("hilang_pin_sub").remove("hilang_msg_label")
                .remove("hilang_warn")
                .apply();
    }

    public static boolean simWasAbsent(Context c) {
        return sp(c).getBoolean("sim_was_absent", false);
    }

    public static void setSimWasAbsent(Context c, boolean v) {
        sp(c).edit().putBoolean("sim_was_absent", v).apply();
    }

    public static void setLastSimId(Context c, String v) {
        sp(c).edit().putString("last_sim_id", v == null ? "" : v).apply();
    }

    // ---------- IDE-3: foto penyusup ----------
    public static boolean fotoPenyusup(Context c) {
        return sp(c).getBoolean("foto_penyusup", true);
    }

    public static void setFotoPenyusup(Context c, boolean v) {
        sp(c).edit().putBoolean("foto_penyusup", v).apply();
    }

    // ---------- IDE-6: papan LED + jam ----------
    public static int papanBg(Context c) {
        return sp(c).getInt("papan_bg", 0xFF000000);
    }

    public static void setPapanBg(Context c, int v) {
        sp(c).edit().putInt("papan_bg", v).apply();
    }

    public static int papanFg(Context c) {
        return sp(c).getInt("papan_fg", 0xFFFFEB3B);
    }

    public static void setPapanFg(Context c, int v) {
        sp(c).edit().putInt("papan_fg", v).apply();
    }

    /** 0=sans 1=serif 2=mono 3=tebal */
    public static int papanFont(Context c) {
        return sp(c).getInt("papan_font", 0);
    }

    public static void setPapanFont(Context c, int v) {
        sp(c).edit().putInt("papan_font", v).apply();
    }

    /** kecepatan teks berjalan 1..5 */
    public static int papanSpeed(Context c) {
        int v = sp(c).getInt("papan_speed", 3);
        return Math.max(1, Math.min(5, v));
    }

    public static void setPapanSpeed(Context c, int v) {
        sp(c).edit().putInt("papan_speed", Math.max(1, Math.min(5, v))).apply();
    }

    /** ukuran teks 0=S 1=M 2=L 3=XL */
    public static int papanSize(Context c) {
        int v = sp(c).getInt("papan_size", 2);
        return Math.max(0, Math.min(3, v));
    }

    public static void setPapanSize(Context c, int v) {
        sp(c).edit().putInt("papan_size", Math.max(0, Math.min(3, v))).apply();
    }

    public static boolean jamFmt24(Context c) {
        return sp(c).getBoolean("jam_fmt24", true);
    }

    public static void setJamFmt24(Context c, boolean v) {
        sp(c).edit().putBoolean("jam_fmt24", v).apply();
    }

    public static boolean jamDetik(Context c) {
        return sp(c).getBoolean("jam_detik", true);
    }

    public static void setJamDetik(Context c, boolean v) {
        sp(c).edit().putBoolean("jam_detik", v).apply();
    }

    // ---------- IDE-7: antrean YouTube (per device) ----------
    // ---------- IDE-9: skip iklan YouTube ----------
    public static boolean skipIklan(Context c) {
        return sp(c).getBoolean("skip_iklan", true);
    }

    public static void setSkipIklan(Context c, boolean v) {
        sp(c).edit().putBoolean("skip_iklan", v).apply();
    }

    public static String antreanJson(Context c, String target) {
        return sp(c).getString("antrean_" + target, "[]");
    }

    public static void setAntreanJson(Context c, String target, String v) {
        sp(c).edit().putString("antrean_" + target, v == null ? "[]" : v).apply();
    }

    // ---------- mode suara (voice command) per chat ----------
    public static boolean voiceMode(Context c, long chatId) {
        return sp(c).getBoolean("voicemode_" + chatId, false);
    }

    public static void setVoiceMode(Context c, long chatId, boolean v) {
        sp(c).edit().putBoolean("voicemode_" + chatId, v).apply();
    }

    public static String pinLockPin(Context c) {
        return sp(c).getString("pin_lock_pin", "");
    }

    public static void setPinLockPin(Context c, String v) {
        sp(c).edit().putString("pin_lock_pin", v == null ? "" : v).apply();
    }

    // ---------- alarm (v2.2) : "triggerAt|label;..." ----------

    public static java.util.List<String> alarms(Context c) {
        java.util.List<String> out = new java.util.ArrayList<>();
        String raw = sp(c).getString("alarms", "");
        if (raw == null || raw.isEmpty()) return out;
        for (String x : raw.split(";")) {
            x = x.trim();
            if (!x.isEmpty()) out.add(x);
        }
        java.util.Collections.sort(out);
        return out;
    }

    public static void addAlarm(Context c, long triggerAt, String label) {
        removeAlarm(c, triggerAt);
        java.util.List<String> all = alarms(c);
        all.add(triggerAt + "|" + (label == null ? "" : label.replace(";", " ").replace("|", " ")));
        sp(c).edit().putString("alarms", android.text.TextUtils.join(";", all)).apply();
    }

    public static void removeAlarm(Context c, long triggerAt) {
        java.util.List<String> all = alarms(c);
        java.util.List<String> keep = new java.util.ArrayList<>();
        String prefix = triggerAt + "|";
        for (String x : all) {
            if (!x.startsWith(prefix) && !x.equals(String.valueOf(triggerAt))) keep.add(x);
        }
        sp(c).edit().putString("alarms", android.text.TextUtils.join(";", keep)).apply();
    }

    /** Hapus alarm yang jamnya diawali teks tsb ("06:30"). */
    public static boolean removeAlarmLike(Context c, String jam) {
        java.util.List<String> all = alarms(c);
        java.util.List<String> keep = new java.util.ArrayList<>();
        boolean found = false;
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.US);
        for (String x : all) {
            String[] p = x.split("\\|", 2);
            try {
                if (f.format(new java.util.Date(Long.parseLong(p[0]))).equals(jam)) {
                    found = true;
                    continue;
                }
            } catch (Exception ignored) {
            }
            keep.add(x);
        }
        if (found) sp(c).edit().putString("alarms", android.text.TextUtils.join(";", keep)).apply();
        return found;
    }
}
