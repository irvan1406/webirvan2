package id.irvan.mydevice;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.UUID;

/** Klien Bot API Telegram minimal (tanpa library tambahan). */
public class TelegramApi {

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return bos.toString("UTF-8");
    }

    public static JSONObject call(String token, String method, JSONObject params) throws Exception {
        URL url = new URL("https://api.telegram.org/bot" + token + "/" + method);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(60000);
        c.setReadTimeout(95000);
        c.setRequestProperty("Content-Type", "application/json");
        try (OutputStream os = c.getOutputStream()) {
            os.write(params.toString().getBytes("UTF-8"));
        }
        int code = c.getResponseCode();
        String body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
        JSONObject r = new JSONObject(body);
        if (!r.optBoolean("ok", false)) {
            throw new Exception("Telegram: " + r.optString("description", "error " + code));
        }
        return r;
    }

    public static JSONObject getUpdates(String token, long offset) throws Exception {
        JSONObject p = new JSONObject();
        p.put("offset", offset);
        p.put("timeout", 45);
        return call(token, "getUpdates", p);
    }

    public static void sendMessage(String token, long chatId, String text, JSONObject replyMarkup) throws Exception {
        if (text.length() > 4000) text = text.substring(0, 4000) + "\n...(dipotong)";
        JSONObject p = new JSONObject();
        p.put("chat_id", chatId);
        p.put("text", text);
        if (replyMarkup != null) p.put("reply_markup", replyMarkup);
        call(token, "sendMessage", p);
    }

    /** Satu tombol Menu (setelah perintah selesai, biar chat tidak tenggelam). */
    public static JSONObject homeMarkup() throws Exception {
        JSONObject btn = new JSONObject();
        btn.put("text", "\uD83C\uDFE0 Menu");
        btn.put("callback_data", "cmd:menu");
        JSONArray row = new JSONArray();
        row.put(btn);
        JSONArray kb = new JSONArray();
        kb.put(row);
        JSONObject m = new JSONObject();
        m.put("inline_keyboard", kb);
        return m;
    }

    public static void result(String token, long chatId, String text) {
        try {
            sendMessage(token, chatId, text, homeMarkup());
        } catch (Exception ignored) {
        }
    }

    public static void answerCallback(String token, String cbId) {
        try {
            JSONObject p = new JSONObject();
            p.put("callback_query_id", cbId);
            call(token, "answerCallbackQuery", p);
        } catch (Exception ignored) {
        }
    }

    /** Upload file generik (sendPhoto/sendAudio/sendDocument). */
    /** @return message_id pesan yang terkirim */
    public static long sendFile(String token, String method, String field,
                                long chatId, File file, String caption,
                                JSONObject replyMarkup) throws Exception {
        String boundary = UUID.randomUUID().toString();
        URL url = new URL("https://api.telegram.org/bot" + token + "/" + method);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(60000);
        c.setReadTimeout(95000);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (OutputStream os = c.getOutputStream()) {
            writeField(os, boundary, "chat_id", String.valueOf(chatId));
            if (caption != null) writeField(os, boundary, "caption", caption);
            if (replyMarkup != null) writeField(os, boundary, "reply_markup", replyMarkup.toString());
            os.write(("--" + boundary + "\r\n").getBytes("UTF-8"));
            os.write(("Content-Disposition: form-data; name=\"" + field + "\"; filename=\""
                    + file.getName() + "\"\r\n").getBytes("UTF-8"));
            os.write("Content-Type: application/octet-stream\r\n\r\n".getBytes("UTF-8"));
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = fis.read(buf)) > 0) os.write(buf, 0, n);
            }
            os.write("\r\n".getBytes("UTF-8"));
            os.write(("--" + boundary + "--\r\n").getBytes("UTF-8"));
        }
        int code = c.getResponseCode();
        String body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
        JSONObject r = new JSONObject(body);
        if (!r.optBoolean("ok", false)) {
            throw new Exception("Telegram: " + r.optString("description", "upload gagal"));
        }
        try {
            return r.getJSONObject("result").optLong("message_id", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    private static void writeField(OutputStream os, String boundary, String name, String value) throws Exception {
        os.write(("--" + boundary + "\r\n").getBytes("UTF-8"));
        os.write(("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n").getBytes("UTF-8"));
        os.write((value + "\r\n").getBytes("UTF-8"));
    }

    /** Edit teks pesan yang sudah terkirim (untuk menu inline). */
    public static void editMessage(String token, long chatId, long msgId,
                                   String text, JSONObject replyMarkup) throws Exception {
        if (text.length() > 4000) text = text.substring(0, 4000) + "\n...(dipotong)";
        JSONObject p = new JSONObject();
        p.put("chat_id", chatId);
        p.put("message_id", msgId);
        p.put("text", text);
        if (replyMarkup != null) p.put("reply_markup", replyMarkup);
        call(token, "editMessageText", p);
    }

    /**
     * Ganti foto pada pesan yang sudah terkirim (untuk live screen).
     * caption boleh null (caption lama dipertahankan Telegram bila null).
     */
    public static void editMessageMedia(String token, long chatId, long msgId,
                                        File photo, String caption,
                                        JSONObject replyMarkup) throws Exception {
        String boundary = UUID.randomUUID().toString();
        URL url = new URL("https://api.telegram.org/bot" + token + "/editMessageMedia");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(60000);
        c.setReadTimeout(95000);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        JSONObject media = new JSONObject();
        media.put("type", "photo");
        media.put("media", "attach://shot");
        if (caption != null) media.put("caption", caption);
        try (OutputStream os = c.getOutputStream()) {
            writeField(os, boundary, "chat_id", String.valueOf(chatId));
            writeField(os, boundary, "message_id", String.valueOf(msgId));
            writeField(os, boundary, "media", media.toString());
            if (replyMarkup != null) writeField(os, boundary, "reply_markup", replyMarkup.toString());
            os.write(("--" + boundary + "\r\n").getBytes("UTF-8"));
            os.write(("Content-Disposition: form-data; name=\"shot\"; filename=\""
                    + photo.getName() + "\"\r\n").getBytes("UTF-8"));
            os.write("Content-Type: image/jpeg\r\n\r\n".getBytes("UTF-8"));
            try (FileInputStream fis = new FileInputStream(photo)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = fis.read(buf)) > 0) os.write(buf, 0, n);
            }
            os.write("\r\n".getBytes("UTF-8"));
            os.write(("--" + boundary + "--\r\n").getBytes("UTF-8"));
        }
        int code = c.getResponseCode();
        String body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
        JSONObject r = new JSONObject(body);
        if (!r.optBoolean("ok", false)) {
            throw new Exception("Telegram: " + r.optString("description", "edit media gagal"));
        }
    }

    /** Live location: pin peta bergerak mengikuti HP selama livePeriod detik. */
    public static JSONObject sendLocationLive(String token, long chatId, double lat, double lon,
                                              int livePeriod) throws Exception {
        JSONObject p = new JSONObject();
        p.put("chat_id", chatId);
        p.put("latitude", lat);
        p.put("longitude", lon);
        p.put("live_period", livePeriod);
        return call(token, "sendLocation", p);
    }

    public static void editMessageLiveLocation(String token, long chatId, long msgId,
                                               double lat, double lon) throws Exception {
        JSONObject p = new JSONObject();
        p.put("chat_id", chatId);
        p.put("message_id", msgId);
        p.put("latitude", lat);
        p.put("longitude", lon);
        call(token, "editMessageLiveLocation", p);
    }

    public static void stopMessageLiveLocation(String token, long chatId, long msgId) throws Exception {
        JSONObject p = new JSONObject();
        p.put("chat_id", chatId);
        p.put("message_id", msgId);
        call(token, "stopMessageLiveLocation", p);
    }

    public static void sendLocation(String token, long chatId, double lat, double lon) throws Exception {        JSONObject p = new JSONObject();
        p.put("chat_id", chatId);
        p.put("latitude", lat);
        p.put("longitude", lon);
        call(token, "sendLocation", p);
    }

    public static JSONObject getFile(String token, String fileId) throws Exception {
        JSONObject p = new JSONObject();
        p.put("file_id", fileId);
        return call(token, "getFile", p);
    }

    public static void downloadFile(String token, String filePath, File dest) throws Exception {
        URL url = new URL("https://api.telegram.org/file/bot" + token + "/"
                + URLEncoder.encode(filePath, "UTF-8").replace("%2F", "/"));
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(60000);
        c.setReadTimeout(95000);
        try (InputStream in = c.getInputStream();
             java.io.FileOutputStream fos = new java.io.FileOutputStream(dest)) {
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 45L * 1024 * 1024) throw new Exception("File > 45MB");
                fos.write(buf, 0, n);
            }
        }
    }
}
