# PANDUAN ISI TOKEN & ID — MyDevice (WAJIB DIBACA)

Paket ini adalah kode sumber MyDevice yang **sudah dikosongkan** dari token bot
dan ID Telegram pemilik aslinya. Aplikasi TIDAK akan terhubung ke siapa pun
sebelum kamu mengisi token & ID milikmu sendiri. Itu memang disengaja: setiap
orang mengendalikan HP-nya sendiri, dengan bot-nya sendiri.

## Yang harus disiapkan

1. **Bot Telegram baru** — buka Telegram, chat **@BotFather**:
   - kirim `/newbot`, ikuti langkahnya (beri nama & username bot).
   - BotFather akan memberikan **TOKEN** berbentuk seperti
     `1234567890:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` — simpan baik-baik,
     jangan dibagikan ke siapa pun.
2. **ID Telegram kamu** — chat **@userinfobot** (atau @getmyid_bot), bot itu
   akan membalas ID numerik akunmu, contoh: `123456789`.

## Cara mengisi

Buka file:

```
app/src/main/java/id/irvan/mydevice/Prefs.java
```

Cari dua baris ini (di bagian atas file):

```java
public static final String DEFAULT_TOKEN = "ISI_TOKEN_BOT_KAMU_DISINI";
public static final long   DEFAULT_OWNER = 0L;
```

- Ganti `ISI_TOKEN_BOT_KAMU_DISINI` dengan token dari BotFather (tetap di dalam
  tanda kutip).
- Ganti `0` dengan ID Telegram numerik kamu (tanpa tanda kutip, biarkan huruf
  `L` di belakangnya).

Kedua nilai ini hanya **bawaan awal**; di dalam aplikasi juga ada menu
pengaturan untuk mengganti token & ID tanpa build ulang.

## Cara build menjadi APK

- **Android Studio**: buka folder proyek ini → tunggu Gradle selesai → menu
  Build → Build APK(s).
- **GitHub Actions**: unggah proyek ini ke repo GitHub milikmu → workflow
  `android.yml` yang disertakan akan membangun APK debug otomatis di tab
  Actions.

## Catatan

- APK jadi (folder `releases/`) **sengaja tidak disertakan** dalam paket ini,
  karena APK lama membawa token pemilik sebelumnya di dalamnya.
- Jangan pernah membagikan token botmu. Kalau token terlanjur tersebar, revoke
  lewat @BotFather dengan perintah `/revoke` lalu isi token yang baru.
- Gunakan hanya pada perangkat milikmu sendiri.
